<?php
// Genere par azj_base 0.0.28p - (c) Alexandre Zvenigorosky - 22/03/2016
require('../../verifieHtml.php');
function sqlp($txt){ // corrige ou supprime les caracteres speciaux \t \r \n \->\ '->''
if (is_numeric($txt)) return $txt;
$z=strlen($txt);
$w='';
$x=0;
while($x<$z){
	$v=$txt[$x++];
	if (($v == "\\") || ($v=="\n") | ($v=="\t") | ($v == "\r")) $v="";
	if ($v == "'") $v="\\'";
	$w.=$v;
}
return $w;
}
echo '<!DOCTYPE HTML>'."\n";
echo '<HTML>'."\n";
echo '<HEAD>'."\n";
echo '<TITLE>saisie3</TITLE>'."\n";
echo '<SCRIPT TYPE="text/javascript" SRC="../../js/headAZJ.js"></SCRIPT>';
echo '</HEAD>'."\n";
echo '<BODY>'."\n";
$conn=new mysqli('localhost','user','user','docAZJ',3306);
if (!$conn) die("Erreur: Ouverture du serveur Mysql en lecture!");
if (!isset($_POST['indicev'])) $ndeb=0; else $ndeb=$_POST['indicev'];
$l0=4;
$l=1;
$tbl_table[0]='HTML';
$ts[0]=0;
$tidx[0]='HTML_idx';
$tl_tbl[0]='HTML_idx';
$tl_tbl[1]='HTML_rubrique';
$tl_tbl[2]='HTML_texte';
$tl_tbl[3]='HTML_codes';
$ts[$l]=4;
$mod_sql=0;
$clause="SELECT HTML_idx, HTML_rubrique, HTML_texte, HTML_codes FROM HTML";
for($i2=0;$i2<$l0*6;$i2++) $tfonc[$i2]=0;
$result=$conn->query($clause);
$num_result=0;
while (($result) && ($ligne=$result->fetch_row())){
	for($i=0;$i<$l0;$i++){
		$k=5*$i;
		if (!$num_result) $tfonc[$k]=$ligne[$i];
		if (!$num_result) $tfonc[$k+1]=$ligne[$i];
		if ($ligne[$i]<$tfonc[$k]) $tfonc[$k]=$ligne[$i];
		if ($ligne[$i]>$tfonc[$k+1]) $tfonc[$k+1]=$ligne[$i];
		$tfonc[$k+2]+=$ligne[$i];
		$tfonc[$k+4]+=$ligne[$i]*$ligne[$i];
	}
	$num_result++;
}
if ($num_result){
	for($i2=0;$i2<$l0;$i2++){
		$k=5*$i2;
		$tfonc[$k+3]=$tfonc[$k+2]/$num_result;
		$tfonc[$k+4]=$tfonc[$k+4]/$num_result-$tfonc[$k+3]*$tfonc[$k+3];
	}
} else {
	for($i2=0;$i2<5*$l0;$i2++) $tfonc[$i2]='indetermin&eacute';
}
$result=$conn->query($clause);
$num_result=0;
while(($result) && ($ligne=$result->fetch_row())){
	$num_result++;
$_1i0=0;
$_1i=0;
$_1n=25;
$_1x=0;
$_1y=0;
$_20=100000;
$_1i=$_1i0;
while(($_1i<=$_1n) && ($_20)){
$_1x=$_1i*$_1i;
$_1y=$_1y+$_1x;
echo 'somme x²='.$_1y.'<BR>';
$_20--;
$_1i++;
}
echo '<h1>essai</h1><p>yyy<br></p>';
echo '<hr \>';
}
echo "\n".'</BODY>'."\n";
echo '</HTML>'."\n";
?>
