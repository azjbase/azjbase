prg('Def','i','','0','','');
prg('Def','n0','','0','','');
prg('Def','n','','5','','');
prg('Boucle','i','n0','n','','');
prg('5','[HTML.HTML_codes]','[HTML.HTML_codes]','+','i','');
prg('}','','','','','');
