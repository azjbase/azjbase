Fichier des controles azj_base
(c) A zvenigorosky - 10/10/2010

