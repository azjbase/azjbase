<?php
echo "<!DOCTYPE HTML>\n";
echo "<head>\n";
echo "<title>choix d'image</title>\n";
if (!isset($_POST['charger'])) $_POST['charger']='';
if (!isset($_POST['fichier'])) $_POST['fichier']='';
if (isset($_FILES['fichier'])) $nomFile=$_POST['fichier']=$_FILES['fichier']['name'];
else if (!isset($_POST['fichier'])) $_POST['fichier']='';
echo "<script type=\"text/javascript\">\n";
echo "function load(){\n";
if ($nomFile) echo "envoyer('".$nomFile."');\n";
echo "}\n";
echo "function getIFrameDocument(aID){\n";
echo "var docFen=window.opener.document;\n";
echo "return docFen.getElementById(aID).contentDocument;\n";
echo "}\n";

echo "function verifInt(val,valMin,valMax){\n";
// donne -1 si non valide
echo "var regle=/^[0-9]+$/;\n";
echo "if (!regle.test(val)){\n";
echo "alert(val+\" n'est pas un nombre valide!\");\n";
echo "return -1;\n";
echo "}\n";
echo "if ((val < valMin) || (val > valMax)){\n";
echo "alert(val+\" n'est pas compris entre \"+valMin+\" et \"+valMax+\" !\");\n";
echo "return -1;\n";
echo "}\n";
echo "return val;\n";
echo "}\n";

echo "function formate(motClef,phrase) {\n";
echo "getIFrameDocument('fenetre').execCommand(motClef,false, phrase);\n";
echo "return;\n";
echo "}\n";

echo "function envoyer(nomFile)\n";
echo "{\n";	
echo "if ( isNaN( document.getElementById('largeur').value ) || isNaN(document.getElementById('hauteur').value))\n";
echo "{\n";
echo "alert(\"Hauteur et largeur doivent être des nombres positifs!\");\n";
echo "window.close();\n";
echo "return;\n";
echo "}\n";
echo "var phrase='<IMG SRC=\"../../img/';\n";
//echo "var nomFile=document.getElementById('fichier').value;\n";
echo "if (!nomFile){\n";
echo "	alert(\"Vous n'avez pas spécifié le nom de l'image!\");\n";
echo "window.close();\n";
echo "}\n";
echo "phrase+=nomFile+'\"';\n";
echo "var larg=document.getElementById('largeur').value;\n";
echo "var haut=document.getElementById('hauteur').value;\n";
echo "if (larg) phrase+=' WIDTH=\"'+larg+'\"';\n";
echo "if (haut) phrase+=' HEIGHT=\"'+haut+'\"';\n";
echo "phrase+='>';\n";
echo "formate(\"inserthtml\",phrase);\n";
echo "window.close();\n";
echo "}\n";
echo "</script>\n";
echo "</head>\n";
echo "<body onload=\"load();\">\n";
echo "<form enctype=\"multipart/form-data\" name=\"texte\" id=\"texte\" method=\"post\">\n";
if (($_POST['charger']) && ($_FILES['fichier'])){
	$srcFile='../../../img/'.$_FILES['fichier']['name'];
	echo $srcFile.'<BR>';
	if (move_uploaded_file($_FILES['fichier']['tmp_name'],$srcFile)){
		echo "Image chargée!";
	} else {
		echo "Erreur:chargement de l'image!";
	}
}
echo "<TABLE>\n";
echo "<TR>\n";
echo "<TD>nom de l'image</TD>\n";
echo "<input type=\"hidden\" NAME=\"MAX_FILE_SIZE\" VALUE=\"300000\">\n";
echo "<TD><input name=\"fichier\" id=\"fichier\" type=\"file\" accept=\"image/*\" size=\"96\" value=\"".$_POST['fichier']."\"></TD></TR>\n";
echo "<TR><TD>largeur</TD>\n";
echo "<TD><input id=\"largeur\" type=\"number\" size=\"4\" /></TD></TR>\n";
echo "<TR><TD>hauteur</TD>\n";
echo "<TD><input id=\"hauteur\" type=\"number\" size=\"4\" /></TD></TR>\n";
echo "</TABLE>\n";
echo "<BR>\n";
echo "&nbsp;&nbsp;<input type=\"submit\" name=\"charger\" id=\"charger\" value=\"Choisir\">\n";
// echo "&nbsp;&nbsp;<input type=\"submit\" name=\"envVal\" id=\"envVal\" value=\"envoi\" onclick=\"envoyer();\">\n";
echo "</form>\n";
echo "</body>\n";
echo "</html>\n";
?>
