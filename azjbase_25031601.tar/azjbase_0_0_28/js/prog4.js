// variables globales
	declare_nom=new Array();
	declare_val=new Array(); // definition
	lig_type=new Array(); // type des lignes
	num_lig=1; // nb de lignes
	t_sql=0; // place dans declare pour champ sql

	function sel1_chg(num,selnum){
	var i=0;
	var j=parseInt(num);
	if (lig_type[j] == selnum) return;
	// effacement element precedent
	for(i=1;i<6;i++) elt[num*6+i].data="";
	if ((lig_type[j]=="Def") || (lig_type[j] == '=')){
		cols[num*6+1].removeChild(cols[num*6+1].lastChild);
		cols[num*6+3].removeChild(cols[num*6+3].lastChild);
	}
	if ((lig_type[j]=='Si') || (lig_type[j] == 'Si_') || (lig_type[j] == 'Si__') || (lig_type[j] == 'Rect')){
		cols[num*6+1].removeChild(cols[num*6+1].lastChild);
		cols[num*6+2].removeChild(cols[num*6+2].lastChild);
		cols[num*6+3].removeChild(cols[num*6+3].lastChild);
		cols[num*6+4].removeChild(cols[num*6+4].lastChild);
		cols[num*6+5].removeChild(cols[num*6+5].lastChild);
	}
	if ((lig_type[j]=="Prog") || (lig_type[j]=='Prog_')){
		cols[num*6+1].removeChild(cols[num*6+1].lastChild);
		cols[num*6+2].removeChild(cols[num*6+2].lastChild);
		cols[num*6+3].removeChild(cols[num*6+3].lastChild);
		cols[num*6+4].removeChild(cols[num*6+4].lastChild);
	}
	if ((lig_type[j]=="Fonc") || (lig_type[j] == 'Boucle') || (lig_type[j] == 'Tant que')){
		cols[num*6+1].removeChild(cols[num*6+1].lastChild);
		cols[num*6+2].removeChild(cols[num*6+2].lastChild);
		cols[num*6+3].removeChild(cols[num*6+3].lastChild);
	}
	if (selnum == "Def"){
		cols[num*6+1].appendChild(cr_def(num,"op1_",'blue'));
		cols[num*6+2].style.color='blue';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num*6+3].appendChild(cr_def(num,"op2_",'blue'));
		lig_type[j]=selnum;
	}
	if (selnum == "="){
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'black'));
		cols[num*6+2].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num*6+3].appendChild(cr_def(num,"op2_",'black'));
		lig_type[j]=selnum;
	}
	if (selnum == "Si"){
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'green'));
		cols[num*6+2].appendChild(cr_si_2(num,'green'));
		cols[num*6+3].appendChild(cr_si_1(num,"op3_",'green'));
		cols[num*6+4].style.color='green';
		elt[num*6+4].data=" alors ";
		cols[num*6+4].appendChild(cr_si_1(num,"op4_",'green'));
		cols[num*6+5].style.color='green';
		elt[num*6+5].data=String.fromCharCode(0x2190);
		cols[num*6+5].appendChild(cr_si_1(num,"op5_",'green'));
		lig_type[j]=selnum;
	}
	if (selnum == "Si_"){
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'green'));
		cols[num*6+2].appendChild(cr_si_2(num,'green'));
		cols[num*6+3].appendChild(cr_def(num,"op3_",'green'));
		cols[num*6+4].style.color='green';
		elt[num*6+4].data=" alors ";
		cols[num*6+4].appendChild(cr_si_1(num,"op4_",'green'));
		cols[num*6+5].style.color='green';
		elt[num*6+5].data=String.fromCharCode(0x2190);
		cols[num*6+5].appendChild(cr_si_1(num,"op5_",'green'));
		lig_type[j]=selnum;
	}
	if (selnum == "Si__"){
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'green'));
		cols[num*6+2].appendChild(cr_si_2(num,'green'));
		cols[num*6+3].appendChild(cr_def(num,"op3_",'green'));
		cols[num*6+4].style.color='green';
		elt[num*6+4].data=" alors ";
		cols[num*6+4].appendChild(cr_si_1(num,"op4_",'green'));
		cols[num*6+5].style.color='green';
		elt[num*6+5].data=String.fromCharCode(0x2190);
		cols[num*6+5].appendChild(cr_def(num,"op5_",'green'));
		lig_type[j]=selnum;
	}
	if (selnum == "Fonc"){
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'black'));
		cols[num*6+2].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num*6+2].appendChild(cr_f_1(num));
		cols[num*6+3].appendChild(cr_si_1(num,"op3_",'black'));
		lig_type[j]=selnum;
	}
	if ((selnum == 'Fin') || (selnum == '}')) lig_type[j]=selnum;
	if (selnum == 'Prog_'){
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'black'));
		cols[num*6+2].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num*6+2].appendChild(cr_si_1(num,"op2_",'black'));
		cols[num*6+3].appendChild(cr_opr_1(num,"op3_"));
		cols[num*6+4].appendChild(cr_def(num,"op4_",'black'));
		lig_type[j]=selnum;
	}
	if (selnum == 'Boucle'){
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'red'));
		cols[num*6+2].style.color='red';
		elt[num*6+2].data=" variant de ";
		cols[num*6+2].appendChild(cr_si_1(num,"op2_",'red'));
		cols[num*6+3].style.color='red';
		elt[num*6+3].data=" a ";
		cols[num*6+3].appendChild(cr_si_1(num,"op3_",'red'));
		cols[num*6+4].style.color='red';
		elt[num*6+4].data='{';
		lig_type[j]=selnum;
	}
	if (selnum == 'Tant que'){
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'red'));
		cols[num*6+2].appendChild(cr_si_2(num,'red'));
		cols[num*6+3].appendChild(cr_si_1(num,"op3_",'red'));
		cols[num*6+4].style.color='red';
		elt[num*6+4].data='{';
		lig_type[j]=selnum;
	}
	if (selnum == 'Rect'){
		elt[num*6+1].data="Origine x";
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'darkviolet'));
		cols[num*6+1].style.color='darkviolet';
		elt[num*6+2].data="y";
		cols[num*6+2].appendChild(cr_si_1(num,"op2_",'darkviolet'));
		cols[num*6+2].style.color='darkviolet';
		elt[num*6+3].data="largeur";
		cols[num*6+3].appendChild(cr_si_1(num,"op3_",'darkviolet'));
		cols[num*6+3].style.color='darkviolet';
		elt[num*6+4].data="hauteur";
		cols[num*6+4].appendChild(cr_si_1(num,"op4_",'darkviolet'));
		cols[num*6+4].style.color='darkviolet';
		elt[num*6+5].data="en";
		cols[num*6+5].appendChild(cr_si_1(num,"op5_",'darkviolet'));
		cols[num*6+5].style.color='darkviolet';
		lig_type[j]=selnum;
	}
	if (parseInt(selnum) == j){ // ligne d'affectation
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'black'));
		cols[num*6+2].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num*6+2].appendChild(cr_si_1(num,"op2_",'black'));
		cols[num*6+3].appendChild(cr_opr_1(num,"op3_"));
		cols[num*6+4].appendChild(cr_si_1(num,"op4_",'black'));
		lig_type[j]="Prog";
	}
	if (j >= num_lig){
		num_lig++;
		document.getElementById("nbe").value=num_lig;
		lig_type[num_lig]="";
		lignes[num_lig]=document.createElement("tr");
		for (i=0;i<6;i++){
	 		cols[i+num_lig*6]=document.createElement("td");
			if (i == 0) elt[i+num_lig*6]=cr_select_1(num_lig);
			else elt[i+num_lig*6]=document.createTextNode("");
			cols[i+num_lig*6].appendChild(elt[i+num_lig*6]);
			lignes[num_lig].appendChild(cols[i+num_lig*6]);
		}
        	tablebody.appendChild(lignes[num_lig]);
	}
}

	function vnom(txt){ // indique si un non est correct
	var i=1;
	var c;
	var n=txt.length;
	var ok=0; // valeur de retour
	if (n==0) return ok;
	c=txt.charAt(0);
	if (c == '_') ok=1;
	if ((c >= 'A') && (c <= 'Z')) ok=1;
	if ((c >= 'a') && (c <= 'z')) ok=1;
	if (!ok) return 0;
	while((i<n) && (ok)){
		ok=0;
		c=txt.charAt(i++);
		if (c == '_') ok=1;
		if ((c >= 'A') && (c <= 'Z')) ok=1;
		if ((c >= 'a') && (c <= 'z')) ok=1;
		if ((c >= '0') && (c <= '9')) ok=1;
	}
	return ok;
}

    function cr_select_1(num){
	var a=document.createElement("select");
	a.name="type_"+num;
	a.size="1";
	a.id="type_"+num;
	a.onchange=function(){sel1_chg(num,this[this.selectedIndex].value);};
	var nOption;
	nOption=new Option("","",false,false);
	a.options.add(nOption);
	nOption=new Option(num,num,false,false);
	a.options.add(nOption);
	nOption=new Option("Si","Si",false,false);
	nOption.style.color='green';
	a.options.add(nOption);
	nOption=new Option('Def','Def',false,false);
	nOption.style.color='blue';
	a.options.add(nOption);
	nOption=new Option("Fonc","Fonc",false,false);
	a.options.add(nOption);
	nOption=new Option("Prog_","Prog_",false,false);
	a.options.add(nOption);
	nOption=new Option("Si_","Si_",false,false);
	nOption.style.color='green';
	a.options.add(nOption);
	nOption=new Option("Si__","Si__",false,false);
	nOption.style.color='green';
	a.options.add(nOption);
	nOption=new Option("=","=",false,false);
	a.options.add(nOption);
	nOption=new Option("Boucle","Boucle",false,false);
	nOption.style.color='red';
	a.options.add(nOption);
	nOption=new Option("}","}",false,false);
	nOption.style.color='red';
	a.options.add(nOption);
	nOption=new Option("Tant que","Tant que",false,false);
	nOption.style.color='red';
	a.options.add(nOption);
	nOption=new Option("Rect","Rect",false,false);
	nOption.style.color='darkviolet';
	a.options.add(nOption);
	nOption=new Option("Fin","Fin",false,false);
	a.options.add(nOption);
	return a;
}
 
    function cr_opr_1(num,nom){
	var a=document.createElement("select");
	a.name=nom+num;
	a.size="1";
	a.id=nom+num;
	var nOption;
	nOption=new Option("+","+",false,false);
	a.options.add(nOption);
	nOption=new Option("-","-",false,false);
	a.options.add(nOption);
	nOption=new Option("*","*",false,false);
	a.options.add(nOption);
	nOption=new Option("/","/",false,false);
	a.options.add(nOption);
	nOption=new Option("%","%",false,false);
	a.options.add(nOption);
	nOption=new Option(".",".",false,false);
	a.options.add(nOption);
	nOption=new Option(":",":",false,false); // extraction d'un caractère
	a.options.add(nOption);
	nOption=new Option("^","^",false,false); // puissance
	a.options.add(nOption);
	return a;
}

    function cr_f_1(num){
	var a=document.createElement("select");
	a.name='op2_'+num;
	a.size="1";
	a.id='op2_'+num;
	var nOption;
	nOption=new Option("Ent","Ent",false,false);
	a.options.add(nOption);
	nOption=new Option("Frac","Frac",false,false);
	a.options.add(nOption);
	nOption=new Option("log","Log",false,false);
	a.options.add(nOption);
	nOption=new Option("Exp","exp",false,false);
	a.options.add(nOption);
	nOption=new Option("Abs","abs",false,false);
	a.options.add(nOption);
	nOption=new Option("Long","Long",false,false);
	a.options.add(nOption);
	nOption=new Option("sqrt","sqrt",false,false);
	a.options.add(nOption);
	nOption=new Option("Inv","Inv",false,false);
	a.options.add(nOption);
	nOption=new Option("Cos","cos",false,false);
	a.options.add(nOption);
	nOption=new Option("Sin","sin",false,false);
	a.options.add(nOption);
	nOption=new Option("Tan","tan",false,false);
	a.options.add(nOption);
	nOption=new Option("Id","Id",false,false);
	a.options.add(nOption);
	nOption=new Option("Type","Type",false,false);
	a.options.add(nOption);
	return a;
}

    function cr_si_1(num,nom,couleur){
	var j=parseInt(num);
	var a=document.createElement("select");
	a.name=nom+num;
	a.size="1";
	a.id=nom+num;
	a.style.color=couleur;
	var nOption;
	var i;
	for(i=0;i<=num_lig+t_sql;i++){
		if (declare_nom[i] != undefined){
			nOption=new Option(declare_nom[i],declare_nom[i],false,false);
			a.options.add(nOption);
		}
	}
	return a;
}

	function cr_si_2(num,couleur){
		var a=document.createElement("select");
		a.name="op2_"+num;
		a.size="1";
		a.id="op2_"+num;
		a.style.color=couleur;
		var nOption;
		nOption=new Option("=","=",false,false);
		a.options.add(nOption);
		nOption=new Option("<=","<=",false,false);
		a.options.add(nOption);
		nOption=new Option("<","<",false,false);
		a.options.add(nOption);
		nOption=new Option(">",">",false,false);
		a.options.add(nOption);
		nOption=new Option(">=",">=",false,false);
		a.options.add(nOption);
		nOption=new Option("!=","!=",false,false);
		a.options.add(nOption);
		nOption=new Option("~","~",false);
		a.options.add(nOption);
		return a;
}

	function txt_blur(num,tid,valeur){
	var nfonc=tid.substr(0,4);
	var j=parseInt(num);
	if ((nfonc == "op1_") || (nfonc == "op2_")){
		var a0=document.getElementById("op1_"+num);
		var a1=a0.value;
		if (!vnom(a1)){
			a1="val_"+num;
			a0.value=a1;
		}
		var a2=document.getElementById("op2_"+num).value;
		declare_nom[j+t_sql]=a1;
		declare_val[j+t_sql]=a2;
	}
}

    function cr_def(num,nom,couleur){
	var a=document.createElement("input");
	a.name=nom+num;
	a.id=nom+num;
	a.size="24";
	a.type="text";
	a.maxLength="24";
	a.style.color=couleur;
	a.onblur=function(){txt_blur(num,this.id,this.value);};
	return a;
}
    function cs_def(num,nom,v,couleur){
	var a=document.createElement("input");
	a.name=nom+num;
	a.id=nom+num;
	a.size="24";
	a.type="text";
	a.maxLength="24";
	a.style.color=couleur;
	a.value=v;
	a.onblur=function(){txt_blur(num,this.id,this.value);};
	return a;
}

	function rech_sel(obj,a){
	var n=obj.length;
	var tbl=obj.options;
	var i=0;
	while(tbl[i].value != a) i++;
	return i;
}

	function prg(b,a1,a2,a3,a4,a5){ // genere la ligne equivalente
	var i=0;
	var num=num_lig;
	var j=parseInt(num);
	var obj;
	var selnum=b;
	if (selnum == "Def"){
		if (!vnom(a1)) a1="val_"+num;
		obj=cols[num*6].lastChild;
		obj.selectedIndex=3;
		cols[num*6+1].appendChild(cs_def(num,"op1_",a1,'blue'));
		cols[num*6+2].style.color='blue';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num*6+3].appendChild(cs_def(num,"op2_",a2,'blue'));
		lig_type[j]="Def";
		declare_nom[t_sql+num]=a1;
		declare_val[t_sql+num]=a2;
	}
		if (selnum == "="){
		obj=cols[num*6].lastChild;
		obj.selectedIndex=8;
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'black'));
		cols[num*6+2].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num*6+3].appendChild(cs_def(num,"op3_",a3,'black'));
		obj=cols[num*6+1].lastChild;
		obj.selectedIndex=(rech_sel(obj,a1));
		lig_type[j]="=";
	}
	if (selnum == "Si"){
		obj=cols[num*6].lastChild;
		obj.selectedIndex=2;
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'green'));
		cols[num*6+2].appendChild(cr_si_2(num,'green'));
		cols[num*6+3].appendChild(cr_si_1(num,"op3_",'green'));
		cols[num*6+4].style.color='green';
		elt[num*6+4].data=" alors ";
		cols[num*6+4].appendChild(cr_si_1(num,"op4_",'green'));
		cols[num*6+5].style.color='green';
		elt[num*6+5].data=String.fromCharCode(0x2190);
		cols[num*6+5].appendChild(cr_si_1(num,"op5_",'green'));
		lig_type[j]=selnum;
		obj=cols[num*6+1].lastChild;
		obj.selectedIndex=(rech_sel(obj,a1));
		obj=cols[num*6+2].lastChild;
		obj.selectedIndex=(rech_sel(obj,a2));
		obj=cols[num*6+3].lastChild;
		obj.selectedIndex=(rech_sel(obj,a3));
		obj=cols[num*6+4].lastChild;
		obj.selectedIndex=(rech_sel(obj,a4));
		obj=cols[num*6+5].lastChild;
		obj.selectedIndex=(rech_sel(obj,a5));
	}
	if (selnum == "Si_"){
		obj=cols[num*6].lastChild;
		obj.selectedIndex=6;
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'green'));
		cols[num*6+2].appendChild(cr_si_2(num,'green'));
		cols[num*6+3].appendChild(cs_def(num,"op3_",a3,'green'));
		cols[num*6+4].style.color='green';
		elt[num*6+4].data=" alors ";
		cols[num*6+4].appendChild(cr_si_1(num,"op4_",'green'));
		cols[num*6+5].style.color='green';
		elt[num*6+5].data=String.fromCharCode(0x2190);
		cols[num*6+5].appendChild(cr_si_1(num,"op5_",'green'));
		lig_type[j]=selnum;
		obj=cols[num*6+1].lastChild;
		obj.selectedIndex=(rech_sel(obj,a1));
		obj=cols[num*6+2].lastChild;
		obj.selectedIndex=(rech_sel(obj,a2));
		obj=cols[num*6+4].lastChild;
		obj.selectedIndex=(rech_sel(obj,a4));
		obj=cols[num*6+5].lastChild;
		obj.selectedIndex=(rech_sel(obj,a5));
	}
	if (selnum == "Si__"){
		obj=cols[num*6].lastChild;
		obj.selectedIndex=7;
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'green'));
		cols[num*6+2].appendChild(cr_si_2(num,'green'));
		cols[num*6+3].appendChild(cs_def(num,"op3_",a3,'green'));
		cols[num*6+4].style.color='green';
		elt[num*6+4].data=" alors ";
		cols[num*6+4].appendChild(cr_si_1(num,"op4_",'green'));
		cols[num*6+5].style.color='green';
		elt[num*6+5].data=String.fromCharCode(0x2190);
		cols[num*6+5].appendChild(cs_def(num,"op5_",a5,'green'));
		lig_type[j]=selnum;
		obj=cols[num*6+1].lastChild;
		obj.selectedIndex=(rech_sel(obj,a1));
		obj=cols[num*6+2].lastChild;
		obj.selectedIndex=(rech_sel(obj,a2));
		obj=cols[num*6+4].lastChild;
		obj.selectedIndex=(rech_sel(obj,a4));
	}
	if (selnum == "Fonc"){
		obj=cols[num*6].lastChild;
		obj.selectedIndex=4;
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'black'));
		cols[num*6+2].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num*6+2].appendChild(cr_f_1(num));
		cols[num*6+3].appendChild(cr_si_1(num,"op3_",'black'));
		lig_type[j]=selnum;
		obj=cols[num*6+1].lastChild;
		obj.selectedIndex=(rech_sel(obj,a1));
		obj=cols[num*6+2].lastChild;
		obj.selectedIndex=(rech_sel(obj,a2));
		obj=cols[num*6+3].lastChild;
		obj.selectedIndex=(rech_sel(obj,a3));
	}
	if (selnum == num){ // ligne d'affectation
		obj=cols[num*6].lastChild;
		obj.selectedIndex=1;
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'black'));
		cols[num*6+2].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num*6+2].appendChild(cr_si_1(num,"op2_",'black'));
		cols[num*6+3].appendChild(cr_opr_1(num,"op3_"));
		cols[num*6+4].appendChild(cr_si_1(num,"op4_",'black'));
		lig_type[j]="Prog";
		obj=cols[num*6+1].lastChild;
		obj.selectedIndex=(rech_sel(obj,a1));
		obj=cols[num*6+2].lastChild;
		obj.selectedIndex=(rech_sel(obj,a2));
		obj=cols[num*6+3].lastChild;
		obj.selectedIndex=(rech_sel(obj,a3));
		obj=cols[num*6+4].lastChild;
		obj.selectedIndex=(rech_sel(obj,a4));
	}
	if (selnum == "Prog_"){ // x=y+cte
		obj=cols[num*6].lastChild;
		obj.selectedIndex=5;
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'black'));
		cols[num*6+2].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num*6+2].appendChild(cr_si_1(num,"op2_",'black'));
		cols[num*6+3].appendChild(cr_opr_1(num,"op3_"));
		cols[num*6+4].appendChild(cs_def(num,"op4_",a4,'black'));
		lig_type[j]="Prog_";
		obj=cols[num*6+1].lastChild;
		obj.selectedIndex=(rech_sel(obj,a1));
		obj=cols[num*6+2].lastChild;
		obj.selectedIndex=(rech_sel(obj,a2));
		obj=cols[num*6+3].lastChild;
		obj.selectedIndex=(rech_sel(obj,a3));
	}
	if (selnum == "Boucle"){ // Boucle <var> variant de <variable> à <variable>
		obj=cols[num*6].lastChild;
		obj.selectedIndex=9;
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'red'));
		cols[num*6+2].style.color='red';
		elt[num*6+2].data=' variant de ';
		cols[num*6+2].appendChild(cr_si_1(num,"op2_",'red'));
		cols[num*6+3].style.color='red';
		elt[num*6+3].data=' a ';
		cols[num*6+3].appendChild(cr_si_1(num,"op3_",'red'));
		cols[num*6+4].style.color='red';
		elt[num*6+4].data='{';
		lig_type[j]="Boucle";
		obj=cols[num*6+1].lastChild;
		obj.selectedIndex=(rech_sel(obj,a1));
		obj=cols[num*6+2].lastChild;
		obj.selectedIndex=(rech_sel(obj,a2));
		obj=cols[num*6+3].lastChild;
		obj.selectedIndex=(rech_sel(obj,a3));
	}
	if (selnum == "Tant que"){ // Boucle <var> variant de <variable> à <variable>
		obj=cols[num*6].lastChild;
		obj.selectedIndex=11;
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'red'));
		cols[num*6+2].appendChild(cr_si_2(num,'red'));
		cols[num*6+3].appendChild(cr_si_1(num,"op3_",'red'));
		cols[num*6+4].style.color='red';
		elt[num*6+4].data='{';
		lig_type[j]="Tant que";
		obj=cols[num*6+1].lastChild;
		obj.selectedIndex=(rech_sel(obj,a1));
		obj=cols[num*6+2].lastChild;
		obj.selectedIndex=(rech_sel(obj,a2));
		obj=cols[num*6+3].lastChild;
		obj.selectedIndex=(rech_sel(obj,a3));
	}
	if (selnum == "}"){ // Boucle <var> variant de <variable> à <variable>
		obj=cols[num*6].lastChild;
		obj.selectedIndex=10;
	}
	if (selnum == "Rect"){ // Rectange
		obj=cols[num*6].lastChild;
		obj.selectedIndex=12;
		lig_type[j]="Rect";
		elt[num*6+1].data="Origine x";
		cols[num*6+1].appendChild(cr_si_1(num,"op1_",'darkviolet'));
		cols[num*6+1].style.color='darkviolet';
		elt[num*6+2].data="y";
		cols[num*6+2].appendChild(cr_si_1(num,"op2_",'darkviolet'));
		cols[num*6+2].style.color='darkviolet';
		elt[num*6+3].data="largeur";
		cols[num*6+3].appendChild(cr_si_1(num,"op3_",'darkviolet'));
		cols[num*6+3].style.color='darkviolet';
		elt[num*6+4].data="hauteur";
		cols[num*6+4].appendChild(cr_si_1(num,"op4_",'darkviolet'));
		cols[num*6+4].style.color='darkviolet';
		elt[num*6+5].data="en";
		cols[num*6+5].appendChild(cr_si_1(num,"op5_",'darkviolet'));
		cols[num*6+5].style.color='darkviolet';
		obj=cols[num*6+1].lastChild;
		obj.selectedIndex=(rech_sel(obj,a1));
		obj=cols[num*6+2].lastChild;
		obj.selectedIndex=(rech_sel(obj,a2));
		obj=cols[num*6+3].lastChild;
		obj.selectedIndex=(rech_sel(obj,a3));
		obj=cols[num*6+4].lastChild;
		obj.selectedIndex=(rech_sel(obj,a4));
		obj=cols[num*6+5].lastChild;
		obj.selectedIndex=(rech_sel(obj,a5));
	}
		num_lig++;
		document.getElementById("nbe").value=num_lig;
		lig_type[num_lig]="";
		lignes[num_lig]=document.createElement("tr");
		for (i=0;i<6;i++){
	 		cols[i+num_lig*6]=document.createElement("td");
			if (i == 0) elt[i+num_lig*6]=cr_select_1(num_lig);
			else elt[i+num_lig*6]=document.createTextNode("");
			cols[i+num_lig*6].appendChild(elt[i+num_lig*6]);
			lignes[num_lig].appendChild(cols[i+num_lig*6]);
		}
        	tablebody.appendChild(lignes[num_lig]);
}

    function start() {
	var n;
	var i;
	if (sql_chp0[0] != undefined){
		n=sql_champ.length;
		for(i=0;i<n;i++){
			declare_nom[t_sql]=sql_champ[i];
			declare_val[t_sql++]='';
		}
		n=tbl_glob.length;
		for(i=0;i<n;i++){
			declare_nom[t_sql]=tbl_glob[i];
			declare_val[t_sql++]='';
		}
	}
	tablebody=document.getElementById("Prog");
	var intitules=new Array("Prog","","","","","");
	j=1; // indice ligne
        // creation des cellules
	lignes=new Array(); // tableau des lignes
	cols=new Array(); // tableau des colonnes;
	elt=new Array(); // tableau des elements
	lignes[0]=document.createElement("tr");
	for (i=0;i<6;i++){
	 	cols[i]=document.createElement("td");
		elt[i]=document.createTextNode(intitules[i]);
		cols[i].appendChild(elt[i]);
		lignes[0].appendChild(cols[i]);
	}
	var nbe=document.createElement("input");
	nbe.name="nbe";
	nbe.id="nbe";
	nbe.type="hidden";
	nbe.value="1";
	cols[1].appendChild(nbe);
        tablebody.appendChild(lignes[0]);
	lignes[1]=document.createElement("tr");
	for (i=0;i<6;i++){
	 	cols[i+6]=document.createElement("td");
		if (i == 0) elt[i+6]=cr_select_1(1);
		else elt[i+6]=document.createTextNode("");
		cols[i+6].appendChild(elt[i+6]);
		lignes[1].appendChild(cols[i+6]);
	}
        tablebody.appendChild(lignes[1]);
    }
