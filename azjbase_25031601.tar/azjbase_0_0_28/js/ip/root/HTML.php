<?php
echo "<!DOCTYPE HTML>\n";
// Modifie par Alexandre Zvenigorosky - 14-10-2009
echo "<html>\n";
echo "<head>\n";
echo "<title>HTML Input</title>\n";
$txt=file_get_contents("../../../liens/root/tables.js");
echo "<script type=\"text/javascript\">\n";
echo $txt."\n";
echo "function getIFrameDocument(aID){\n";
echo "var docFen=window.opener.document;\n";
echo "return docFen.getElementById(aID).contentDocument;\n";
echo "}\n";

echo "function formate(motClef,phrase){\n";
echo "getIFrameDocument('fenetre').execCommand(motClef,false, phrase);\n";
echo "return;\n";
echo "}\n";

echo "function envoyer()\n";
echo "{\n";
echo "if (ts1 < 1){\n";
echo "window.close();\n";
echo "return;\n";
echo "}\n";
echo "var sqla=document.getElementById('txtChamp').value;\n";
echo "formate(\"inserthtml\",\"[htm(\"+sql_tbl[0]+'.'+sqla+\")]\");\n";
echo "window.close();\n";
echo "}\n";
echo "</script>\n";
echo "</head>\n";
echo "<body>\n";
echo "<form name=\"texte\" id=\"texte\" method=\"post\">\n";
echo "<center>\n";
echo "<H2>Zone de saisie &eacute;tendue</H2>\n";
echo "<select id=\"txtChamp\" size=\"6\">\n";
echo "<script>\n";
echo "var i=0;\n";
echo "if (l0 < 1) document.write('<option>Il faut au moins un champ!</option>');\n";
echo "document.write('<option selected>'+sql_chp0[0]+'</option>');\n";
echo "for(i=1;i<ts1;i++){\n";
echo "document.write('<option>'+sql_chp0[i]+'</option>');\n";
echo "}\n";
echo "</script>\n";
echo "</select>\n";
echo "</center>\n";
echo "<BR>&nbsp;&nbsp;<input type=\"submit\" name=\"envVal\" id=\"envVal\" value=\"envoi\" onclick=\"envoyer();\">\n";
echo "</form>\n";
echo "</body>\n";
echo "</html>\n";
?>
