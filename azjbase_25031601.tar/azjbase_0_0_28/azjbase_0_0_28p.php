<?php
// azj_base 0.0.28 (c) 22/03/2016 - Alexandre Zvenigorosky III
// version 12 --> fonction min,max,avg, liste sur un select + doc a jour
// version 14 --> marquage des champs de saisie pour eviter doublon + valeur par defaut pour liste sur un select
// version 15 --> ip --> multiutilisateurs
// version 16 --> multirepertoires de js
// version 17 --> anti sql injection + sous repertoire = username
// version 18 --> submit --> script avec limit de 1 par le script
// version 19 --> plus de limite + fonctions dans entete uniquement
// version 19a --> fonction si(champ,condition,valeur,valeur sinon), [[--> [, pas de <HR> --> seul entete, correspond a ok4=0
// version 19b --> liens html et popup avec pages en php
// version 19c --> saisie unicode
// version 19d --> saisie editor
// version 19e --> prog partie 1
// version 19f --> checkbox+svg noms des champ.azj + champ de connexion
// version 19r --> chemin relatif
// version 20  --> utilisation d'editor
// version 21  --> boucle
// version 22 --> HTML5 input date, datetime, ...
// version 25 --> compatibilité php 7
// version 28 --> fiches.txt
require('verifieHtml.php');
function sqlp($txt){ // corrige ou supprime les caracteres speciaux \t \r \n \->\\ '->''
if (is_numeric($txt)) return $txt;
$z = strlen($txt);
$w = '';
for($x = 0;
$x<$z;
$x++){
$v0 = $txt[$x];
if (($v == "\n") || ($v == "\r") && ($v == "\t")) $v0 = '';
if ($v == "'") $v0 = "\\\'";
if ($v == "\\") $v0 = "\\\\";
if ($v == '"') $v0 = '\"';
$w.=$v0;
}
return $w;
}

function vnom($txt){ // verifie que le nom fourni suit a-z,A-Z,0-9,_
$ok = 0;
$n = 0;
if ($txt <> '') $n = strlen($txt);
if ($n < 1) return 0;
$a = $txt[0];
if (($a >= 'A') && ($a <= 'Z')) $ok = 1;
if (($a >= 'a') && ($a <= 'z')) $ok = 1;
if ($a == '_') $ok1;
$i = 1;
while(($ok) && ($i<$n)){
$a = $txt[$i];
$ok = 0;
if (($a >= 'A') && ($a <= 'Z')) $ok = 1;
if (($a >= 'a') && ($a <= 'z')) $ok = 1;
if (($a >= '0') && ($a <= '9')) $ok = 1;
if ($a == '_') $ok = 1;
$i++;
}
return $ok;
}

function est_num($txt){
$n = 0;
if ($txt <> '') $n = strlen($txt);
if ($n<1) return false;
$i = 0;
$ok = 1;
while(($ok) && ($i<$n)){
$ok = (($txt[$i]>='0') && ($txt[$i]<='9'));
$i++;
}
return $ok;
}

function erreur($txt){
echo '<script type="text/javascript">'."\n";
echo 'alert("'.$txt.'")'."\n";
echo '</script>'."\n";
exit;
}

function attention($txt){
echo '<script type="text/javascript">'."\n";
echo 'alert("'.$txt.'")'."\n";
echo '</script>'."\n";
}

header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date dans le passé
$i = error_reporting(E_ERROR+E_WARNING+E_PARSE+E_CORE_ERROR+E_CORE_WARNING+E_COMPILE_ERROR+E_COMPILE_WARNING);
$chm_os = realpath('./');
$i = strlen($_SERVER['DOCUMENT_ROOT']);
if (substr($_SERVER['DOCUMENT_ROOT'], -1) == '/') $i--;
$chm_web = substr($chm_os, $i);
echo "<!DOCTYPE html>\n<HTML>\n";
echo "<HEAD><TITLE>Creation de masque</TITLE>\n";
echo '<script TYPE="text/javascript" src="editor/barreoutils.js"></script>'."\n";
echo "</HEAD>\n";
echo "<BODY>\n";
echo "<H1>azj_base</H1>\n";
echo '<A HREF="creer06.php">Gestion des tables<A>&nbsp;&nbsp;&nbsp;<A HREF="base_user2.php">Gestion utilisateurs et cr&eacute;ation de base de donn&eacute;es</A>';
echo '&nbsp;&nbsp;&nbsp;<A HREF="table_user1.php">Droits sur les tables<A>&nbsp;&nbsp;&nbsp;';
echo '&nbsp;&nbsp;&nbsp;<A HREF="sauve.php">Sauvegarde/Restauration/Importation<A>&nbsp;&nbsp;&nbsp;';
echo "&nbsp;&nbsp;&nbsp;<A HREF='azjbase_0_0_20.php'>Version sans programme</A>";
echo "&nbsp;&nbsp;&nbsp;<A HREF='feuille_styles.php'>Feuille de styles</A>";
echo "&nbsp;&nbsp;&nbsp;<A HREF='doc/help_azj_base_7.html'>Aide</A><BR><BR>\n";
// recherche des changements de parametres
if (!isset($_POST['srv_1_serveur'])) $_POST['srv_1_serveur'] = 'localhost';
if (!isset($_POST['srv_1_user'])) $_POST['srv_1_user'] = '';
if (!isset($_POST['srv_1_mdp'])) $_POST['srv_1_mdp'] = '';
if (!isset($_POST['srv_1_base'])) $_POST['srv_1_base'] = '';
if (!isset($_POST['srv_1_port'])) $_POST['srv_1_port'] = 3306;
if (!isset($_POST['file_etat'])) $_POST['file_etat'] = '';
$t_0['srv_1_serveur'] = sqlp($_POST['srv_1_serveur']);
$t_0['srv_1_user'] = sqlp($_POST['srv_1_user']);
$t_0['srv_1_mdp'] = sqlp($_POST['srv_1_mdp']);
$t_0['srv_1_base'] = sqlp($_POST['srv_1_base']);
$t_0['file_etat'] = sqlp($_POST['file_etat']);
$t_0['old_file_etat'] = sqlp($_POST['old_file_etat']);
$t_0['srv_1_port'] = $_POST['srv_1_port'];
if (!$t_0['srv_1_serveur']) $t_0['srv_1_serveur'] = 'localhost';
echo '<FORM NAME="azjbase" ACTION="azjbase_0_0_28p.php" METHOD="POST">'."\n";
echo '<TABLE BORDER="0" CELLPADDING="3"><TR>';
echo '<TR><TD>Serveur:</TD><TD><INPUT TYPE="TEXT" NAME="srv_1_serveur" SIZE="16" MAXLENGTH="16" VALUE="'.$t_0['srv_1_serveur'].'"></TD>';
echo '<TD>Utilisateur:</TD><TD><INPUT TYPE="TEXT" NAME="srv_1_user" SIZE="16" MAXLENGTH="16" VALUE="'.$t_0['srv_1_user'].'"></TD>';
echo '<TD>Mot de passe:</TD><TD><INPUT TYPE="PASSWORD" NAME="srv_1_mdp" SIZE="16" MAXLENGTH="16" VALUE="'.$t_0['srv_1_mdp'].'" ></TD><TR>';
echo '<TR><TD>Base de donn&eacute;es:</TD><TD><INPUT TYPE="TEXT" NAME="srv_1_base" SIZE="24" MAXLENGTH="24" VALUE="'.$t_0['srv_1_base'].'" ></TD>';
echo '<TR><TD>Port:</TD><TD><INPUT TYPE="NUMBER" NAME="srv_1_port" SIZE="24" MAXLENGTH="24" VALUE="'.$t_0['srv_1_port'].'" ></TD>';
echo '<TD>Nom du formulaire:</TD><TD><INPUT TYPE="TEXT" NAME="file_etat" SIZE="24" MAXLENGTH="24" VALUE="'.$t_0['file_etat'].'" ></TD>';
echo '<TD>Feuille de style:</TD><TD><INPUT TYPE="TEXT" NAME="feuille_style" SIZE="24" MAXLENGTH="24" VALUE="'.$_POST['feuille_style'].'"></TD></TR></TABLE>';
echo '<INPUT TYPE=HIDDEN NAME="old_file_etat" SIZE="24" MAXLENGTH="24" VALUE="'.$t_0['file_etat'].'" >'."\n";
echo '<INPUT TYPE=SUBMIT NAME="Demander" VALUE="Demander">';
$a = $t_0['srv_1_mdp'];
echo '<BR>'.$chemin.'<BR>';
if ((stripos($a, ';')) || ($a[0] == ';'))
erreur("Le mot de passe ne peut comporter de ;!");
$a = $t_0['srv_1_base'];
if ((stripos($a, ';')) || ($a[0] == ';'))
erreur("Le nom de la base ne peut comporter de ;!");
if (!$t_0['srv_1_user']) exit; // pas d'utilisateur
if (!$a) exit; // pas de nom de base
vnom($a) or erreur("Erreur: nom de base invalide!");
$ok = (strlen($_POST['srv_1_serveur'])>2) && (strlen($_POST['srv_1_serveur'])>2);
if (!$ok) die("Veuillez rectifier les informations de login?");
// ouverture de la base
$conn = new mysqli($t_0['srv_1_serveur'], $t_0['srv_1_user'], $t_0['srv_1_mdp'], $t_0['srv_1_base'], $t_0['srv_1_port']) or erreur("Erreur:ouverture de session Mysql!");
$ts[1] = 0; // pour tables.js
$rep0 = $t_0['srv_1_user'];
if ($rep0){
$rep_base2 = $chm_web.'/liens/'.$rep0;
$rep_base3 = $chm_web.'/js/ip/'.$rep0;
$rep_base = $chm_os.'/liens/'.$rep0;
if (!is_dir($chm_os.'/js/ip/'.$rep0)){ // creation du sous repertoire js
$file_base[1] = 'Champ.php';
$file_base[2] = 'ListChamp.php';
$file_base[3] = 'Texte.php';
$file_base[4] = 'Liste.php';
$file_base[5] = 'Forme.html';
$file_base[6] = 'Fonctions.php';
$file_base[7] = 'ZoneTexte.php';
$file_base[8] = 'Si.php';
$file_base[9] = 'Liens.php';
$file_base[10] = 'Readme.txt';
$file_base[11] = 'ExtText.php';
$file_base[12] = 'ExtArea.php';
$file_base[13] = 'HTML.php';
$file_base[14] = 'Case.php';
$file_base[15] = 'Mode.html';
$file_base[16] = 'Div.html';
if (!is_dir($rep_base)) mkdir($rep_base, 0755) or erreur('Erreur pendant la cr&eacute;ation du r&eacute;pertoire des fichiers de sauvegardes');
if (!is_dir($chm_os.'/js/ip/'.$rep0)) mkdir($chm_os.'/js/ip/'.$rep0, 0755) or erreur('Erreur pendant la creation du rep des plugins');
for($i = 1;$i<17;$i++){
$a = $chm_os.'/js/'.$file_base[$i];
$rq = fopen($a, "r") or erreur('Erreur ouverture fichier '.$a.' en lecture!');
$formulaire = fread($rq, 32768);
$n = strlen($formulaire);
if ($n >= 32768)
erreur("Erreur: fichier modele trop long!");
$formulaire = str_replace('IPADDR', $rep0, $formulaire);
$formulaire = str_replace('ADDRWEB', $chm_web, $formulaire);
$n = strlen($formulaire);
fclose($rq);
$a = $chm_os.'/js/ip/'.$rep0.'/'.$file_base[$i];
$rq = fopen($a, "w") or erreur('Erreur ouverture fichier '.$a.' en &eacute;criture!');
$i0 = fwrite($rq, $formulaire, $n);
if ($i0 != $n)
erreur('Erreur: &eacute;criture incomplete pour '.$a.'!');
fclose($rq);
} // gestion des droits de js...?
$a=$chm_os.'/js/rechLien.php';
$rq=fopen($a,'r') or erreur("Erreur ouverture rechLien.php!".$a.' en lecture');
$formulaire=fread($rq,32768);
$n=strlen($formulaire);
fclose($rq);
if ($n>=32768) erreur("Erreur fichier trop long!".$a);
$formulaire = str_replace('IPADDR', $rep0, $formulaire);
$formulaire = str_replace('ADDRWEB', $chm_web, $formulaire);
$n = strlen($formulaire);
$a=$chm_os.'/liens/'.$rep0.'/rechLien.php';
$rq = fopen($a, "w") or erreur('Erreur ouverture fichier '.$a.' en &eacute;criture!');
$i0 = fwrite($rq, $formulaire, $n);
if ($i0 != $n)
erreur('Erreur: &eacute;criture incomplete pour '.$a.'!');
fclose($rq);
$formulaire = '';
}
} else
erreur("Vous devez saisir un nom d'utilisateur valide.");
if ($t_0['file_etat']){
$ok = vnom($t_0['file_etat']) or erreur("Erreur:nom de formulaire incorrect!");
}
if (!isset($_POST['limit1'])) $_POST['limit1'] = 50;
$sql_limit0 = 0+$_POST['limit0'];
$sql_limit1 = 0+$_POST['limit1'];
if ($sql_limit1 <1) $sql_limit1 = 1;
if ($sql_limit1 >999) $sql_limit1 = 999;
if ($_POST['Avant']){
$sql_limit0-=$sql_limit1;
//$sql_limit1-=$i;
if ($sql_limit0 <0) $sql_limit0 = 0;
}
if ($_POST['Apres']){
$sql_limit0+=$sql_limit1;
}
$nsel = 0; // nbe de complement de fonction sel
if ($_POST['formulaire']) $formulaire = str_replace("\\", "", $_POST['formulaire']);
// sauvegarde du formulaire
if (($_POST['SauveF']) && (strlen($t_0['file_etat'])>1)){
if (strlen($_POST['formulaire'])>3){
$rq = fopen($rep_base.'/'.$t_0['file_etat'].".html", "w");
fwrite($rq, $formulaire);
fclose($rq);
}
}
$ok1 = 0;
if (($t_0['file_etat'] != $t_0['old_file_etat']) && (strlen($t_0['file_etat'])>1)){
$ok1 = 1;
// voulez-vous sauver ....
}
if (($_POST['ChargeF']) && (strlen($t_0['file_etat'])>1)) $ok1 = 1;
if ($ok1){
if (file_exists($rep_base."/".$t_0['file_etat'].".html")){
$rq = fopen($rep_base.'/'.$t_0["file_etat"].".html", "r");
$formulaire = fread($rq, 32768);
fclose($rq);
}
else $formulaire = '';
}
// liste des tables
if (($t_0['file_etat']) && (file_exists($rep_base.'/'.$t_0['file_etat'].'.azj')) && ($t_0['file_etat'] != $t_0['old_file_etat'])){
include $rep_base.'/'.$t_0['file_etat'].".azj";
$ok5 = 1; // par include
} else {
$tbl_table = $_POST['tbl_table'];
$tbl_maitre = $_POST['tbl_maitre'];
$ok5 = 0;
}
if ($ok){
echo "<HR>\n";
$result = $conn->query("SHOW TABLES");
$ok = 0;
$l = 0; // nbe de choix de tables - $p boucle courante
$i1 = -1; // table maitre choisie
$ts[0] = 0; // $tl[]:debut des champs choisis de la table+fin, tl_tbl:champs choisis
$tj[0] = ''; // type pour detection de jointure
$tjl[0] = ''; // liste de jointure possible
$tjl0 = 0; // pointeur dans tjl
echo '<TABLE BORDER="0"><TR><TD>';
echo "Tables:</TD><TD><SELECT MULTIPLE NAME='tbl_table[]' SIZE='5'>";
while (($result) && ($ligne = $result->fetch_row())){
$ok = 1;
if ($ligne[0] == $tbl_table[$l]){
if ($tbl_maitre == $ligne[0]) $i1 = $l;
echo "<OPTION SELECTED>".$tbl_table[$l++]."</OPTION>";
}
else echo "<OPTION>".$ligne[0]."</OPTION>";
}
echo "</SELECT>\n</TD><TD>Table maitre</TD><TD><SELECT NAME='tbl_maitre' SIZE=3>";
for($i0 = 0;
$i0<$l;
$i0++){
if ($tbl_maitre == $tbl_table[$i0]) echo '<OPTION SELECTED>'.$tbl_maitre.'</OPTION>';
else echo '<OPTION>'.$tbl_table[$i0].'</OPTION>';
}
echo '</SELECT></TD></TR></TABLE>';
if ($i1>0){
$a = $tbl_table[0];
$tbl_table[0] = $tbl_table[$i1];
$tbl_table[$i1] = $a;
}
echo "<BR>\n";
}
if ($l == 0) $ok = 0;
$l0 = 0; // indice dans ts
$ok = 0;
$k = 0; // table de description de tous les champs
$sep2 = 0; // au moins une clause dans le where (pour join)
for($p = 0;
$p<$l;
$p++){
// structure des tables choisies
echo "<TABLE BORDER='0' CELLSPACING='12'><TR>";
$clause = "DESCRIBE ".$tbl_table[$p];
$result = $conn->query(sqlp($clause));
$t_sel_name = "tbl_champ".$p;
$n = 0; // nbe de champ de la table
$ts[$p] = $l0;
if (!$ok5) $t_champ = $_POST[$t_sel_name];
$j = 0; // tous les champs selectionnes de la table
echo "<TD>".$tbl_table[$p]."</TD><TD><SELECT MULTIPLE NAME='".$t_sel_name."[]' SIZE='5'>";
while (($result) && ($ligne = $result->fetch_row())){
$ok = 1;
for($i = 0;$i<6;$i++) $tbl_c[$k++] = $ligne[$i];
	if ($ligne[3] == 'PRI') $tidx[$p] = $ligne[0]; // nom de l'index primaire de la table
	if ($ligne[0] == $t_champ[$j]) {
	echo "<OPTION SELECTED>".$ligne[0]."</OPTION>";
	$tj[$l0] = $ligne[1];
	$tl_tbl[$l0++] = $ligne[0];
	$j++;
	}
	else echo "<OPTION>".$ligne[0]."</OPTION>";
	$n++;
}
echo "</SELECT></TD>\n";
if (!$tidx[$p]) echo "Attention:la table n'a pas de clef primaire";
$clause = "SHOW CREATE TABLE ".$tbl_table[$p];
$result = $conn->query($clause) or die("Erreur:recherche commentaires!".$clause);
$ligne = $result->fetch_row();
$j0 = stripos($ligne[1], '(');
if (!$j0) die("Erreur:table mal formée!".$ligne[1]);
$j0++;
$ligne[1] = substr($ligne[1], $j0);
$j1 = 0;
for($i = 0;
$i<$n;
$i++){
$j2 = stripos($ligne[1], ',', $j1);
$txt = substr($ligne[1], $j1, $j2-$j1);
$j3 = stripos($txt, "COMMENT '");
if ($j3) $tbl_c[$i*6+5] = substr($txt, $j3+9, -1);
$j1 = $j2+1;
}
} // ($t_0['nom_table'])
// affichage du tableau des champs
echo "<TD><TABLE BORDER='1'>";
echo "<TR><TD>Nom du champ</TD><TD> Type </TD><TD> Null? </TD><TD> Index </TD><TD> Valeur Init </TD><TD> Autres </TD></TR>\n";
for($i = $ts[$p];
$i<$ts[$p]+$n;
$i++){
echo "<TR>\n";
for ($i0 = 0;
$i0<6;
$i0++) echo "<TD>".$tbl_c[$i*6+$i0]."</TD>";
echo "<TR>\n";
}
echo "</TABLE></TD></TR></TABLE><HR>\n";
// sauvegarde des tables et des champs
if (($t_0['file_etat']) && ($t_0['file_etat'] == $t_0['old_file_etat'])){
$r = "<?php\n";
for($i = 0;
$i<$l;
$i++) $r.='$tbl_table['.$i.']=\''.$tbl_table[$i]."';\n";
for($i = 0;
$i<$l0;
$i++) $r.='$t_champ['.$i.']=\'' . $tl_tbl[$i] . "';\n";
$r.='$tbl_maitre=\'' . $tbl_maitre . "';\n?>\n";
$rq = fopen($rep_base . '/' . $t_0['file_etat'] . ".azj", "w");
fwrite($rq, $r);
fclose($rq);
}
//detection type formulaire:un input ...
$ok2 = 0; // pas de <form
$ok11 = 0;
if (stripos($formulaire, '<form ') !== false)
    $ok2 = 1;
else {
    if (stripos($formulaire, '<input ') !== false)
        $ok11 = 1;
    if (stripos($formulaire, '<textarea') !== false)
        $ok11 = 1;
    if (stripos($formulaire, '<select ') !== false)
        $ok11 = 1;
    if (stripos($formulaire, '[sel(') !== false)
        $ok11 = 1;
    if (stripos($formulaire, '[sai(') !== false)
        $ok11 = 1;
    if (stripos($formulaire, '[txt(') !== false)
        $ok11 = 1;
    if (stripos($formulaire, '[htm(') !== false)
        $ok11 = 1;
    if ($ok11) {
        $formulaire = ' <form method="POST" name="' . $t_0['file_etat'] . '" action="">' . $formulaire;
        $ok2 = 1;
    }
}
if ($ok2) {
    if (!stripos($formulaire, '</form>'))
        $formulaire.="</form>";
    if ((!stripos($formulaire, '"submit\\"')) && (!stripos($formulaire, "submit")))
        $formulaire = str_replace('</form', '<BR><input type="submit" name="saisie" value="saisie">' . "\n</form\n", $formulaire);
}
$ind_form2 = stripos($formulaire, '"submit');
$n_tbl_var = 3;
$tbl_var[1] = 'time()';
$tbl_var[2] = '$valide'; // validation de formulaire > 0
$ok6 = strpos($formulaire, '[log]');
if ($ind_form2) {
    $q = 1;
    $l2 = $ts[1];
    $tbl_var[0] = '$ndeb';
    if ($ok6 !== false) {
        $tbl_var[1] = '$srv_log';
    }
} else {
    $q = $p; // remplacant de $l pour les formulaires
    $l2 = $l0;
    $tbl_var[0] = '$num_result';
}
if ($l > 0) {
    $ts[$l] = $l0;
    $clause = "SELECT";
}
$sep = 0; // pour detection separateur apres le premier
for ($p = 0; $p < $q; $p++) {
    for ($i = $ts[$p]; $i < $ts[$p + 1]; $i++) {
        if ($sep)
            $clause.=",";
        $sep = 1;
        if ($l > 1)
            $clause.=" " . $tbl_table[$p] . "." . $tl_tbl[$i];
        else
            $clause.=" " . $tl_tbl[$i];
    }
}
$m0 = 0; // place du FROM
if ($l > 0) {
    $m0 = strlen($clause);
    $clause.=" FROM " . $tbl_table[0];
}
for ($p = 1; $p < $q; $p++)
    $clause.=", " . $tbl_table[$p];
$j = 0; // compteur de champs[]
if ($l > 0)
    echo "<TABLE BORDER='1'>";
for ($p = 0; $p < $q; $p++) {
    for ($i = $ts[$p]; $i < $ts[$p + 1]; $i++) {
        $marq[$i] = 0; // marquage
        echo "<TR><TD>" . $tl_tbl[$i];
        if ($l > 1)
            echo "." . $tbl_table[$p];
        $t_sel_cond_i = "cond_" . $p . '_' . $i;
        $t_sel_cond[$i] = $_POST[$t_sel_cond_i];
        if ($l > 1)
            $champs[$j++] = $tbl_table[$p] . '.' . $tl_tbl[$i];
        else
            $champs[$j++] = $tl_tbl[$i];
        echo "</TD><TD>";
        if ($t_sel_cond[$i] <> '') {
            if ($sep2 == 0)
                $clause.=' WHERE ';
            $sep2 = 1;
            if ($l > 1)
                $clause.=$tbl_table[$p] . ".";
            $clause.=$tl_tbl[$i] . " " . $t_sel_cond[$i];
        }
        echo "<SELECT NAME='" . $t_sel_cond_i . "'>";
        if ($t_sel_cond[$i] == '')
            echo "<OPTION SELECTED></OPTION>";
        else
            echo "<OPTION></OPTION>";
        if ($t_sel_cond[$i] == 'LIKE')
            echo "<OPTION SELECTED>LIKE</OPTION>";
        else
            echo "<OPTION>LIKE</OPTION>";
        if ($t_sel_cond[$i] == '=')
            echo "<OPTION SELECTED>=</OPTION>";
        else
            echo "<OPTION>=</OPTION>";
        if ($t_sel_cond[$i] == '>')
            echo "<OPTION SELECTED>></OPTION>";
        else
            echo "<OPTION>></OPTION>";
        if ($t_sel_cond[$i] == '>=')
            echo "<OPTION SELECTED>>=</OPTION>";
        else
            echo "<OPTION>>=</OPTION>";
        if ($t_sel_cond[$i] == '<')
            echo "<OPTION SELECTED><</OPTION>";
        else
            echo "<OPTION><</OPTION>";
        if ($t_sel_cond[$i] == '<=')
            echo "<OPTION SELECTED><=</OPTION>";
        else
            echo "<OPTION><=</OPTION>";
        if ($t_sel_cond[$i] == '<>')
            echo "<OPTION SELECTED><></OPTION>";
        else
            echo "<OPTION><></OPTION>";
        if ($t_sel_cond[$i] == 'IS NULL')
            echo "<OPTION SELECTED>IS NULL</OPTION>";
        else
            echo "<OPTION>IS NULL</OPTION>";
        if ($t_sel_cond[$i] == 'IS NOT NULL')
            echo "<OPTION SELECTED>IS NOT NULL</OPTION>";
        else
            echo "<OPTION>IS NOT NULL</OPTION>";
        if ($t_sel_cond[$i] == 'BETWEEN')
            echo "<OPTION SELECTED>BETWEEN</OPTION>";
        else
            echo "<OPTION>BETWEEN</OPTION>";
        if ($t_sel_cond[$i] == 'NOT BETWEEN')
            echo "<OPTION SELECTED>BETWEEN</OPTION>";
        else
            echo "<OPTION>BETWEEN</OPTION>";
        echo "</SELECT>\n";
        $a = $t_sel_cond[$i];
        if (($a == 'LIKE') || ($a == '=') || ($a == '>') || ($a == '>=') || ($a == '<') || ($a == '<=') || ($a == '<>') || ($a == 'BETWEEN')) { // premier complement
            $t_sel_name = 't_sel_testa' . $i;
            $t_sel_testa[$i] = $_POST[$t_sel_name];
            $clause.=" '" . $t_sel_testa[$i] . "'";
            echo "&nbsp;&nbsp;<INPUT NAME='" . $t_sel_name . "' TYPE='TEXT' VALUE='" . $t_sel_testa[$i] . "'SIZE='16' MAXLENGTH='16'>";
        }
        if (($a == 'BETWEEN') || ($a == 'NOT BETWEEN')) {
            echo " AND ";
            $clause.=" AND ";
            $t_sel_name = 't_sel_testb' . $i;
            $t_sel_testb[$i] = $_POST[$t_sel_name];
            $clause.="'" . $t_sel_testb[$i] . "'";
            echo "&nbsp;&nbsp;<INPUT NAME='" . $t_sel_name . "' TYPE='TEXT' VALUE='" . $t_sel_testb[$i] . "'SIZE='16' MAXLENGTH='16'>";
            if ($t_sel_testb[$i] < $t_sel_testa[$i]) {
                $j0 = $t_sel_testa[$i];
                $t_sel_testa[$i] = $t_sel_testb[$i];
                $t_sel_testb[$i] = $j0;
            }
        }
        $j0 = $i + 1;
        if (($sep2) && ($j0 < $l0) && ($_POST['t_sel_cond' . $j0] <> '')) {
            $t_sel_name = "sel_log" . $i;
            $t_sel_log[$i] = $_POST[$t_sel_name];
            $clause.=" " . $t_sel_log[$i] . " ";
            echo "&nbsp;&nbsp;<SELECT NAME='" . $t_sel_name . "'>";
            if ($t_sel_log[$i] == 'AND')
                echo "<OPTION SELECTED>AND</OPTION>";
            else
                echo "<OPTION>AND</OPTION>";
            if ($t_sel_log[$i] == 'OR')
                echo "<OPTION SELECTED>OR</OPTION>";
            else
                echo "<OPTION>OR</OPTION>";
            if ($t_sel_log[$i] == 'XOR')
                echo "<OPTION SELECTED>XOR</OPTION>";
            else
                echo "<OPTION>XOR</OPTION>";
            echo "</SELECT>\n";
        }
        echo "</TD></TR>";
    }
}
echo "</TABLE>\n";
// recherche des jointures:meme type de champ
if (($l > 1) && ($l0 > 0)) {
    for ($k = 0; $k < $ts[1]; $k++) {
        $k0 = $tjl0;
        for ($i = 1; $i < $l; $i++) {
            for ($j = $ts[$i]; $j < $ts[$i + 1]; $j++) {
                if ($tj[$k] == $tj[$j]) {
                    if ($tjl0 == $k0)
                        $tjl[$tjl0++] = '';
                    $tjl[$tjl0++] = $tbl_table[$i] . "." . $tl_tbl[$j];
                }
            }
        }
        if ($tjl0 > $k0) {
            echo "<BR><U>Jointures</U><BR>";
            if (!$k0)
                echo '<TABLE BORDER="1">' . "\n";
            $t_sel_name = "joint" . $k;
            echo "<TR><TD>" . $tbl_table[0] . "." . $tl_tbl[$k] . '</TD><TD> = <SELECT NAME="' . $t_sel_name . '">' . "\n";
            for ($i = $k0; $i < $tjl0; $i++) {
                if ($tjl[$i] == $_POST[$t_sel_name]) {
                    if ($i > $k0) {
                        if ($sep2)
                            $clause.=" AND " . $tbl_table[0] . "." . $tl_tbl[$k] . "=" . $tjl[$i];
                        else
                            $clause.=' WHERE ' . $tbl_table[0] . "." . $tl_tbl[$k] . "=" . $tjl[$i];
                        $sep2 = 1;
                    }
                    echo '<OPTION SELECTED>' . $tjl[$i] . '</OPTION>' . "\n";
                } else
                    echo "<OPTION>" . $tjl[$i] . "</OPTION>";
            }
            echo "</SELECT></TD></TR>\n";
        }
        if ($k0 > 1)
            echo "</TABLE><BR>\n";
    }
}
$clause1 = $clause; // pour suppression
$clause2 = $clause; // pour formulaire;
if ((!$ind_form2) && ($clause)) { // traitement de LIMIT
    echo " <BR><BR> LIMIT ";
    $clause.=" LIMIT ";
    // if ($sql_limit0 == $sql_limit1) $sql_limit1+=49;
    echo '<INPUT TYPE="submit" NAME="Avant" Value="Pr&eacute;c&eacute;dents">&nbsp;&nbsp;&nbsp;';
    echo " <INPUT TYPE='NUMBER' NAME='limit0' VALUE='" . $sql_limit0 . "'> , ";
    echo " <INPUT TYPE='NUMBER' NAME='limit1' VALUE='" . $sql_limit1 . "'> , ";
    echo '&nbsp;&nbsp;&nbsp;<INPUT TYPE="submit" NAME="Apres" Value="Suivants"><BR>';
    $clause.=$sql_limit0 . "," . $sql_limit1;
} // traitement de LIMIT
// Prog - 20e
if (file_exists($rep_base . '/tables.js'))
    $txt = file_get_contents($rep_base . '/tables.js');
else
    $txt = '';
echo "<script type=\"text/javascript\">\n";
echo $txt . "\n";
echo "</script>\n";
echo '<BR><TABLE BORDER="1"><tbody id="Prog">';
echo '</tbody>';
echo '</TABLE>';
echo '<script type="text/javascript" src="' . $chm_web . '/js/prog5.js"></script>';
echo '<script type="text/javascript">';
echo 'start()';
echo '</script>';
for ($i = 0; $i < $l0; $i++)
    $marque[$i] = 0; // non saisie <-- vient du script ou 0
$bcl = 0; // nbe de boucles imbriquées à fermer à la fin du script
// traduction du programme
$nbe = $_POST['nbe'];
$t = ''; // programme
$s = ''; // equiv prog
// recherche element graphique et insertion alors d'un canvas outils de 800*600
$ok7 = 0;
$i = 1;
while (($i < $nbe) && (!$ok7)) {
    if ($_POST['type_' . $i] == 'Rect')
        $ok7 = 1;
    if ($_POST['type_' . $i] == 'Arc')
        $ok7 = 1;
    if ($_POST['type_' . $i] == 'Ligne')
        $ok7 = 1;
    if ($_POST['type_' . $i] == 'Transforme')
        $ok7 = 1;
    if ($_POST['type_' . $i] == 'Quadratic')
        $ok7 = 1;
    if (!$ok7)
        $i++;
}
if ($i < $nbe) {
    if ($ind_form2)
        $t.='if ($req) ';
    $t.='echo \'<canvas id="graphe" Height="800" Width="600"></canvas>\'."\n";' . "\n";
}
if ($t_0['file_etat'] != $_POST['old_file_etat']) {
    $a = $rep_base . '/' . $t_0['file_etat'] . ".js";
    if ((file_exists($a)) && (filesize($a) > 5))
        echo '<script type="text/javascript" src="' . $rep_base2 . '/' . $t_0['file_etat'] . '.js"></script>' . "\n";
}
else {
    for ($i = 1; $i <= $nbe - 1; $i++) {
        $a = $_POST['type_' . $i];
        $a1 = $_POST['op1_' . $i];
        $a2 = $_POST['op2_' . $i];
        $a3 = $_POST['op3_' . $i];
        $a4 = $_POST['op4_' . $i];
        $a5 = $_POST['op5_' . $i];
        $s.='prg(\'' . $a . '\',\'' . $a1 . '\',\'' . $a2 . '\',\'' . $a3 . '\',\'' . $a4 . '\',\'' . $a5 . "');\n";
        if ($ind_form2) {
            if ($a1 == '$num_result')
                $a1 = $ndeb;
            if ($a2 == '$num_result')
                $a2 = $ndeb;
            if ($a3 == '$num_result')
                $a3 = $ndeb;
            if ($a4 == '$num_result')
                $a4 = $ndeb;
            if ($a5 == '$num_result')
                $a5 = $ndeb;
        }
        $j = $j0 = 0;
        $okp = 1;
        while (($okp) && ($j < $l)) {
            while (($okp) && ($j0 < $l0)) {
                if ($a1 == '[' . $tbl_table[$j] . '.' . $tl_tbl[$j0] . ']')
                    $okp = 0;
                else
                    $j0++;
            }
            if ($okp)
                $j++;
        }
        if (!$okp)
            $a1 = '$ligne[' . $j0 . ']';
        elseif (($a1 == $tbl_var[0]) || ($a1 == $tbl_var[1]))
            erreur("Erreur:Variable " . $a1 . " en lecture seule!");
        elseif ($a1 == '$valide')
            $i = $i + 0;
        else
            $a1 = '$_1' . $a1;
        $elt2 = $elt3 = $elt4 = $elt5 = 0;
        $j = $j0 = 0;
        $okp = 1;
        while (($okp) && ($j < $l)) {
            while (($okp) && ($j0 < $l0)) {
                if ($a2 == '[' . $tbl_table[$j] . '.' . $tl_tbl[$j0] . ']')
                    $okp = 0;
                else
                    $j0++;
            }
            if ($okp)
                $j++;
        }
        if (!$okp)
            $a2 = '$ligne[' . $j0 . ']';
        elseif (($a2 == $tbl_var[0]) || ($a2 == $tbl_var[1]))
            $i = $i + 0;
        elseif ($a2 == '$valide')
            $i = $i + 0;
        else
            $elt2 = 1;
        $j = $j0 = 0;
        $okp = 1;
        while (($okp) && ($j < $l)) {
            while (($okp) && ($j0 < $l0)) {
                if ($a3 == '[' . $tbl_table[$j] . '.' . $tl_tbl[$j0] . ']')
                    $okp = 0;
                else
                    $j0++;
            }
            if ($okp)
                $j++;
        }
        if (!$okp)
            $a3 = '$ligne[' . $j0 . ']';
        elseif (($a3 == $tbl_var[0]) || ($a3 == $tbl_var[1]))
            $i = $i + 0;
        elseif ($a3 == '$valide')
            $i = $i + 0;
        else
            $elt3 = 1;
        $j = $j0 = 0;
        $okp = 1;
        while (($okp) && ($j < $l)) {
            while (($okp) && ($j0 < $l0)) {
                if ($a4 == '[' . $tbl_table[$j] . '.' . $tl_tbl[$j0] . ']')
                    $okp = 0;
                else
                    $j0++;
            }
            if ($okp)
                $j++;
        }
        if (!$okp)
            $a4 = '$ligne[' . $j0 . ']';
        elseif (($a4 == $tbl_var[0]) || ($a4 == $tbl_var[1]))
            $i = $i + 0;
        elseif ($a4 == '$valide')
            $i = $i + 0;
        else
            $elt4 = 1;
        $j = $j0 = 0;
        $okp = 1;
        while (($okp) && ($j < $l)) {
            while (($okp) && ($j0 < $l0)) {
                if ($a5 == '[' . $tbl_table[$j] . '.' . $tl_tbl[$j0] . ']')
                    $okp = 0;
                else
                    $j0++;
            }
            if ($okp)
                $j++;
        }
        if (!$okp)
            $a5 = '$ligne[' . $j0 . ']';
        elseif (($a5 == $tbl_var[0]) || ($a5 == $tbl_var[1]))
            $i = $i + 0;
        elseif ($a5 == '$valide')
            $i = $i + 0;
        else
            $elt5 = 1;
        if ($a == 'Def') {
            if (!is_numeric($a3))
                $a3 = '\'' . sqlp($a3) . '\'';
            $t.=$a1 . '=' . $a3 . ";\n";
            $tbl_var[$n_tbl_var++] = $a1;
        }
        if ($a == '=') {
            if ($elt1)
                $a1 = '$_1' . $a1;
            if (!is_numeric($a3))
                $a3 = '\'' . sqlp($a3) . '\'';
            $t.=$a1 . '=' . $a3 . ";\n";
        }
        if ($a == 'Si') {
            if ($elt3)
                $a3 = '$_1' . $a3;
            if ($elt4)
                $a4 = '$_1' . $a4;
            if ($elt5)
                $a5 = '$_1' . $a5;
            if ($a2 == '=')
                $a2 = '==';
            if ($a2 == '~')
                $t.='if (stripos(' . $a1 . ',' . $a3 . ') ' . $a4 . '=' . $a5 . ";\n";
            else
                $t.='if (' . $a1 . $a2 . $a3 . ') ' . $a4 . '=' . $a5 . ";\n";
        }
        if ($a == 'Si_') {
            if (!is_numeric($a3))
                $a3 = '\'' . sqlp($a3) . '\'';
            if ($elt4)
                $a4 = '$_1' . $a4;
            if ($elt5)
                $a5 = '$_1' . $a5;
            if ($a2 == '=')
                $a2 = '==';
            if ($a2 == '~')
                $t.='if (stripos(' . $a1 . ',' . $a3 . ') ' . $a4 . '=' . $a5 . ";\n";
            else
                $t.='if (' . $a1 . $a2 . $a3 . ') ' . $a4 . '=' . $a5 . ";\n";
        }
        if ($a == 'Si__') {
            if (!is_numeric($a3))
                $a3 = '\'' . sqlp($a3) . '\'';
            if (!is_numeric($a5))
                $a5 = '\'' . sqlp($a5) . '\'';
            if ($elt4)
                $a4 = '$_1' . $a4;
            if ($a2 == '=')
                $a2 = '==';
            if ($a2 == '~')
                $t.='if (stripos(' . $a1 . ',' . $a3 . ') ' . $a4 . '=' . $a5 . ";\n";
            else
                $t.='if (' . $a1 . $a2 . $a3 . ') ' . $a4 . '=' . $a5 . ";\n";
        }
        if ($a == 'Fonc') {
            if ($elt3)
                $a3 = '$_1' . $a3;
            if ($a2 == 'Id')
                $t.=$a1 . '=' . $a3 . ";\n";
            elseif ($a2 == 'Ent')
                $t.=$a1 . '=(int)' . $a3 . ";\n";
            elseif ($a2 == 'Long')
                $t.=$a1 . '=strlen(' . $a3 . ");\n";
            elseif ($a2 == 'Frac')
                $t.=$a1 . '=' . $a3 . '- (int)' . $a3 . ";\n";
            elseif ($a2 == 'Log')
                $t.='if (' . $a3 . '>0) ' . $a1 . '=log(' . $a3 . ");\n else " . $a1 . '=\'\'' . ";\n";
            elseif ($a2 == 'Inv')
                $t.='if (' . $a3 . '!=0) ' . $a1 . '=1/' . $a3 . ";\n else " . $a1 . '=\'\'' . ";\n";
            elseif ($a2 == 'sqrt')
                $t.='if (' . $a3 . '>0) ' . $a1 . '=sqrt(' . $a3 . ");\n else " . $a1 . '=\'\'' . ";\n";
            elseif ($a2 == 'Type') {
                $t.='if (is_numeric(' . $a3 . ')) ' . $a1 . '=\'Nombre\'' . ";\n";
                $t.='elseif (is_int(' . $a3 . ')) ' . $a1 . '=\'Entier\'' . ";\n";
                $t.='else ' . $a1 . '=\'Chaine\'' . ";\n";
            } elseif ($a2 == 'cos')
                $t.=$a1 . '=cos(' . $a3 . ');' . "\n";
            elseif ($a2 == 'sin')
                $t.=$a1 . '=sin(' . $a3 . ");\n";
            elseif ($a2 == 'tan')
                $t.=$a1 . '=tan(' . $a3 . ");\n";
            else
                $t.=$a2 . '(' . $a3 . ");\n";
        }
        if (is_numeric($a)) {
            if ($elt2)
                $a2 = '$_1' . $a2;
            if ($elt4)
                $a4 = '$_1' . $a4;
            if (($a3 == '\\') || ($a3 == '/') || ($a3 == '%')) {
                $t.='if (' . $a4 . ' == 0) ' . $a1 . '=0;' . "\n"; // par convention
                if ($a3 == '\\')
                    $t.='else ' . $a1 . '=(int) $' . $a2 . '/$' . $a4 . ";\n";
                else
                    $t.='else ' . $a1 . '=' . $a2 . $a3 . $a4 . ";\n";
            }
            elseif ($a3 == '^') {
                $t.='if ((!is_numeric(' . $a2 . ')) || (!is_numeric(' . $a4 . ')) || (' . $a2 . '<=0)) ' . $a1 . '=-1;' . "\n";
                $t.='else ' . $a1 . '=pow(' . $a2 . ',' . $a4 . ");\n";
            } elseif ($a3 == ':') { //lettre d'un texte
                $t.='if ((!is_numeric(' . $a4 . ')) || (' . $a4 . '<0)) ' . $a1 . '=\'\';' . "\n";
                $t.='else ' . $a1 . '=' . $a2 . '[intval(' . $a4 . ')];' . "\n";
            } else
                $t.=$a1 . '=' . $a2 . $a3 . $a4 . ";\n";
        }
        if ($a == 'Prog_') {
            if (!is_numeric($a4))
                $a4 = '\'' . sqlp($a4) . '\'';
            if ($elt2)
                $a2 = '$_1' . $a2;
            if (($a3 == '\\') || ($a3 == '/') || ($a3 == '%')) {
                if ($a4 == '0')
                    erreur("Dvision par 0 dans le programme!");
                if ($a3 == '\\')
                    $t.=$a1 . '=(int) $' . $a2 . '/$' . $a4 . ";\n";
                else
                    $t.=$a1 . '=' . $a2 . $a3 . $a4 . ";\n";
            } else
                $t.=$a1 . '=' . $a2 . $a3 . $a4 . ";\n";
        }
        if ($a == 'Boucle') {
            if ($elt1)
                $a1 = '$_1' . $a1;
            if ($elt2)
                $a2 = '$_1' . $a2;
            if ($elt3)
                $a3 = '$_1' . $a3;
            $t.='$_2' . $bcl . '=100000;' . "\n"; // nbe maximal d'ittération
            $t.=$a1 . '=' . $a2 . ";\n";
            $t.='while((' . $a1 . '<=' . $a3 . ') && ($_2' . $bcl . ')){' . "\n";
            $bclInd[$bcl++] = $a1;
        }
        if ($a == 'Tant que') {
            if ($elt1)
                $a1 = '$_1' . $a1;
            if ($elt3)
                $a3 = '$_1' . $a3;
            $t.='$_2' . $bcl . '=100000;' . "\n"; // nbe maximal d'ittération
            $t.='while((' . $a1 . $a2 . $a3 . ') && ($_2' . $bcl . ')){' . "\n";
            $bclInd[$bcl] = '';
            $bcl++;
        }
        if ($a == '}') {
            $bcl--;
            $t.='$_2' . $bcl . '--;' . "\n";
            if ($bclInd[$bcl])
                $t.=$bclInd[$bcl] . '++;' . "\n";
            $t.="}\n";
        }
        if ($a == 'Rect') {
            if ($elt1)
                $a1 = '$_1' . $a1;
            if ($elt2)
                $a2 = '$_1' . $a2;
            if ($elt3)
                $a3 = '$_1' . $a3;
            if ($elt4)
                $a4 = '$_1' . $a4;
            if ($elt5)
                $a5 = '$_1' . $a5;
            if ($ind_form2)
                $t.='if ($req){' . "\n";
            $t.=$a2 . '=(int) ' . $a2 . ';' . "\n";
            $t.=$a3 . '=(int) ' . $a3 . ';' . "\n";
            $t.=$a4 . '=(int) ' . $a4 . ';' . "\n";
            $t.=$a1 . '=(int) ' . $a1 . ';' . "\n";
            $t.='$okGrph=' . $a1 . '+' . $a2 . '+' . $a3 . '+' . $a4 . ';' . "\n";
            $t.='if (($okGrph) && (' . $a5 . ')){' . "\n";
            $t.='echo \'<script type="text/javascript">\'."\n";' . "\n";
            $t.='echo \'var obj=document.getElementById("graphe");\'."\n";' . "\n";
            $t.='echo \'var Outil=obj.getContext("2d");\'."\n";' . "\n";
            $t.='echo \'Outil.fillStyle="\'.' . $a5 . '.\'";\'."\n";' . "\n";
            $t.='echo \'Outil.fillRect(\'.' . $a1 . '.\',\'.' . $a2 . '.\',\'.' . $a3 . '.\',\'.' . $a4 . '.\');\'."\n";' . "\n";
            $t.='echo \'</script>\'."\n";' . "\n";
            $t.="}\n";
            if ($ind_form2)
                $t.='}' . "\n";
        }
        if ($a == 'Arc') {
            if ($elt1)
                $a1 = '$_1' . $a1;
            if ($elt2)
                $a2 = '$_1' . $a2;
            if ($elt3)
                $a3 = '$_1' . $a3;
            if ($elt4)
                $a4 = '$_1' . $a4;
            if ($elt5)
                $a5 = '$_1' . $a5;
            if ($ind_form2)
                $t.='if ($req){' . "\n";
            $t.=$a1 . '=(float) ' . $a1 . ';' . "\n";
            $t.=$a2 . '=(float) ' . $a2 . ';' . "\n";
            $t.=$a3 . '=(float) ' . $a3 . ';' . "\n";
            $t.=$a4 . '=(float) ' . $a4 . ';' . "\n";
            $t.=$a5 . '=(float) ' . $a5 . ';' . "\n";
            $t.='$okGrph=' . $a1 . '+' . $a2 . '+' . $a3 . '+' . $a4 . '+' . $a5 . ';' . "\n";
            $t.='if ($okGrph){' . "\n";
            $t.='echo \'<script type="text/javascript">\'."\n";' . "\n";
            $t.='echo \'var obj=document.getElementById("graphe");\'."\n";' . "\n";
            $t.='echo \'var Outil=obj.getContext("2d");\'."\n";' . "\n";
            $t.='echo \'Outil.beginPath();\'."\n";' . "\n";
//			$t.='echo \'Outil.strokeStyle="\'.'.$a5.'.\'";\'."\n";'."\n";
            $t.='echo \'Outil.arc(\'.' . $a1 . '.\',\'.' . $a2 . '.\',\'.' . $a3 . '.\',\'.' . $a4 . '.\',\'.' . $a5 . '.\',0);\'."\n";' . "\n";
            $t.='echo \'Outil.stroke();\';' . "\n";
            $t.='echo \'</script>\'."\n";' . "\n";
            $t.="}\n";
            if ($ind_form2)
                $t.='}' . "\n";
        }
        if ($a == 'Ligne') {
            if ($elt1)
                $a1 = '$_1' . $a1;
            if ($elt2)
                $a2 = '$_1' . $a2;
            if ($elt3)
                $a3 = '$_1' . $a3;
            if ($elt4)
                $a4 = '$_1' . $a4;
            if ($elt5)
                $a5 = '$_1' . $a5;
            if ($ind_form2)
                $t.='if ($req){' . "\n";
            $t.=$a1 . '=(float) ' . $a1 . ';' . "\n";
            $t.=$a2 . '=(float) ' . $a2 . ';' . "\n";
            $t.=$a3 . '=(float) ' . $a3 . ';' . "\n";
            $t.=$a4 . '=(float) ' . $a4 . ';' . "\n";
            $t.='$okGrph=' . $a1 . '+' . $a2 . '+' . $a3 . '+' . $a4 . ';' . "\n";
            $t.='if (($okGrph) && (' . $a5 . ')){' . "\n";
            $t.='echo \'<script type="text/javascript">\'."\n";' . "\n";
            $t.='echo \'var obj=document.getElementById("graphe");\'."\n";' . "\n";
            $t.='echo \'var Outil=obj.getContext("2d");\'."\n";' . "\n";
            $t.='echo \'Outil.beginPath();\'."\n";' . "\n";
            $t.='echo \'Outil.strokeStyle="\'.' . $a5 . '.\'";\'."\n";' . "\n";
            $t.='echo \'Outil.moveTo(\'.' . $a1 . '.\',\'.' . $a2 . '.\');\'."\n";' . "\n";
            $t.='echo \'Outil.lineTo(\'.' . $a3 . '.\',\'.' . $a4 . '.\');\'."\n";' . "\n";
            $t.='echo \'Outil.stroke();\';' . "\n";
            $t.='echo \'</script>\'."\n";' . "\n";
            $t.="}\n";
            if ($ind_form2)
                $t.='}' . "\n";
        }
        if ($a == 'Transforme') {
            if ($ind_form2)
                $t.='if ($req){' . "\n";
            $t.=$a2 . '=(int) ' . $a2 . ';' . "\n";
            $t.=$a3 . '=(int) ' . $a3 . ';' . "\n";
            $t.=$a4 . '=(int) ' . $a4 . ';' . "\n";
            $t.=$a1 . '=(int) ' . $a1 . ';' . "\n";
            $t.='$okGrph=' . $a1 . '+' . $a2 . '+' . $a3 . '+' . $a4 . ';' . "\n";
            $t.='if (($okGrph) && (' . $a5 . ')){' . "\n";
            $t.='echo \'<script type="text/javascript">\'."\n";' . "\n";
            $t.='echo \'var obj=document.getElementById("graphe");\'."\n";' . "\n";
            $t.='echo \'var Outil=obj.getContext("2d");\'."\n";' . "\n";
            $t.='echo \'Outil.fillStyle="\'.' . $a5 . '.\'";\'."\n";' . "\n";
            $t.='echo \'Outil.fillRect(\'.' . $a1 . '.\',\'.' . $a2 . '.\',\'.' . $a3 . '.\',\'.' . $a4 . '.\');\'."\n";' . "\n";
            $t.='echo \'</script>\'."\n";' . "\n";
            $t.="}\n";
            if ($ind_form2)
                $t.='}' . "\n";
        }
        if ($a == 'Quadratic') {
            if ($ind_form2)
                $t.='if ($req){' . "\n";
            $t.=$a1 . '=(int) ' . $a1 . ';' . "\n";
            $t.=$a2 . '=(int) ' . $a2 . ';' . "\n";
            $t.=$a3 . '=(int) ' . $a3 . ';' . "\n";
            $t.=$a4 . '=(int) ' . $a4 . ';' . "\n";
            $t.='$okGrph=' . $a1 . '+' . $a2 . '+' . $a3 . '+' . $a4 . ';' . "\n";
            $t.='if (($okGrph) && (' . $a5 . ')){' . "\n";
            $t.='echo \'<script type="text/javascript">\'."\n";' . "\n";
            $t.='echo \'var obj=document.getElementById("graphe");\'."\n";' . "\n";
            $t.='echo \'var Outil=obj.getContext("2d");\'."\n";' . "\n";
            $t.='echo \'Outil.fillStyle="\'.' . $a5 . '.\'";\'."\n";' . "\n";
            $t.='echo \'Outil.fillRect(\'.' . $a1 . '.\',\'.' . $a2 . '.\',\'.' . $a3 . '.\',\'.' . $a4 . '.\');\'."\n";' . "\n";
            $t.='echo \'</script>\'."\n";' . "\n";
            $t.="}\n";
            if ($ind_form2)
                $t.='}' . "\n";
        }
        if ($a == 'Style') {
            if ($ind_form2)
                $t.='if ($req){' . "\n";
            if ($elt1)
                $a1 = '$_1' . $a1;
            if ($elt3)
                $a3 = '$_1' . $a3;
            $t.=$a3 . '=(int) ' . $a3 . ';' . "\n";
            $t.='if ((' . $a1 . ') && (' . $a3 . ')){' . "\n";
            $t.='echo \'<script type="text/javascript">\'."\n";' . "\n";
            $t.='echo \'var obj=document.getElementById("graphe");\'."\n";' . "\n";
            $t.='echo \'var Outil=obj.getContext("2d");\'."\n";' . "\n";
            $t.='echo \'Outil.strokeStyle="\'.' . $a1 . '.\'";\'."\n";' . "\n";
            $t.='echo \'Outil.lineWidth="\'.' . $a3 . '.\'";\'."\n";' . "\n";
            $t.='echo \'</script>\'."\n";' . "\n";
            $t.="}\n";
            if ($ind_form2)
                $t.='}' . "\n";
        }
    }
    if ($_POST['file_etat']) {
        $a = $rep_base . '/' . $_POST['file_etat'] . ".js";
        $rq = fopen($a, "w");
        fwrite($rq, $s);
        fclose($rq);
        echo '<script type="text/javascript">' . "\n";
        echo $s . "\n";
        echo "</script>\n";
//		if ((file_exists($a)) && (filesize($a)>5)) echo '<script type="text/javascript" src="'.$rep_base2.'/'.$t_0['file_etat'].'.js"></script>'."\n";
    }
} // !$nbe et file_exists
while ($bcl) {
    $bcl--;
    $t.='$_2' . $bcl . '--;' . "\n";
    if ($bclInd[$bcl])
        $t.=$bclInd[$bcl] . '++;' . "\n";
    $t.="}\n";
}
// fin du prog
$clause = sqlp($clause);
$result = 0;
if (!$clause)
    exit();
echo "<BR>" . $clause . "<BR>\n";
//if (($sep1 <> 0) || ($sep2 <> 0)){
if (!$ind_form2)
    $result = $conn->query($clause);
else
    $result = $conn->query($clause . ' LIMIT 0,1');
//}
if ($result === false)
    echo "<BR> Erreur dans la requete!" . " " . $conn->error . "<BR>";
$num_result = $result->num_rows;
echo "<HR><U>R&eacute;sultats de la requ&egrave;te</U>\n";
echo "<BR>Nombre d'enregistrements obtenus: " . $num_result . "<BR>\n";
$k = 0; // index dans le tableau r&eacute;sultat
echo "<TABLE BORDER='1'><TR>";
for ($i = 0; $i < $l2; $i++)
    echo "<TD>" . $champs[$i] . "</TD>";
echo "</TR>";
while (($result) && ($resa = $result->fetch_row())) {
    echo "<TR>";
    for ($j = 0; $j < $l2; $j++) {
        $sql_res[$k] = $resa[$j];
        echo "<TD>" . verifieHtml($sql_res[$k++]) . "</TD>";
    }
    echo "</TR>\n";
    $k++;
}
$num_result = $k;
echo "</TABLE>\n";
echo '__________________________________________________________________________<INPUT TYPE="submit" NAME="DropE" Value="Effacer les enregistrements"><BR><BR>'; // a traiter au debut
// traitement de delete
if (($k) && ($_POST['DropE'])) {
    $clause1 = 'DELETE ' . substr($clause1, $m0);
    echo '<BR>' . $clause1;
    $result = $conn->query($clause1);
    if (!$result)
        echo "Erreur de la suppresion des enregistrements!<BR>";
    else
        echo '<BR> suppression de ' . $result . ' enregistrements<BR>';
}
if (($_POST['UseF']) && (strlen($t_0['file_etat']) > 1)) {
// Ajout de l'entete php + connection + select +
// traitement du formulaire: remplacement: une section par ligne de la requête
// affichage du champ: [nom de champ]
// passage d'enregistrement: mot clef : <HR>
// saisie de champ: par formulaire: le nom doit correspondre au champ de la base:<table>.<champ>
    $sep3 = 0; // utilisation de editor
    $editor_ind = 0;
    $debut6 = 0; // debut apres log
    $uni00 = -1; // cpt de saisie unicode avec uni_sai
    $r = "<?php\n";
    $r.="// Genere par azj_base 0.0.28p - (c) Alexandre Zvenigorosky - 22/03/2016\n";
    $r.="require('../../verifieHtml.php');\n";
    $r.='function sqlp($txt){ // corrige ou supprime les caracteres speciaux \t \r \n \->\\ \'->\'\'' . "\n";
    $r.='if (is_numeric($txt)) return $txt;' . "\n";
    $r.='$z=strlen($txt);' . "\n";
    $r.='$w=\'\';' . "\n";
    $r.='$x=0' . ";\n";
    $r.='while($x<$z){' . "\n";
    $r.='	$v=$txt[$x++];' . "\n";
    $r.='	if (($v == "\\\\") || ($v=="\\n") | ($v=="\\t") | ($v == "\\r")) $v="";' . "\n";
    $r.='	if ($v == "\'") $v="\\\\\'";' . "\n";
    $r.='	$w.=$v;' . "\n";
    $r.='}' . "\n";
    $r.='return $w;' . "\n";
    $r.="}\n";
    $r.='echo \'<!DOCTYPE HTML>\'."\\n";' . "\n";
    $r.='echo \'<HTML>\'."\\n";' . "\n";
    $r.='echo \'<HEAD>\'."\\n";' . "\n";
    $r.='echo \'<TITLE>' . $t_0['file_etat'] . '</TITLE>\'."\\n";' . "\n";
	$r.='echo \'<SCRIPT TYPE="text/javascript" SRC="../../js/headAZJ.js"></SCRIPT>\';'."\n";
    //echo $chm_os.'/liens/'.$rep0.'/'.sqlp($_POST['feuille_style']);
    if (($_POST['feuille_style']) && (file_exists($chm_os . '/liens/' . $rep0 . '/' . sqlp($_POST['feuille_style'])))) {
        $r.='echo \'<style type="text/css">\'."\\n";' . "\n";
        // Complement police a partir du fichier font/font.txt
        if (file_exists('font/font.txt')) {
            $rq = fopen('font/font.txt', 'rb');
            while (!feof($rq)) {
                $nom = fgets($rq);
                if ($nom) {
                    $nom = substr($nom, 0, -1);
                    $r.='echo \'@font-face {\'."\\n";' . "\n";
                    $r.='echo \'font-family: ' . $nom . '\'.";\\n";' . "\n";
                    $r.='echo \'src: url("' . $chm_web . '/font/' . $nom . '.ttf");\'."\\n";' . "\n";
                    $r.='echo \'}\'."\\n";' . "\n";
                }
            }
            fclose($rq);
            $r.='echo \'</style>\'."\\n";' . "\n";
        }
        $r.='echo \'<LINK rel="stylesheet" type="text/css" href="' . sqlp($_POST['feuille_style']) . '">\'."\\n";' . "\n";
    }
    $r.='echo \'</HEAD>\'."\\n";' . "\n";
    $r.='echo \'<BODY>\'."\\n";' . "\n";
// marque sur name="champ"
    for ($i = 0; $i < $l0; $i++) {
        $im = stripos($formulaire, 'name="' . $tl_tbl[$i] . '"');
        if ($im)
            $marque[$i] = 1;
    }
    if ($ok6 !== false) {
        $debut6 = $ok6;
        if (!$ind_form2) {
            $r.='echo \'<form method="POST" name="' . $t_0['file_etat'] . '" action="">\';' . "\n";
        } else {
            $r.='echo \'<form method="POST" name="' . $t_0['file_etat'] . '" action="">\';' . "\n";
            str_replace('<form ', '<from ', $formulaire);
        }
        if (stripos($formulaire, '[') < $ok6)
            erreur("Erreur:complement [ avant [log]!");
        if ($debut6) {
            $j = 0;
            $a = '';
            while ($j < $debut6) {
                $a0 = $formulaire[$j++];
                if ($a0 == "\n")
                    $a0 = '';
                if (($a0 == "\\") && ($formulaire[$j] == "\""))
                    $a0 = '';
                if ($a0 == "'") {
                    if (($j == 1) || ($formulaire[$j - 2] != "\\"))
                        $a0 = "\\'";
                }
                if ($a0 == "\r") {
                    $r.='echo \'' . $a . '\'' . ".\"\\n\";\n";
                    $a = '';
                } else
                    $a.=$a0;
            }
            if ($a)
                $r.='echo \'' . $a . '\'' . ";\n";
        }
        $r.='if ($_POST[\'terminer\']){' . "\n";
        $r.='	echo \'<input type="text" name="_j_login" size="24" maxlength="24" value="">\';' . "\n";
        $r.='	echo \'&nbsp;&nbsp;&nbsp;<input type="password" name="_j_mdp" size="24" maxlength="24" value="">\';' . "\n";
        $r.="} else {\n";
        $r.='	echo \'<input type="text" name="_j_login" size="24" maxlength="24" value="\'.$_POST[\'_j_login\'].\'">\';' . "\n";
        $r.='	echo \'&nbsp;&nbsp;&nbsp;<input type="password" name="_j_mdp" size="24" maxlength="24" value="\'.$_POST[\'_j_mdp\'].\'">\';' . "\n}\n";
        $r.='	echo \'&nbsp;&nbsp;&nbsp;<input type="number" name="_j_port" size="5" maxlength="5" value="\'.$_POST[\'_j_port\'].\'">\';' . "\n}\n";
        $r.='echo \'&nbsp;&nbsp;&nbsp;<input type="submit" name="connexion" value="connexion">\';' . "\n";
        $r.='echo \'&nbsp;&nbsp;&nbsp;<input type="submit" name="terminer" value="Terminer">\';' . "\n";
        if (!$ind_form2)
            $r.='echo \'</form>\';' . "\n";
        $ok6 = 1;
        $r.='if (!$_POST[\'_j_login\']) exit;' . "\n";
        $r.='if (!$_POST[\'_j_mdp\']) exit;' . "\n";
        $r.='if (!$_POST[\'_j_port\']) $_POST[\'_j_port\']=3306;' . "\n";
        $r.='$srv_log=sqlp($_POST[\'_j_login\']);' . "\n";
        $r.='$srv_mdp=sqlp($_POST[\'_j_mdp\']);' . "\n";
        $r.='$conn=new mysqli(\'' . $t_0['srv_1_serveur'] . '\',\'' . $t_0['srv_1_user'] . '\',\'' . $t_0['srv_1_mdp'] . '\',\'' . $t_0['srv_1_base'] . '\',' . $t_0['srv_1_port'] . ')' . "\n";
    } else
        $r.='$conn=new mysqli(\'' . $t_0['srv_1_serveur'] . '\',\'' . $t_0['srv_1_user'] . '\',\'' . $t_0['srv_1_mdp'] . '\',\'' . $t_0['srv_1_base'] . '\',' . $t_0['srv_1_port'] . ');' . "\n";
    $r.='if (!$conn) die("Erreur: Ouverture du serveur Mysql en lecture!");' . "\n";
    $r.='if (!isset($_POST[\'indicev\'])) $ndeb=0; else $ndeb=$_POST[\'indicev\'];' . "\n";
    $r.='$l0=' . $l0 . ";\n";
    $r.='$l=' . $l . ";\n";
    if ((stripos($formulaire, '[txt(')) || (stripos($formulaire, '[sai('))) {
        $uni00 = 0;
        $r.='echo \'<script TYPE="text/javascript" src="' . $chm_web . '/js/char_ext.js"></script>\'."\n";' . "\n";
    }
// recuperation des noms des tables et des champs
    for ($i0 = 0; $i0 < $l; $i0++) {
        $r.='$tbl_table[' . $i0 . ']=\'' . $tbl_table[$i0] . "';\n";
        $r.='$ts[' . $i0 . ']=' . $ts[$i0] . ";\n";
        $r.='$tidx[' . $i0 . ']=\'' . $tidx[$i0] . "';\n";
        for ($i = $ts[$i0]; $i < $ts[$i0 + 1]; $i++)
            $r.='$tl_tbl[' . $i . ']=\'' . $tl_tbl[$i] . "';\n";
        if ($ok2) {
            for ($i = $ts[$i0]; $i < $ts[$i0 + 1]; $i++) {
                $r.='if (!isset($_POST[\'' . $tl_tbl[$i] . '\'])) $_POST[\'' . $tl_tbl[$i] . '\']=\'\';' . "\n";
                $r.='$ligne[' . $i . ']=$_POST[\'' . $tl_tbl[$i] . '\']' . ";\n";
//				if ($marque[$i]) $r.='$ligne['.$i.']=$_POST[\''.$tl_tbl[$i].'\']'.";\n";
//				else $r.='$ligne['.$i.']=\'\';'."\n";
            }
        }
    }
    $r.='$ts[$l]=' . $ts[$l] . ";\n";
    if ($ok2)
        $r.=$t;
    $r.='$mod_sql=0;' . "\n"; // pas de modification post traitement
    if ($ok2) {
        $r.='if ($ligne[0] !== FALSE) $mod_sql=1' . ";\n";
        $r.='$a8=0;' . "\n"; // pas de saisie
// est-ce un formulaire: _post non vide ou un etat
        $ind_form = 0; // 1 --> champ texte a remplacer
// requete ajout/modification
        $r.='$req="INSERT INTO ' . $tbl_table[0] . ' (' . $tl_tbl[0];
        for ($i = 1; $i < $ts[1]; $i++)
            $r.=', ' . $tl_tbl[$i];
        $r.=') VALUES(\'".sqlp($ligne[0])."\'';
        for ($i = 1; $i < $ts[1]; $i++)
            $r.=', \'".sqlp($ligne[' . $i . '])."\'';
        $r.=') ON DUPLICATE KEY UPDATE ';
        $r.=$tl_tbl[0] . '=\'".sqlp($ligne[0])."\'';
        for ($i = 1; $i < $ts[1]; $i++)
            $r.=', ' . $tl_tbl[$i] . '=\'".sqlp($ligne[' . $i . '])."\'';
        $r.="\";\n";
        $r.='if ($mod_sql){' . "\n";
        $r.='if (!isset($_POST[\'indicev\'])) $_POST[\'indicev\']=0;' . "\n";
        $r.='if (!isset($_POST[\'indices\'])) $_POST[\'indices\']=0;' . "\n";
        $r.='if (!isset($_POST[\'indicep\'])) $_POST[\'indicep\']=0;' . "\n";
        $r.='if (!isset($_POST[\'Effacer\'])) $_POST[\'Effacer\']=0;' . "\n";
        $r.='if (!isset($_POST[\'_flags\'])) $_POST[\'_flags\']=0;' . "\n";
	$r.='if ((isset($_GET[\'affiche\'])) && ($_GET[\'affiche\'])) $_POST[\'_flags\']=1;';
	$r.='if ((isset($_POST[\'saisie\'])) && ($_POST[\'saisie\']) && (!$_POST[\'_flags\'])){'."\n";
//        $r.='	if ((!$_POST[\'_flags\']) && (!(($_POST[\'indicep\']) || ($_POST[\'indices\']) || ($_POST[\'Effacer\'])))){' . "\n";
//	$r.='		echo $req."<BR>";'."\n";
        $r.='		$result=$conn->query($req);' . "\n";
        $r.='		if ($result) $a8++;' . "\n";
        $r.='		else {' . "\n";
        $r.='			echo "Echec mise a jour de la table:".$conn->error' . ";\n";
        $r.="			exit;\n }\n }\n";
        $r.='	if ($_POST[\'Effacer\']){' . "\n";
        $r.='		$req=\'DELETE FROM \'.$tbl_table[0].\' WHERE \';' . "\n";
        $r.='		$req.=$tl_tbl[0].\'=\\\'\'.$_POST[$tl_tbl[0]].\'\\\'\';' . "\n";
        $r.='		echo $req.\'<BR>\';' . "\n";
        $r.='		$result=$conn->query($req);' . "\n";
        $r.='		if ($result) $a8++;' . "\n";
        $r.='		else {' . "\n";
        $r.='			echo "Echec de la suppression!".$conn->error' . ";\n";
        $r.="			exit;\n";
        $r.="		}\n";
        $r.="	}\n";
        $r.='}' . "\n";
        $r.='if ($mod_sql){' . "\n";
        $r.='	$ndeb=$_POST[\'indicev\'];' . "\n";
        $r.='	$ndeb=0+$a8+$ndeb;' . "\n";
        $r.='	if ($_POST[\'indicep\']) $ndeb--;' . "\n";
        $r.='	if ($_POST[\'indices\']) $ndeb++;' . "\n";
        $r.='	if ($ndeb<0) $ndeb=0;' . "\n";
        if (!$ind_form2)
            $r.='	if ($ndeb >= $num_result) $ndeb=$num_result-1;' . "\n";
        $r.="}\n";
    } // $ok2
    if ($ind_form2) {
//		$r.='$ndeb0=$ndeb+1;'."\n"; ??
        $r.='$a7=\' LIMIT \'.$ndeb.\',1\'' . ";\n";
        $r.='$clause="' . sqlp($clause) . '".sqlp($a7);' . "\n";
    } else
        $r.='$clause="' . sqlp($clause2) . '";' . "\n";
    if (!$ind_form2) {
        // traitement des fonctions
        $r.='for($i2=0;$i2<$l0*6;$i2++) $tfonc[$i2]=0;' . "\n";
        $r.='$result=$conn->query($clause);' . "\n";
        $r.='$num_result=0;' . "\n";
        $r.='while (($result) && ($ligne=$result->fetch_row())){' . "\n";
        $r.='	for($i=0;$i<$l0;$i++){' . "\n";
        $r.='		$k=5*$i;' . "\n";
        $r.='		if (!$num_result) $tfonc[$k]=$ligne[$i];' . "\n";
        $r.='		if (!$num_result) $tfonc[$k+1]=$ligne[$i];' . "\n";
        $r.='		if ($ligne[$i]<$tfonc[$k]) $tfonc[$k]=$ligne[$i];' . "\n";
        $r.='		if ($ligne[$i]>$tfonc[$k+1]) $tfonc[$k+1]=$ligne[$i];' . "\n";
        $r.='		$tfonc[$k+2]+=$ligne[$i];' . "\n";
        $r.='		$tfonc[$k+4]+=$ligne[$i]*$ligne[$i];' . "\n";
        $r.='	}' . "\n";
        $r.='	$num_result++;' . "\n";
        $r.="}\n";
        $r.='if ($num_result){' . "\n";
        $r.='	for($i2=0;$i2<$l0;$i2++){' . "\n";
        $r.='		$k=5*$i2;' . "\n";
        $r.='		$tfonc[$k+3]=$tfonc[$k+2]/$num_result;' . "\n";
        $r.='		$tfonc[$k+4]=$tfonc[$k+4]/$num_result-$tfonc[$k+3]*$tfonc[$k+3];' . "\n";
        $r.='	}' . "\n";
        $r.='} else {' . "\n";
        $r.='	for($i2=0;$i2<5*$l0;$i2++) $tfonc[$i2]=\'indetermin&eacute\';' . "\n";
        $r.="}\n";
    }
// traduction
// recherche du premier <hr \>: entete
    $debut = stripos($formulaire, '<hr ');
    if (!$debut) {
        if (($ok6 !== false) && ($debut < $debut6))
            erreur("Erreur:[log] doit se trouver dans l'entete!");
        $debut = $debut6;
        $fin = strlen($formulaire);
    }
    else {
        // recherche du second <hr />:fin de boucle (et apres validation de saisie?)
        $fin = stripos($formulaire, '<hr ', $debut + 1);
        if (!$fin)
            $fin = strlen($formulaire);
        $debut+=6;
        if ($debut >= $fin)
            $fin = -1;
    }
// Ecriture entete
    $j = $debut6;
    while ($j < $debut) {
        $a = '';
        while (($j < $debut) && ($formulaire[$j] != '[')) {
            $a0 = $formulaire[$j++];
            if ($a0 == "\n")
                $a0 = '';
            if (($a0 == "\\") && ($formulaire[$j] == "\""))
                $a0 = '';
            if ($a0 == "'") {
                if (($j == 1) || ($formulaire[$j - 2] != "\\"))
                    $a0 = "\\'";
            }
            if ($a0 == "\r") {
                $r.='echo \'' . $a . '\'' . ".\"\\n\";\n";
                $a = '';
            } else
                $a.=$a0;
        }
        if ($a)
            $r.='echo \'' . $a . '\'' . ";\n";
        if (($j < $debut) && ($formulaire[$j] == '[')) {
            if ($formulaire[$j + 1] == '[') {
                $j+=2;
                $r.='[';
            } elseif (($formulaire[$j + 1] == 'l') && ($formulaire[$j + 2] == 'o') && ($formulaire[$j + 3] == 'g') && ($formulaire[$j + 4] == ']')) {
                $ok6++;
                $j+=5;
            } elseif ((($j + 5) < $debut) && ($formulaire[$j + 4] == '(')) {
                // fonction: [abc(table.champ)]
                $ch0 = substr($formulaire, $j + 1, 3);
                $j+=5;
                $a0 = ''; // nom de la table
                $j0 = $j + 24; // longueur max d'une des parties
                while (($j < $j0) && ($formulaire[$j] != '.'))
                    $a0.=$formulaire[$j++];
                if ($j >= $j0)
                    erreur("le parametre [" . $a0 . " ... est mal forme!");
                $j++;
                $a = '';
                $j0 = $j + 24;
                while (($j < $j0) && ($formulaire[$j] != ')'))
                    $a.=$formulaire[$j++];
                if ($j >= $j0)
                    erreur("le parametre [" . $a0 . "." . $a . " ... est mal forme!");
                $i = 0;
                $i0 = 0;
                while (($i0 < $l) && (strcmp($tbl_table[$i0], $a0)))
                    $i0++;
                while (($i < $l0) && (strcmp($tl_tbl[$i], $a)))
                    $i++;
                if (($i0 >= $l) || ($i >= $l0))
                    erreur("Le parametre [" . $a0 . "." . $a . "] n'a pas ete trouve dans la selection!1");
                $j+=2;
                // ecriture de la boucle resultat
                if (!strcmp($ch0, 'min'))
                    $r.='echo $tfonc[5*' . $i . '];' . "\n";
                elseif (!strcmp($ch0, 'max'))
                    $r.='echo $tfonc[5*' . $i . '+1];' . "\n";
                elseif (!strcmp($ch0, 'sum'))
                    $r.='echo $tfonc[5*' . $i . '+2];' . "\n";
                elseif (!strcmp($ch0, 'moy'))
                    $r.='echo $tfonc[5*' . $i . '+3];' . "\n";
                elseif (!strcmp($ch0, 'sig'))
                    $r.='echo $tfonc[5*' . $i . '+4];' . "\n";
                else
                    erreur("Erreur: Fonction inconnue!");
            } else
                erreur("Erreur: Seules les fonctions peuvent apparaitre dans l'entete!" . substr($formulaire, $j - 16, 32));
        }
    } // $j<$debut
    if ($fin > 0) {
        // Ecriture boucle enregistre si pas mod_sql
        $r.='$result=$conn->query($clause);' . "\n";
        if ($ind_form2)
            $r.='if (!$mod_sql) erreur(\'Formulaire hors champ!\');' . "\n";
        $j = $debut;
        $r.='$num_result=0;' . "\n";
        if ($ind_form2) {
            $r.='$ligne=$result->fetch_row();' . "\n";
            $r.='while($num_result < 1){' . "\n";
        } else
            $r.='while(($result) && ($ligne=$result->fetch_row())){' . "\n";
        $r.='	$num_result++;' . "\n";
    }
    $r.=$t;
    while ($j < $fin) {
        $a = '';
        while (($j < $fin) && ($formulaire[$j] != '[')) {
            $a0 = $formulaire[$j++];
            if (($ind_form2) && ($a0 == '<') && ($formulaire[$j] == '/') && ($formulaire[$j + 1] == 'f') && ($formulaire[$j + 2] == 'o') && ($formulaire[$j + 3] = 'r') && ($formulaire[$j + 4] == 'm') && ($formulaire[$j + 5] == '>')) {
                if ($a)
                    $r.='echo \'' . $a . '\'' . ";\n";
                $a = '';
                $r.='echo "\n<br><input type=\"submit\" name=\"indicep\" value=\"Pr&eacute;c&eacute;dent\">\n";' . "\n";
                $r.='echo "&nbsp;&nbsp;&nbsp;<input type=\"text\" size=\"8\" maxlength=\"8\" name=\"indicev\" id=\"indicev\" value=\'".$ndeb."\'>\n";' . "\n";
		$r.='$txt=\'\';';
		$r.='if ($_POST[\'_flags\']) $txt=\' checked \';';
                $r.='echo "&nbsp;&nbsp;&nbsp;<input type=\"checkbox\" name=\"_flags\" id=\"_flags\" ".$txt."onChange=\"submit(); \">\n";'."\n";
                $r.='echo "&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"indices\" value=\"Suivant\">\n";' . "\n";
                $r.='echo " _________________ <input type=\"submit\" name=\"Effacer\" value=\"Effacer\">\n";' . "\n";
                if ($uni00 > -1) {
                    if ($uni00 == 0)
                        erreur("Erreur:les extensions de saisie doivent uniquement apparaitre dans le corps du formulaire!");
                    require 'js/pre_ext.php';
                    $r.='echo \'<SCRIPT TYPE="text/javascript">\'."\n"' . ";\n";
                    $r.='echo \'document.getElementById("alpha").onchange=chg;\'."\n"' . ";\n";
                    for ($i = 0; $i < $uni00; $i++) {
                        $r.='echo \'document.getElementById("' . $uni_sai[$i] . '").onkeydown=traduit;\'."\n"' . ";\n";
                        $r.='echo \'document.getElementById("' . $uni_sai[$i] . '").onkeyup=trad2;\'."\n"' . ";\n";
                    }
                    $r.='echo \'</SCRIPT>\'' . ";\n";
                }
            }
            if ($a0 == "\n")
                $a0 = '';
            if (($a0 == "\\") && ($formulaire[$j] == "\""))
                $a0 = '';
            if ($a0 == "'") {
                if (($j == 1) || ($formulaire[$j - 2] != "\\"))
                    $a0 = "\\'";
            }
            if ($a0 == "\r") {
                $r.='echo \'' . $a . '\'' . ".\"\\n\";\n";
                $a = '';
            } else
                $a.=$a0;
        }
        if ($a)
            $r.='echo \'' . $a . '\'' . ";\n";
        if (($j < $fin) && ($formulaire[$j] == '[')) {
            if (($formulaire[$j + 1] == 'n') && ($formulaire[$j + 2] == 'u') && ($formulaire[$j + 3] == 'm') && ($formulaire[$j + 4] == ']')) {
                $j+=5;
                $r.='echo $num_result;' . "\n";
            } elseif ($formulaire[$j + 1] == '[') {
                $j+=2;
                $r.='[';
            } elseif ((($j + 5) < $fin) && ($formulaire[$j + 4] == '(')) {
                // fonction: [abc(table.champ)]
                $ch0 = substr($formulaire, $j + 1, 3);
                $j+=5;
                $a0 = ''; // nom de la table
                $j0 = $j + 24; // longueur max d'une des parties
                while (($j < $j0) && ($formulaire[$j] != '.'))
                    $a0.=$formulaire[$j++];
                if ($j >= $j0)
                    erreur("le parametre [" . $a0 . " ... est mal forme!");
                $j++;
                $a = '';
                $j0 = $j + 24;
                while (($j < $j0) && ($formulaire[$j] != ')'))
                    $a.=$formulaire[$j++];
                if ($j >= $j0)
                    erreur("le parametre [" . $a0 . "." . $a . " ... est mal forme!");
                $i = 0;
                $i0 = 0;
                while (($i0 < $l) && (strcmp($tbl_table[$i0], $a0)))
                    $i0++;
                while (($i < $l0) && (strcmp($tl_tbl[$i], $a)))
                    $i++;
                if (($i0 >= $l) || ($i >= $l0))
                    erreur("Le parametre [" . $a0 . "." . $a . "] n'a pas ete trouve dans la selection!2");
                $j+=2;
                // ecriture de la boucle resultat
                if (!strcmp($ch0, 'sel')) { // liste depuis une table [sel(table1.champ1)table2.champ2,champ3]
                    $a1 = '';
                    $j--;
                    $a1 = ''; // nom du second champ
                    $j0 = $j + 24; // longueur max d'une des parties
                    while (($j < $j0) && ($formulaire[$j] != '.'))
                        $a1.=$formulaire[$j++];
                    if ($j >= $j0)
                        erreur("la seconde table " . $a1 . " ... est mal formee!");
                    $j++;
                    $a2 = ''; // nom du second champ
                    $j0 = $j + 24; // longueur max d'une des parties
                    while (($j < $j0) && ($formulaire[$j] != ','))
                        $a2.=$formulaire[$j++];
                    if ($j >= $j0)
                        erreur("le second champ " . $a2 . " ... est mal forme!");
                    $a3 = ''; // nom du second champ
                    $j++;
                    $j0 = $j + 24; // longueur max d'une des parties
                    while (($j < $j0) && ($formulaire[$j] != ']'))
                        $a3.=$formulaire[$j++];
                    if ($j >= $j0)
                        erreur("le trosieme champ " . $a3 . " ... est mal forme!");
                    $j++;
                    if ((vnom($a) + vnom($a0) + vnom($a1) + vnom($a2) + vnom($a3)) < 5)
                        erreur('Erreur: [sel(' . $a . '.' . $a0 . ')' . $a1 . '.' . $a2 . ',' . $a3 . '] est mal forme!');
                    if ($i0 != 0)
                        erreur('Seule la premiere table est prise en compte dans le formulaire!');
                    $r.='echo \'<INPUT TYPE="text" NAME="_nsel' . $nsel . '" SIZE="5" MAXLENGTH="5">&nbsp;&nbsp;&nbsp;\';' . "\n";
                    $req = 'select ' . $a2 . ', ' . $a3 . ' from ' . $a1 . ' where ' . $a2 . ' like \\\'\'.sqlp($_POST[\'_nsel' . $nsel . '\']).\'%\\\' limit 150';
                    $nsel++;
                    $r.='$req=\'' . $req . '\'' . ";\n";
                    $r.='$result2=$conn->query($req) or erreur(\'Erreur select\'.$req);' . "\n";
                    $r.='$l1=0;' . "\n";
                    $r.='echo \'<SELECT NAME="' . $a . '">\';' . "\n";
                    $r.='echo \'<option selected>\'.$ligne[' . $i . '].\'</option>\';' . "\n";
                    $r.='while ($ligne) && ($ligne2=$result2->mysql_fetch_row())){' . "\n";
                    $r.='	$ok=1;' . "\n";
                    $r.='	$l1++;' . "\n";
                    $r.='echo \'<option value="\'.$ligne2[1].\'">\'.$ligne2[0].\'</option>\';' . "\n";
                    $r.="}\n";
                    $r.='echo \'</SELECT>\';' . "\n";
                    $im0 = -1;
                    for ($im = 0; $im < $ts[1]; $im++)
                        if ($a == $tl_tbl[$im])
                            $im0 = $im;
                    if ($im0 > -1) {
                        if ($marque[$im0])
                            erreur("Le champ '.$a.' est deja l'objet d'une autre saisie!");
                        else
                            $marque[$im0] = 1;
                    }
                }
                elseif (!strcmp($ch0, 'sai')) { // saisie unicode
                    $a1 = $tbl_c[6 * $i + 1];
                    $a2 = substr($a1, 0, 7);
                    if ($i0 > 0)
                        erreur("Erreur:seul la table maitre est utilisable dans les formulaires!");
                    if (($a2 != 'varchar') && ($a1 != 'mediumtext') && ($a1 != 'text'))
                        erreur("Erreur:saisie etendue seulement sur les champs VARCHAR ou TEXT!".$i.":".print_r($tbl_c));
                    $j0 = substr($a1, 8, -1);
                    //$j0=(int) ($j0/7);
                    if (($a2 == 'varchar') && ($j0 == 0))
                        erreur("Erreur:lg < 1!");
                    if ($j0 > 128)
                        erreur("Erreur:champ de saisie de taille > 128!");
                    $r.='echo \'<INPUT TYPE="TEXT" ID="sai_' . $a . '" NAME="' . $a . '" SIZE="' . $j0 . '" MAXLENGTH="' . $j0 . '" VALUE="\'.$ligne[' . $i . '].\'">\';' . "\n";
                    $uni_sai[$uni00++] = 'sai_' . $a;
                    $im0 = -1;
                    for ($im = 0; $im < $ts[1]; $im++)
                        if ($a == $tl_tbl[$im])
                            $im0 = $im;
                    if ($im0 > -1) {
                        if ($marque[$im0])
                            erreur("Le champ '.$a.' est dèjà l'objet d'une autre saisie!");
                        else
                            $marque[$im0] = 1;
                    }
                }
                elseif (!strcmp($ch0, 'txt')) { // saisie unicode
                    $a1 = $tbl_c[6 * $i + 1];
                    $a2 = substr($a1, 0, 7);
                    if (($a2 != 'varchar') && ($a1 != 'mediumtext') && ($a1 != 'text'))
                        erreur("Erreur:saisie etendue seulement sur les champs VARCHAR ou TEXT!".$i.':'.print_r($tbl_c));
                    if ($a2 == 'VARCHAR')
                        $j0 = substr($a1, 8, -1);
                    $j0 = 1024;
                    if ($j0 == 0)
                        erreur("Erreur:lg < 7!");
                    $j1 = 1 + (int) (sqrt(j0) / 2);
                    $j2 = (int) $j0 / $j1;
                    if ($j2 > 128) {
                        $j2 = 128;
                        $j1 = (int) ($j0 / 128);
                    }
                    if ($i0 > 0)
                        erreur("Erreur:seul la table maitre est utilisable dans les formulaires!");
                    $r.='echo \'<TEXTAREA ID="sai_' . $a . '" NAME="' . $a . '" COLS="' . $j2 . '" ROWS="' . $j1 . '">\'.$ligne[' . $i . '].\'</TEXTAREA>\';' . "\n";
                    $uni_sai[$uni00++] = 'sai_' . $a;
                    $im0 = -1;
                    for ($im = 0; $im < $ts[1]; $im++)
                        if ($a == $tl_tbl[$im])
                            $im0 = $im;
                    if ($im0 > -1) {
                        if ($marque[$im0])
                            erreur("Le champ '.$a.' est dèjà l'objet d'une autre saisie!");
                        else
                            $marque[$im0] = 1;
                    }
                }
                elseif (!strcmp($ch0, 'htm')) { // saisie editor // pour l'instant 1 seule fenetre par saisie
                    if ($sep3)
                        erreur("Une seule fenetre de saisie HTML par formulaire!");
                    $a1 = $tbl_c[6 * $i + 1];
                    $a2 = substr($a1, 0, 7);
                    if (($a2 != 'varchar') && ($a1 != 'mediumtext') && ($a1 != 'text'))
                        erreur("Erreur:saisie etendue seulement sur les champs VARCHAR ou TEXT!");
                    if ($a1 == 'varchar') {
                        $j0 = substr($a1, 8, -1);
                        if ($j0 < 512)
                            erreur("Erreur:lg < 512!");
                    }
                    if ($i0 > 0)
                        erreur("Erreur:seule la table maitre est utilisable dans les formulaires!");
                    $r.='$formulaire=str_replace("\\\\","",$ligne[' . $i . ']);' . "\n";
                    if (!$sep3) {
                        $r.='echo "<script type=\"text/javascript\" src=\"../../editor/barreoutils3.js\"></script>\n"' . ";\n";
                        $r.='require_once "' . $chm_os . '/edit004.php"' . ";\n";
                    }
                    $sep3 = 1;
                    $tab_editor_champ[$editor_ind++] = $a;
                    $r.='if (!$_POST[\'_flags\']) edite(\'' . $a . '\',verifieHtml($ligne[\'' . $i . '\']),\''.$t_0['file_etat'].'.fiches\'); else echo "<DIV>".verifieHtml($ligne[\'' . $i . '\'])."</DIV>";'."\n";
                    $im0 = -1;
                    for ($im = 0; $im < $ts[1]; $im++)
                        if ($a == $tl_tbl[$im])
                            $im0 = $im;
                    if ($im0 > -1) {
                        if ($marque[$im0])
                            erreur("Le champ '.$a.' est dèjà l'objet d'une autre saisie!");
                        else
                            $marque[$im0] = 1;
                    }
                }
                elseif (!strcmp($ch0, 'chk')) { // checkbox
                    if ($i0 > 0)
                        erreur("Erreur checkbox:" . $a0 . '.' . $a . " ne fait pas partie de la table maitre!");
                    $r.='if ($ligne[\'' . $i . '\']) echo \'<input type="checkbox" name="' . $a . '" checked value="1">\';' . "\n";
                    $r.='else echo \'<input type="checkbox" name="' . $a . '" value="1">\';' . "\n";
                    $im0 = -1;
                    for ($im = 0; $im < $ts[1]; $im++)
                        if ($a == $tl_tbl[$im])
                            $im0 = $im;
                    if ($im0 > -1) {
                        if ($marque[$im])
                            erreur("Le champ '.$a.' est dèjà l'objet d'une autre saisie!");
                        else
                            $marque[$im] = 1;
                    }
                }
                elseif (!strcmp($ch0, 'si_')) {
                    $j--;
                    $a1 = $formulaire[$j++];
                    $b1 = '';
                    if ($a1 == '=')
                        $b1 = '==';
                    if ($a1 == '>')
                        $b1 = '>';
                    if ($a1 == '<')
                        $b1 = '<';
                    if (($a1 == '!') && ($formulaire[$j++] == '='))
                        $b1 = '!=';
                    if (($a1 == '&') && ($formulaire[$j] == 'l') && ($formulaire[$j + 1] == 't') && ($formulaire[$j + 2] == ';')) {
                        $b1 = '<';
                        $j+=3;
                    }
                    if (($a1 == '&') && ($formulaire[$j] == 'g') && ($formulaire[$j + 1] == 't') && ($formulaire[$j + 2] == ';')) {
                        $b1 = '>';
                        $j+=3;
                    }
                    if ($a1 == '~')
                        $b1 = '~';
                    if (!$b1)
                        erreur("Erreur:le signe de comparaison n'est pas reconnu!");
                    $a1 = ''; // aVal
                    if ($formulaire[$j++] != ' ')
                        erreur("Erreur: comparaison mal form&eacute;e");
                    $j0 = $j + 48;
                    if ($j0 > $fin)
                        $j0 = $fin;
                    $ok4 = 1;
                    while (($j < $j0) && ($ok4)) {
                        $a4 = $formulaire[$j++];
                        if ($a4 == ',') {
                            if ($formulaire[$j] == ',')
                                $j++;
                            else
                                $ok4 = 0;
                        }
                        if ($ok4)
                            $a1.=$a4;
                    }
                    if ($ok4)
                        erreur("Erreur:comparaison trop longue!");
                    $a2 = ''; // aOui
                    $j0 = $j + 48;
                    if ($j0 > $fin)
                        $j0 = $fin;
                    $ok4 = 1;
                    while (($j < $j0) && ($ok4)) {
                        $a4 = $formulaire[$j++];
                        if ($a4 == ',') {
                            if ($formulaire[$j] == ',')
                                $j++;
                            else
                                $ok4 = 0;
                        }
                        if ($ok4)
                            $a2.=$a4;
                    }
                    if ($ok4)
                        erreur("Erreur:comparaison trop longue!");
                    $a3 = ''; // aNon
                    $j0 = $j + 48;
                    if ($j0 > $fin)
                        $j0 = $fin;
                    $ok4 = 1;
                    while (($j < $j0) && ($ok4)) {
                        $a4 = $formulaire[$j++];
                        if ($a4 == ',') {
                            if ($formulaire[$j] == ',')
                                $j++;
                            else
                                $ok4 = 0;
                        }
                        if ($ok4)
                            $a3.=$a4;
                    }
                    if ($ok4)
                        erreur("Erreur:comparaison trop longue!");
                    if ($formulaire[$j++] != "]")
                        erreur("Erreur: comparaison mal form&eacute;e");
                    $i0 = 0;
                    while (($i0 < $l) && ($a0 != $tbl_table[$i0]))
                        $i0++;
                    if ($i0 >= $l)
                        erreur("Erreur:la table " . $a0 . " n'a pas &eacute;t&eacute; trouv&eacute;e!");
                    $i = $ts[$i0];
                    while (($i < $ts[$i0 + 1]) && ($a != $tl_tbl[$i]))
                        $i++;
                    if ($i0 >= $l)
                        erreur("Erreur:le champ " . $a . " n'a pas &eacute;t&eacute; trouv&eacute;!");
                    $r.='if ($ligne[' . $i . ']' . $b1;
                    if ($a1[0] == '[') {
                        $a0 = substr($a1, 1);
                        $a0 = substr($a0, 0, -1);
                        $i = strpos($a0, '.');
                        $a = substr($a0, $i + 1);
                        $a0 = substr($a0, 0, $i);
                        $i = $i0 = 0;
                        while (($i0 < $l) && ($a0 != $tbl_table[$i0]))
                            $i0++;
                        if ($i0 >= $l)
                            erreur("Erreur:la table " . $a0 . " n'a pas &eacute;t&eacute; trouv&eacute;e!");
                        $i = $ts[$i0];
                        while (($i < $ts[$i0 + 1]) && ($a != $tl_tbl[$i]))
                            $i++;
                        if ($i >= $ts[$i0 + 1])
                            erreur("Erreur:le champ " . $a . " n'a pas &eacute;t&eacute; trouv&eacute;!");
                        $r.='$ligne[' . $i . ']' . ') echo ';
                    }
                    else {
                        if ((!is_numeric($a1)) && (strcmp($a1, '\'\'')))
                            $a1 = '\'' . $a1 . '\'';
                        $r.=$a1 . ') echo ';
                    }
                    if ($a2[0] == '[') {
                        $a0 = substr($a2, 1);
                        $a0 = substr($a0, 0, -1);
                        $i = strpos($a0, '.');
                        $a = substr($a0, $i + 1);
                        $a0 = substr($a0, 0, $i);
                        $i = $i0 = 0;
                        while (($i0 < $l) && ($a0 != $tbl_table[$i0]))
                            $i0++;
                        if ($i0 >= $l)
                            erreur("Erreur:la table " . $a0 . " n'a pas &eacute;t&eacute; trouv&eacute;e!");
                        $i = $ts[$i0];
                        while (($i < $ts[$i0 + 1]) && ($a != $tl_tbl[$i]))
                            $i++;
                        if ($i >= $ts[$i0 + 1])
                            erreur("Erreur:le champ " . $a . " n'a pas &eacute;t&eacute; trouv&eacute;!");
                        $r.='$ligne[' . $i . ']' . ";\n";
                    }
                    else {
                        if (strcmp($a2, '\'\''))
                            $a2 = '\'' . $a2 . '\'';
                        $r.=$a2 . ";\n";
                    }
                    $r.='else echo ';
                    if ($a3[0] == '[') {
                        $a0 = substr($a3, 1);
                        $a0 = substr($a0, 0, -1);
                        $i = strpos($a0, '.');
                        $a = substr($a0, $i + 1);
                        $a0 = substr($a0, 0, $i);
                        $i = $i0 = 0;
                        while (($i0 < $l) && ($a0 != $tbl_table[$i0]))
                            $i0++;
                        if ($i0 >= $l)
                            erreur("Erreur:la table " . $a0 . " n'a pas &eacute;t&eacute; trouv&eacute;e!");
                        $i = $ts[$i0];
                        while (($i < $ts[$i0 + 1]) && ($a != $tl_tbl[$i]))
                            $i++;
                        if ($i >= $ts[$i0 + 1])
                            erreur("Erreur:le champ " . $a . " n'a pas &eacute;t&eacute; trouv&eacute;!");
                        $r.='$ligne[' . $i . ']' . ";\n";
                    }
                    else {
                        if (strcmp($a3, '\'\''))
                            $a3 = '\'' . $a3 . '\'';
                        $r.=$a3 . ";\n";
                    }
                } //si_
            } elseif ($formulaire[$j + 1] == '$') {
                // variable programme
                $j++;
                $j0 = $j + 24;
                $a = '';
                while (($j < $j0) && ($formulaire[$j] != ']'))
                    $a.=$formulaire[$j++];
                if ($j < $j0) {
                    $j++;
                    $i = 0;
                    while (($i < $n_tbl_var) && ($tbl_var[$i] != $a))
                        $i++;
                    if ($i >= $n_tbl_var)
                        erreur("Erreur:la variable programme " . $a . " n'a pas ete trouvee!");
                    $r.='echo ' . $a . ";\n";
                } else
                    erreur("Erreur:nom de variable mal formee!");
            } else {
                $a0 = ''; // nom de la table
                $j++;
                $j0 = $j + 24; // longueur max d'une des parties
                while (($j < $j0) && ($formulaire[$j] != '.'))
                    $a0.=$formulaire[$j++];
                if ($j >= $j0)
                    erreur("le champ du formulaire [" . $a0 . " ... est mal forme!");
                $j++;
                $a = '';
                $j0 = $j + 24;
                while (($j < $j0) && ($formulaire[$j] != ']'))
                    $a.=$formulaire[$j++];
                if ($j >= $j0)
                    erreur("le champ du formulaire [" . $a0 . "." . $a . " ... est mal forme!");
                $i = 0;
                $i0 = 0;
                while (($i0 < $l) && ($tbl_table[$i0] != $a0)) $i0++;
                while (($i < $l0) && ($tl_tbl[$i] != $a)) $i++;
                if (($i0 >= $l) || ($i >= $l0))
                    erreur("Le champ du formulaire [" . $a0 . "." . $a . "] n'a pas ete trouve dans la selection!3 ".$i0.','.$i.' ');
                $r.='echo str_replace(\'"\',\'&quot;\',$ligne[' . $i . "]);\n";
                $ind_form = 1;
                $j++;
            }
        } // else fonctions
    }
    if ($fin > 0) {
        $r.='echo \'<hr \>\';' . "\n";
//		$r.='$n1+=$l0;'."\n";??
        $r.="}\n";
    }
    if ($sep3) { // element [htm(...
        $r = str_replace('"submit"', '"submit" onclick="sauve2();"', $r);
        $r.='echo "<script type=\"text/javascript\">";' . "\n";
        $r.="echo \"function sauve2(){\";\n";
        for ($i = 0; $i < $editor_ind; $i++)
            $r.='echo "fermeture(\'' . $tab_editor_champ[$i] . '\');";' . "\n";
        $r.="echo \"}\";\n";
        $r.="echo '</script>';\n";
    }
    $r.='echo "\\n".\'</BODY>\'."\\n";' . "\n";
    $r.='echo \'</HTML>\'."\\n";' . "\n";
    $r.="?>\n";
//	$r=str_replace("\"submit\"","submit",$r);
    $rq = fopen($rep_base . '/' . $t_0['file_etat'] . ".php", "w");
$r=str_replace('</fort>','</font>',$r);
    fwrite($rq, $r);
    fclose($rq);
    echo "<script language=\"javascript\">window.open(\"" . $rep_base2 . "/" . $t_0['file_etat'] . ".php\", \"" . $t_0['file_etat'] . "\")";
    echo "</script>";
} // if (($_POST['UseF']) && (strlen($t_0['file_etat'])>1))
echo "Formulaire <HR>\n";
echo "&nbsp;&nbsp;<INPUT TYPE=SUBMIT NAME='SauveF' VALUE='Enregistrer' onclick=\"bouton_sauve();\">\n";
echo "&nbsp;&nbsp;<INPUT TYPE=SUBMIT NAME='ChargeF' VALUE='Editer' onclick=\"bouton_sauve();\">\n";
echo "&nbsp;&nbsp;<INPUT TYPE=SUBMIT NAME='UseF' VALUE='Utiliser' onclick=\"bouton_sauve();\">\n";
$s = 'var l0=' . $l0 . ";\n"; // nom des tables et des champs pour javascript -> liens/tables.js
$s.='var ts1=' . $ts[1] . ";\n";
$s.='var sql_tbl = new Array(';
$sep1 = 0; // plus d'un élément dans le tableau
for ($p = 0; $p < $l; $p++) {
    if ($sep1)
        $s.=', \'' . $tbl_table[$p] . '\'';
    else
        $s.='\'' . $tbl_table[$p] . '\'';
    $sep1 = 1;
}
$s.=");\n";
$s.='var sql_chp0 = new Array(';
$sep1 = 0;
for ($i0 = 0; $i0 < $ts[1]; $i0++) {
    if ($sep1)
        $s.=', \'' . $tl_tbl[$i0] . '\'';
    else
        $s.='\'' . $tl_tbl[$i0] . '\'';
    $sep1 = 1;
}
$s.=");\n";
$s.='var sql_champ = new Array(';
$sep1 = 0;
for ($i0 = 0; $i0 < $l; $i0++)
    for ($i = $ts[$i0]; $i < $ts[$i0 + 1]; $i++) {
        if ($sep1)
            $s.=', \'[' . $tbl_table[$i0] . '.' . $tl_tbl[$i] . ']\'';
        else
            $s.='\'[' . $tbl_table[$i0] . '.' . $tl_tbl[$i] . ']\'';
        $sep1 = 1;
    }
$s.=");\n";
// fichier en php du repertoire utilisateur
$rq = opendir($rep_base) or erreur("Erreur:ouverture du repertoire de stockage des scripts!");
$i = 0; // nbe de fichiers
$s.='var ListePhp=new Array(';
while (false !== ($a2 = readdir($rq))) {
    $a0 = substr($a2, -4);
    if ($a0 == '.php') {
        if (!$i)
            $s.='\'' . substr($a2, 0, -4) . '\'';
        else
            $s.=', \'' . substr($a2, 0, -4) . '\'';
        $i++;
    }
}
closedir($rq);
$s.=");\n";
$s.='var nbListePhp=' . $i . ";\n";
if ($i > 1)
    $s.='ListePhp.sort();' . "\n";
// tableau des variables programmes
$s.='var tbl_var=new Array(';
$s.='\'[' . $tbl_var[0] . ']\'';
for ($i = 1; $i < $n_tbl_var; $i++)
    $s.=', \'[' . $tbl_var[$i] . ']\'';
$s.=');' . "\n";
$s.='var tbl_glob=new Array(\'' . $tbl_var[0] . '\',\'' . $tbl_var[1] . '\',\'' . $tbl_var[2] . '\');' . "\n";
$rq = fopen($rep_base . '/tables.js', "w");
fwrite($rq, $s);
fclose($rq);
// constitution des fiches
if ($ts[1]>1){
$s='var fichesIdx=new Array(';
$s2='var fichesVal=new Array(';
$clause='select '.$tl_tbl[0].','.$tl_tbl[1].' from '.$tbl_table[0];
$result=$conn->query($clause) or die("Erreur:recherche des fiches!".$clause);
$ligne=$result->fetch_row();
$s.="'".str_replace("'","\\'",substr($ligne[0],0,64))."'";
$s2.="'".str_replace("'","\\'",substr($ligne[1],0,64))."'";
while($ligne=$result->fetch_row()){
	$s.=",'".str_replace("'","\\'",substr($ligne[0],0,64))."'";
	$s2.=",'".str_replace("'","\\'",substr($ligne[1],0,64))."'";
}
$s.=");\n";
$s2.=");\n";
$rq=fopen($rep_base.'/'.$t_0['file_etat'].'.fiches','w') or die("Erreur:ouverture fichier des fiches!");
fwrite($rq,$s);
fwrite($rq,$s2);
fclose($rq);
} // ts[1]>1
$formulaire = str_replace("\n", " ", $formulaire);
$formulaire = str_replace("\r", " ", $formulaire);
$formulaire = str_replace("'", "\\'", $formulaire);
$formulaire = str_replace("  ", "", $formulaire);
// appel editor
echo "\n<script TYPE=\"text/javascript\">\n";
echo "function load(){\n";
echo ' document.getElementById("fenetre").contentDocument.body.innerHTML=\'' . $formulaire . "';\n";
echo " document.getElementById(\"fenetre\").contentDocument.designMode=\"On\";\n";
// echo " document.getElementById(\"fenetre\").contentDocument.execCommand('insertBrOnreturn',false,true);\n";
echo "document.getElementById(\"fenetre\").contentWindow.focus();\n";
echo "}\n";
echo "function vide(){\n";
echo "	getIFrameDocument(\"fenetre\").body.innerHTML='';";
echo "	document.getElementById('fenetre').contentWindow.focus();\n";
echo "}\n";
echo "function bouton_sauve(){\n";
echo "	var ptrFormulaire=document.getElementById(\"formulaire\");\n";
echo "	ptrFormulaire.value=getIFrameDocument(\"fenetre\").body.innerHTML;\n";
echo "}\n";
echo "function defImg(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/img.php\",\"backcolorv1\",\"menubar=no, status=no, location=no, dependent=yes, width=500, height=240 scrollbars=yes\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function sauve(){\n";
echo "var txt= getIFrameDocument(\"fenetre\").body.innerHTML;\n";
echo "alert(txt);\n";
echo "}\n";
echo "function defTexte(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/Texte.php\",\"backcolorv1\",\"menubar=no, status=no, location=no, dependent=yes, width=500, height=240 scrollbars=yes\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defListe(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/Liste.php\",\"backcolorv1\",\"menubar=no, status=no, location=no, dependent=yes, width=500, height=400, scrollbars=yes\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defCase(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/Case.php\",\"backcolorv1\",\"menubar=no, status=no, location=no, dependent=yes, width=200, height=210, scrollbars=yes\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defChamp(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/Champ.php\",\"backcolorv1\",\"width=250, height=300, menubar=no, status=no, location=no, dependent=yes, , scrollbars=yes\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defExtArea(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/ExtArea.php\",\"backcolorv1\",\"menubar=no, status=no, scrollbars=no, location=no, dependent=yes, width=200, height=250\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defExtText(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/ExtText.php\",\"backcolorv1\",\"menubar=no, status=no, scrollbars=no, location=no, dependent=yes, width=200, height=250\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defFonctions(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/Fonctions.php\",\"backcolorv1\",\"menubar=no, status=no, scrollbars=no, location=no, dependent=yes, width=350, height=250, scrollbars=yes\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defHTML(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/HTML.php\",\"backcolorv1\",\"menubar=no, status=no, scrollbars=no, location=no, dependent=yes, width=200, height=350\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defLiens(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/Liens.php\",\"backcolorv1\",\"menubar=no, status=no, scrollbars=no, location=no, dependent=yes, width=300, height=250\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defListChamp(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/ListChamp.php\",\"backcolorv1\",\"menubar=no, status=no, scrollbars=no, location=no, dependent=yes, width=300, height=420\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defMode(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/Mode.html\",\"backcolorv1\",\"menubar=no, status=no, scrollbars=no, location=no, dependent=yes, width=200, height=180\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defSi(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/Si.php\",\"backcolorv1\",\"menubar=no, status=no, scrollbars=no, location=no, dependent=yes, width=500, height=300\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defZoneTexte(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/ZoneTexte.php\",\"backcolorv1\",\"menubar=no, status=no, scrollbars=no, location=no, dependent=yes, width=300, height=280\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defDiv(){\n";
echo "	var pan1=window.open(\"js/ip/" . $rep0 . "/Div.html\",\"backcolorv1\",\"scrollbars=yes, dependent=yes, width=700\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "function defForme(){\n";
echo "	var pan1=window.open(\"js/Forme.html\",\"backcolorv1\",\"dependent=yes, width=300, height=180, scrollbars=yes, menubar=no, status=no, location=no\");\n";
echo "	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};\n";
echo "}\n";
echo "</script>\n";
echo "<center>\n";
echo "   <table cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"grey\" border=\"2\">\n";
echo "     <tr>\n";
echo "       <td>\n";
echo "         <div id=\"outils\">\n";
echo "<img src=\"editor/h1.gif\" alt=\"H1\" \n";
echo "          width=\"24\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('formatblock','<h1>');\">\n";
echo "<img src=\"editor/h2.gif\" alt=\"H2\" \n";
echo "          width=\"24\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('formatblock','<h2>');\">\n";
echo "<img src=\"editor/h3.gif\" alt=\"H3\" \n";
echo "          width=\"24\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('formatblock','<h3>');\">\n";
echo "<img src=\"editor/h4.gif\" alt=\"H4\"\n";
echo "          width=\"24\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('formatblock','<h4>');\">\n";
echo "<img src=\"editor/h5.gif\" alt=\"H5\"\n";
echo "          width=\"24\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('formatblock','<h5>');\">\n";
echo "<img src=\"editor/h6.gif\" alt=\"H6\"\n";
echo "          width=\"24\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('formatblock','<h6>');\">\n";
echo "<img src=\"editor/pre.gif\" alt=\"pre\"\n";
echo "          width=\"24\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('formatblock','<pre>');\">\n";
echo "<img src=\"editor/addresse.gif\" alt=\"adresse\"\n";
echo "          width=\"24\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('formatblock','<address>');\">\n";
echo "<img src=\"editor/p.gif\" alt=\"paragraphe\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('formatblock','<p>');\">\n";
echo "<img src=\"editor/ecriture.gif\" alt=\"couleur\"\n";
echo "	width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defForeColor();\">\n";
echo "<img src=\"editor/fond.gif\" alt=\"arrière plan\"\n";
echo "	width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defBackColor();\">\n";
echo "<img src=\"editor/exposant.gif\" alt=\"exposant\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('superscript',null);\">\n";
echo "<img src=\"editor/indice.gif\" alt=\"indice\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('subscript',null);\">\n";
echo "<img src=\"editor/souligne.gif\" alt=\"sousligne\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('underline',null);\">\n";
echo "<img src=\"editor/efface.gif\" alt=\"efface\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('undo',null);\">\n";
echo "<img src=\"editor/texte.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('removeformat',null);\">\n";
echo "<img src=\"editor/bold.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('bold',null);\">\n";
echo "<img src=\"editor/italic.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('italic',null);\">\n";
echo "<img src=\"editor/indente.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('indent',null);\">\n";
echo "<img src=\"editor/desindente.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('outdent',null);\">\n";
echo "<img src=\"editor/left.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('justifyleft',null);\">\n";
echo "<img src=\"editor/center.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('justifycenter',null);\">\n";
echo "<img src=\"editor/right.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('justifyright',null);\">\n";
echo "<img src=\"editor/justify.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('fulljustify',null);\">\n";
echo "<img src=\"editor/table.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defTable();\">\n";
echo "<img src=\"editor/sauve.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"sauve();\">\n";
echo "<img src=\"editor/lst.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('insertunorderedlist',null);\">\n";
echo "<img src=\"editor/num.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"formate('insertorderedlist',null);\">\n";
echo "<img src=\"editor/img.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defImg();\">\n";
echo "<img src=\"editor/vide.gif\" width=\"16\" height=\"16\" align=\"middle\" onClick=\"vide();\">\n";
echo "<HR>\n";
echo "<img src=\"js/Texte.gif\" alt=\"afficher champ\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defTexte();\">\n";
echo "<img src=\"js/Liste.gif\" alt=\"liste\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defListe();\">\n";
echo "<img src=\"js/Case.gif\" alt=\"case à cocher\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defCase();\">\n";
echo "<img src=\"js/Champ.gif\" alt=\"saisie de champ\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defChamp();\">\n";
echo "<img src=\"js/ExtArea.gif\" alt=\"TextArea\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defExtArea();\">\n";
echo "<img src=\"js/ExtText.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defExtText();\">\n";
echo "<img src=\"js/Fonctions.gif\" alt=\"fonction\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defFonctions();\">\n";
echo "<img src=\"js/HTML.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defHTML();\">\n";
echo "<img src=\"js/Liens.gif\" alt=\"lien\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defLiens();\">\n";
echo "<img src=\"js/ListChamp.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defListChamp();\">\n";
echo "<img src=\"js/Mode.gif\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defMode();\">\n";
echo "<img src=\"js/Si.gif\" alt=\"si\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defSi();\">\n";
echo "<img src=\"js/ZoneTexte.gif\" alt=\"zone de texte\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defZoneTexte();\">\n";
echo "<img src=\"js/Div.gif\" alt=\"div\"\n";
echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
echo "          onClick=\"defDiv();\">\n";
/* echo "<img src=\"js/Forme.gif\"\n";
  echo "          width=\"16\" height=\"16\" align=\"middle\"\n";
  echo "          onClick=\"defForme();\">\n"; */
echo "<input type=\"hidden\" name=\"formulaire\" id=\"formulaire\" value=\"" . str_replace("\"", "&quot;", $formulaire) . "\">\n";
echo "</div>\n";
echo "</td>\n";
echo "</tr>\n";
echo "</table>\n";
echo "</center>\n";
echo "</FORM>\n";
echo "<center><iframe id=\"fenetre\" frameborder=\"1\" height=\"350 px\" width=\"75%\" onload=\"load();\"></iframe></center>\n";
echo memory_get_usage();
?>
