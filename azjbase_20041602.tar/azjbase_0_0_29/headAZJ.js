function chgtIndice(n){
	var obj=document.getElementById('indicev');
	obj.value=n;
	document.forms[0].submit();
}
function playStopAudio(son){
	var obj1=document.getElementById('_son');
	if (obj1.value) {
		var obj2=document.getElementById(obj1.value);
		obj2.pause();
		obj2.value='';
	}
	var obj=document.getElementById(son);
	if (obj.paused){
		 obj.play();
		obj1.value=son;
	}
	else obj.pause();
}

