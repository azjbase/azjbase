function chgtIndice(n){
	var obj=document.getElementById('indicev');
	obj.value=n;
	document.forms[0].submit();
}

