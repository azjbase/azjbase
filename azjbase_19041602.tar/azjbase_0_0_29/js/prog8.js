// variables globales
	declare_nom=new Array();
	declare_val=new Array(); // definition
	decale=0; // décalage boucle
	lig_type=new Array(); // type des lignes
	t_sql=0; // place dans declare pour champ sql

	function sel1_chg(num,selnum){
	var i=0;
	var j=parseInt(num);
	// effacement element precedent
	n=cols[num].childNodes.length;
	i=2;
	while(i<n){
		obj=cols[num].lastChild;
		cols[num].removeChild(cols[num].lastChild);
		i++;
	}
	if (selnum == "Def"){
		cols[num].appendChild(cr_def(num,"op1_",'blue'));
		cols[num].style.color='blue';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_def(num,"op3_",'blue'));
		lig_type[j]=selnum;
	}
	if (selnum == "Style"){
		cols[num].style.color='darkviolet';
		elt[num*6+1].data="couleur de trait";
		cols[num].appendChild(elt[num*6+1]);
		cols[num].appendChild(cr_si_1(num,"op1_",'darkviolet'));
		elt[num*6+2].data="epaisseur de trait";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_si_1(num,"op3_",'darkviolet'));
		lig_type[j]=selnum;
	}
	if (selnum == "="){
		cols[num].appendChild(cr_si_1(num,"op1_",'black'));
		cols[num].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_def(num,"op3_",'black'));
		lig_type[j]=selnum;
	}
	if (selnum == "Si"){
		cols[num].appendChild(cr_si_1(num,"op1_",'green'));
		cols[num].appendChild(cr_si_2(num,'green'));
		cols[num].appendChild(cr_si_1(num,"op3_",'green'));
		cols[num].style.color='green';
		elt[num*6+4].data=" alors ";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cr_si_1(num,"op4_",'green'));
		cols[num].style.color='green';
		elt[num*6+5].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cr_si_1(num,"op5_",'green'));
		lig_type[j]=selnum;
	}
	if (selnum == "Si_"){
		cols[num].appendChild(cr_si_1(num,"op1_",'green'));
		cols[num].appendChild(cr_si_2(num,'green'));
		cols[num].appendChild(cr_def(num,"op3_",'green'));
		cols[num].style.color='green';
		elt[num*6+4].data=" alors ";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cr_si_1(num,"op4_",'green'));
		cols[num].style.color='green';
		elt[num*6+5].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cr_si_1(num,"op5_",'green'));
		lig_type[j]=selnum;
	}
	if (selnum == "Si__"){
		cols[num].appendChild(cr_si_1(num,"op1_",'green'));
		cols[num].appendChild(cr_si_2(num,'green'));
		cols[num].appendChild(cr_def(num,"op3_",'green'));
		cols[num].style.color='green';
		elt[num*6+4].data=" alors ";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cr_si_1(num,"op4_",'green'));
		cols[num].style.color='green';
		elt[num*6+5].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cr_def(num,"op5_",'green'));
		lig_type[j]=selnum;
	}
	if (selnum == "Fonc"){
		cols[num].appendChild(cr_si_1(num,"op1_",'black'));
		cols[num].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_f_1(num));
		cols[num].appendChild(cr_si_1(num,"op3_",'black'));
		lig_type[j]=selnum;
	}
	if ((selnum == 'Fin') || (selnum == '}')) lig_type[j]=selnum;
	if (selnum == 'Prog_'){
		cols[num].appendChild(cr_si_1(num,"op1_",'black'));
		cols[num].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_si_1(num,"op2_",'black'));
		cols[num].appendChild(cr_opr_1(num,"op3_"));
		cols[num].appendChild(cr_def(num,"op4_",'black'));
		lig_type[j]=selnum;
	}
	if (selnum == 'Boucle'){
		decale+=12;
		cols[num].appendChild(cr_si_1(num,"op1_",'red'));
		cols[num].style.color='red';
		elt[num*6+2].data=" variant de ";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_si_1(num,"op2_",'red'));
		cols[num].style.color='red';
		elt[num*6+3].data=" à ";
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(cr_si_1(num,"op3_",'red'));
		cols[num].style.color='red';
		elt[num*6+4].data='{';
		cols[num].appendChild(elt[num*6+4]);
		lig_type[j]=selnum;
	}
	if (selnum == 'Tant que'){
		decale+=12;
		cols[num].appendChild(cr_si_1(num,"op1_",'red'));
		cols[num].appendChild(cr_si_2(num,'red'));
		cols[num].appendChild(cr_si_1(num,"op3_",'red'));
		cols[num].style.color='red';
		elt[num*6+4].data='{';
		cols[num].appendChild(elt[num*6+4]);
		lig_type[j]=selnum;
	}
	if (selnum == 'Rect'){
		elt[num*6+1].data="Origine x";
		cols[num].appendChild(elt[num*6+1]);
		cols[num].appendChild(cr_si_1(num,"op1_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+2].data="y";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_si_1(num,"op2_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+3].data="largeur";
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(cr_si_1(num,"op3_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+4].data="hauteur";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cr_si_1(num,"op4_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+5].data="en";
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cr_si_1(num,"op5_",'darkviolet'));
		cols[num].style.color='darkviolet';
		lig_type[j]=selnum;
	}
	if (selnum == 'Arc'){
		elt[num*6+1].data="reliant x1";
		cols[num].appendChild(elt[num*6+1]);
		cols[num].appendChild(cr_si_1(num,"op1_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+2].data="y1";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_si_1(num,"op2_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+3].data="a x2";
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(cr_si_1(num,"op3_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+4].data="y2";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cr_si_1(num,"op4_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+5].data="d'angle";
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cr_si_1(num,"op5_",'darkviolet'));
		cols[num].style.color='darkviolet';
		lig_type[j]=selnum;
	}
	if (selnum == 'Ligne'){
		elt[num*6+1].data="reliant x1";
		cols[num].appendChild(elt[num*6+1]);
		cols[num].appendChild(cr_si_1(num,"op1_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+2].data="y1";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_si_1(num,"op2_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+3].data=" a x2";
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(cr_si_1(num,"op3_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+4].data="y2";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cr_si_1(num,"op4_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+5].data="en";
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cr_si_1(num,"op5_",'darkviolet'));
		cols[num].style.color='darkviolet';
		lig_type[j]=selnum;
	}
	if (selnum == 'Transforme'){
		elt[num*6+1].data="de [[";
		cols[num].appendChild(elt[num*6+1]);
		cols[num].appendChild(cr_si_1(num,"op1_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+2].data=",";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_si_1(num,"op2_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+3].data="][";
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(cr_si_1(num,"op3_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+4].data=",";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cr_si_1(num,"op4_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+5].data="]] de facteur";
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cr_si_1(num,"op5_",'darkviolet'));
		cols[num].style.color='darkviolet';
		lig_type[j]=selnum;
	}
	if (selnum == 'Quadratic'){
		elt[num*6+1].data="de centre (";
		cols[num].appendChild(elt[num*6+1]);
		cols[num].appendChild(cr_si_1(num,"op1_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+2].data=",";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_si_1(num,"op2_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+3].data=") de dim x=";
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(cr_si_1(num,"op3_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+4].data=" y=";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cr_si_1(num,"op4_",'darkviolet'));
		cols[num].style.color='darkviolet';
		elt[num*6+5].data=" en ";
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cr_si_1(num,"op5_",'darkviolet'));
		cols[num].style.color='darkviolet';
		lig_type[j]=selnum;
	}
	if ((decale>11) && (selnum == '}')) decale-=12;
	if (selnum == 'Echo'){
		cols[num].appendChild(cr_def2(num,"op1_",'maroon'));
		cols[num].appendChild(cr_si_1(num,"op2_",'maroon'));
		lig_type[j]="Echo";
	}
	if (parseInt(selnum) == j){ // ligne d'affectation
		cols[num].appendChild(cr_si_1(num,"op1_",'black'));
		cols[num].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_si_1(num,"op2_",'black'));
		cols[num].appendChild(cr_opr_1(num,"op3_"));
		cols[num].appendChild(cr_si_1(num,"op4_",'black'));
		lig_type[j]="Prog";
	}
	cols[num].appendChild(tblInsere[num]);
	cols[num].appendChild(tblSupprime[num]);
	n=document.getElementById('nbe').value;
	num++;
	if (num > n) prg_fin(num);
}

	function vnom(txt){ // indique si un non est correct
	var i=1;
	var c;
	var n=txt.length;
	var ok=0; // valeur de retour
	if (n==0) return ok;
	c=txt.charAt(0);
	if (c == '_') ok=1;
	if ((c >= 'A') && (c <= 'Z')) ok=1;
	if ((c >= 'a') && (c <= 'z')) ok=1;
	if (!ok) return 0;
	while((i<n) && (ok)){
		ok=0;
		c=txt.charAt(i++);
		if (c == '_') ok=1;
		if ((c >= 'A') && (c <= 'Z')) ok=1;
		if ((c >= 'a') && (c <= 'z')) ok=1;
		if ((c >= '0') && (c <= '9')) ok=1;
	}
	return ok;
}

    function cr_select_1(num){
	var a=document.createElement("select");
	a.name="type_"+num;
	a.size="1";
	a.id="type_"+num;
	a.onchange=function(){sel1_chg(num,this[this.selectedIndex].value);};
	var nOption;
	nOption=new Option("","",false,false);
	a.options.add(nOption);
	nOption=new Option(num,num,false,false);
	a.options.add(nOption);
	nOption=new Option(num+' Si','Si',false,false);
	nOption.style.color='green';
	a.options.add(nOption);
	nOption=new Option(num+' Def','Def',false,false);
	nOption.style.color='blue';
	a.options.add(nOption);
	nOption=new Option(num+" Fonc","Fonc",false,false);
	a.options.add(nOption);
	nOption=new Option(num+" Prog_","Prog_",false,false);
	a.options.add(nOption);
	nOption=new Option(num+" Si_","Si_",false,false);
	nOption.style.color='green';
	a.options.add(nOption);
	nOption=new Option(num+" Si__","Si__",false,false);
	nOption.style.color='green';
	a.options.add(nOption);
	nOption=new Option(num+" =","=",false,false);
	a.options.add(nOption);
	nOption=new Option(num+" Boucle","Boucle",false,false);
	nOption.style.color='red';
	a.options.add(nOption);
	nOption=new Option(num+" }","}",false,false);
	nOption.style.color='red';
	a.options.add(nOption);
	nOption=new Option(num+" Tant que","Tant que",false,false);
	nOption.style.color='red';
	a.options.add(nOption);
	nOption=new Option(num+" Rect","Rect",false,false);
	nOption.style.color='darkviolet';
	a.options.add(nOption);
	nOption=new Option(num+" Arc","Arc",false,false);
	nOption.style.color='darkviolet';
	a.options.add(nOption);
	nOption=new Option(num+" Ligne","Ligne",false,false);
	nOption.style.color='darkviolet';
	a.options.add(nOption);
	nOption=new Option(num+" Transforme","Transforme",false,false);
	nOption.style.color='darkviolet';
	a.options.add(nOption);
	nOption=new Option(num+" Quadratic","Quadratic",false,false);
	nOption.style.color='darkviolet';
	a.options.add(nOption);
	nOption=new Option(num+" Style","Style",false,false);
	nOption.style.color='darkviolet';
	a.options.add(nOption);
	nOption=new Option(num+" Fin","Fin",false,false);
	a.options.add(nOption);
	nOption=new Option(num+" Echo","Echo",false,false);
	a.options.add(nOption);
	return a;
}
 
    function cr_opr_1(num,nom){
	var a=document.createElement("select");
	a.name=nom+num;
	a.size="1";
	a.id=nom+num;
	var nOption;
	nOption=new Option("+","+",false,false);
	a.options.add(nOption);
	nOption=new Option("-","-",false,false);
	a.options.add(nOption);
	nOption=new Option("*","*",false,false);
	a.options.add(nOption);
	nOption=new Option("/","/",false,false);
	a.options.add(nOption);
	nOption=new Option("%","%",false,false);
	a.options.add(nOption);
	nOption=new Option(".",".",false,false);
	a.options.add(nOption);
	nOption=new Option(":",":",false,false); // extraction d'un caractère
	a.options.add(nOption);
	nOption=new Option("^","^",false,false); // puissance
	a.options.add(nOption);
	return a;
}

	function cs_opr_1(num,nom,slt){
		var obj=cr_opr_1(num,nom);
		obj.value=slt;
		obj.selectedIndex=rech_sel(obj,slt);
		return obj;
	}

    function cr_f_1(num){
	var a=document.createElement("select");
	a.name='op2_'+num;
	a.size="1";
	a.id='op2_'+num;
	var nOption;
	nOption=new Option("Ent","Ent",false,false);
	a.options.add(nOption);
	nOption=new Option("Frac","Frac",false,false);
	a.options.add(nOption);
	nOption=new Option("log","Log",false,false);
	a.options.add(nOption);
	nOption=new Option("Exp","exp",false,false);
	a.options.add(nOption);
	nOption=new Option("Abs","abs",false,false);
	a.options.add(nOption);
	nOption=new Option("Long","Long",false,false);
	a.options.add(nOption);
	nOption=new Option("sqrt","sqrt",false,false);
	a.options.add(nOption);
	nOption=new Option("Inv","Inv",false,false);
	a.options.add(nOption);
	nOption=new Option("Cos","cos",false,false);
	a.options.add(nOption);
	nOption=new Option("Sin","sin",false,false);
	a.options.add(nOption);
	nOption=new Option("Tan","tan",false,false);
	a.options.add(nOption);
	nOption=new Option("Id","Id",false,false);
	a.options.add(nOption);
	nOption=new Option("Type","Type",false,false);
	a.options.add(nOption);
	return a;
}

	function cs_f_1(num,slt){
		var obj=cr_f_1(num);
		obj.selectedIndex=rech_sel(obj,slt);
		return obj;
}

    function cr_si_1(num,nom,couleur){
	var j=parseInt(num);
	var a=document.createElement("select");
	a.name=nom+num;
	a.size="1";
	a.id=nom+num;
	a.style.color=couleur;
	var nOption;
	var i;
	for(i=0;i<=(j+t_sql);i++){
		if (declare_nom[i] != undefined){
			nOption=new Option(declare_nom[i],declare_nom[i],false,false);
			a.options.add(nOption);
		}
	}
	return a;
}

	function cr_si_2(num,couleur){
		var a=document.createElement("select");
		a.name="op2_"+num;
		a.size="1";
		a.id="op2_"+num;
		a.style.color=couleur;
		var nOption;
		nOption=new Option("=","=",false,false);
		a.options.add(nOption);
		nOption=new Option("<=","<=",false,false);
		a.options.add(nOption);
		nOption=new Option("<","<",false,false);
		a.options.add(nOption);
		nOption=new Option(">",">",false,false);
		a.options.add(nOption);
		nOption=new Option(">=",">=",false,false);
		a.options.add(nOption);
		nOption=new Option("!=","!=",false,false);
		a.options.add(nOption);
		nOption=new Option("~","~",false);
		a.options.add(nOption);
		return a;
}

	function cs_si_1(num,nom,couleur,slt){
		var obj=cr_si_1(num,nom,couleur);
		obj.value=slt;
//		obj.selectedIndex=rech_sel(obj,slt);
		return obj;
}
	function cs_si_2(num,couleur,slt){
		var obj=cr_si_2(num,couleur);
		obj.selectedIndex=rech_sel(obj,slt);
		return obj;
}

	function txt_blur(num,tid,valeur){
	var nfonc=tid.substr(0,4);
	var j=parseInt(num);
	if ((nfonc == "op1_") || (nfonc == "op2_")){
		var a0=document.getElementById("op1_"+num);
		var a1=a0.value;
		if (!vnom(a1)){
			a1="val_"+num;
			a0.value=a1;
		}
		var a3=document.getElementById("op3_"+num).value;
		declare_nom[j+t_sql]=a1;
		declare_val[j+t_sql]=a3;
	}
}
	function txt_blur2(num,tid,valeur){ // pour Echo
	var nfonc=tid.substr(0,4);
	var j=parseInt(num);
	if (nfonc == "op1_"){
		var a0=document.getElementById("op1_"+num);
		var a1=a0.value;
		declare_val[j+t_sql]=a1;
	}
}

    function cr_def(num,nom,couleur){
	var a=document.createElement("input");
	a.name=nom+num;
	a.id=nom+num;
	a.size="24";
	a.type="text";
	a.maxLength="24";
	a.style.color=couleur;
	a.onblur=function(){txt_blur(num,this.id,this.value);};
	return a;
}
    function cr_def2(num,nom,couleur){
	var a=document.createElement("input");
	a.name=nom+num;
	a.id=nom+num;
	a.size="24";
	a.type="text";
	a.maxLength="80";
	a.style.color=couleur;
	a.onblur=function(){txt_blur2(num,this.id,this.value);};
	return a;
}

    function cs_def(num,nom,v,couleur){
	var a=document.createElement("input");
	a.name=nom+num;
	a.id=nom+num;
	a.size="24";
	a.type="text";
	a.maxLength="24";
	a.style.color=couleur;
	a.value=v;
	a.onblur=function(){txt_blur(num,this.id,this.value);};
	return a;
}

	function cs_def2(num,nom,v,couleur){
		var obj=cr_def2(num,nom,couleur);
		obj.value=v;
		return obj;
}

	function rech_sel(obj,a){
	var n=obj.length;
	var tbl=obj.options;
	var i=0;
	var n=obj.options.length;
	while((i<n) && (tbl[i].value != a)) i++;
	if (i>=n) alert('valeur non trouvée:'+a);
	return i;
}

	function supprime(num){
	var i,n;
	var i0,n0,i1;
	var j=parseInt(num);
	var obj=document.getElementById('nbe');
	var sprg=Array();
	n=parseInt(obj.value);
	sprg=doPrg(j);
//2: suppression des lignes
	for(i=j;i<n+1;i++){
		n0=cols[i].childNodes.length;
		for(i1=0;i1<n0;i1++) cols[i].removeChild(cols[i].lastChild);
	}
	for(i=j;i<n;i++){
		cols[i].parentNode.removeChild(cols[i]);
		lignes[i].parentNode.removeChild(lignes[i]);
	}
// réécriture des lignes
	prg_fin(j);
	i0=0;
	for(i=j+1;i<n;i++){
		if (parseInt(sprg[i0+1]) == sprg[i0]) sprg[i0+1]--;
		sprg[i0]--;
		prg(sprg[i0],sprg[i0+1],sprg[i0+2],sprg[i0+3],sprg[i0+4],sprg[i0+5],sprg[i0+6]);
		i0+=7;
	}
}

	function doPrg(num){ // retourne le tableau des lignes de code après num
	var i,n;
	var i0,n0,i1;
	var j=parseInt(num);
	var obj=document.getElementById('nbe');
	var sprg=Array(); // 2:sauvegarde des lignes concernées, 3:suppression
// des <tr>, 4:création des nouveaux <tr>
	n=parseInt(obj.value);
	i0=0;
	for(i=j+1;i<n+1;i++){
		sprg[i0]=i;
		sprg[i0+1]=document.getElementById('type_'+i).value; for(i1=2;i1<7;i1++) sprg[i0+i1]=''; // fausse supposition
		switch (sprg[i0+1]) {
			case 'Def':
			case 'Style':
			case '=':
				sprg[i0+2]=document.getElementById('op1_'+i).value;
				sprg[i0+4]=document.getElementById('op3_'+i).value;
				break;
			case 'Si':
			case 'Si_':
			case 'Si__':
			case 'Rect':
			case 'Arc':
			case 'Ligne':
			case 'Transforme':
			case 'Quadratic':
				sprg[i0+2]=document.getElementById('op1_'+i).value;
				sprg[i0+3]=document.getElementById('op2_'+i).value;
				sprg[i0+4]=document.getElementById('op3_'+i).value;
				sprg[i0+5]=document.getElementById('op4_'+i).value;
				sprg[i0+6]=document.getElementById('op5_'+i).value;
				break;
			case 'Fonc':
			case 'Boucle':
			case 'Tant que':
				sprg[i0+2]=document.getElementById('op1_'+i).value;
				sprg[i0+3]=document.getElementById('op2_'+i).value;
				sprg[i0+4]=document.getElementById('op3_'+i).value;
				break;
			case 'Prog_':
				sprg[i0+2]=document.getElementById('op1_'+i).value;
				sprg[i0+3]=document.getElementById('op2_'+i).value;
				sprg[i0+4]=document.getElementById('op3_'+i).value;
				sprg[i0+5]=document.getElementById('op4_'+i).value;
				break;
			case 'Echo':
				sprg[i0+2]=document.getElementById('op1_'+i).value;
				sprg[i0+4]=document.getElementById('op2_'+i).value;
				break;
		}
		if (parseInt(sprg[i0+1]) == i){
			sprg[i0+2]=document.getElementById('op1_'+i).value;
			sprg[i0+3]=document.getElementById('op2_'+i).value;
			sprg[i0+4]=document.getElementById('op3_'+i).value;
			sprg[i0+5]=document.getElementById('op4_'+i).value;
		}
		i0+=7;
	}
	return sprg;
}
 
	function insere(num){
	var i,n;
	var i0,n0,i1;
	var j=parseInt(num);
	var obj=document.getElementById('nbe');
	var sprg=Array();
	n=parseInt(obj.value);
	sprg=doPrg(j);
//2: suppression des lignes
	for(i=j+1;i<n+1;i++){
		n0=cols[i].childNodes.length;
		for(i1=0;i1<n0;i1++) cols[i].removeChild(cols[i].lastChild);
	}
	for(i=(j+1);i<n;i++){
		cols[i].parentNode.removeChild(cols[i]);
		lignes[i].parentNode.removeChild(lignes[i]);
	}
// réécriture des lignes
	prg_fin(j+1);
	cols[j+1].appendChild(tblInsere[j+1]);
	cols[j+1].appendChild(tblSupprime[j+1]);
	prg_fin(j+2);
	i0=0;
	for(i=j+1;i<n;i++){
		if (parseInt(sprg[i0+1]) == sprg[i0]) sprg[i0+1]++;
		sprg[i0]++;
		prg(sprg[i0],sprg[i0+1],sprg[i0+2],sprg[i0+3],sprg[i0+4],sprg[i0+5],sprg[i0+6]);
		i0+=7;
	}
}

	function prg_fin(num){
	var obj;
	lig_type[num]="";
	lignes[num]=document.createElement("tr");
	cols[num]=document.createElement("td");
	elt[num*6]=cr_select_1(num);
	cols[num].appendChild(elt[num*6]);
	txt0='';
	for(m0=0;m0<decale;m0++) txt0+='&nbsp;';
	colsDecale[num]=document.createElement('div');
	colsDecale[num].style='float:left; width:'+decale+' px; ';
	colsDecale[num].innerHTML=txt0;
	cols[num].appendChild(colsDecale[num]);
	for (i=1;i<6;i++) elt[num*6+i]=document.createTextNode("");
	lignes[num].appendChild(cols[num]);
       	tablebody.appendChild(lignes[num]);
	tblInsere[num]=document.createElement('img');
	tblInsere[num].src='editor/insere.png';
	tblInsere[num].onclick=function(){insere(num);};
	tblSupprime[num]=document.createElement('img');
	tblSupprime[num].src='editor/suppr.png';
	tblSupprime[num].onclick=function(){supprime(num);};
	document.getElementById('nbe').value=num;
}

	function prg(num,b,a1,a2,a3,a4,a5){ // genere la ligne equivalente
	var i=0;
	var j=parseInt(num);
	var obj;
	var selnum=b;
	lig_type[num]=b;
	obj=document.getElementById('type_'+j);
	if (selnum == "Def"){
		obj.selectedIndex=3;
		cols[num].appendChild(cs_def(num,"op1_",a1,'blue'));
		cols[num].style.color='blue';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cs_def(num,"op3_",a3,'blue'));
		declare_nom[t_sql+j]=a1;
		declare_val[t_sql+j]=a3;
	}
	if (selnum == "Style"){// mauvais
		cols[num].style.color='darkviolet';
		elt[num*6+1].data="couleur de trait";
		cols[num].appendChild(elt[num*6+1]);
		cols[num].appendChild(cr_si_1(num,"op1_",'darkviolet'));
		elt[num*6+2].data="epaisseur de trait";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cr_si_1(num,"op3_",'darkviolet'));
		lig_type[j]=selnum;
	}
	if (selnum == "="){
		obj.selectedIndex=8;
		cols[num].appendChild(cs_si_1(num,"op1_",'black',a1));
		cols[num].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cs_def(num,"op3_",a3,'black'));
	}
	if (selnum == "Si"){
		obj.selectedIndex=2;
		cols[num].appendChild(cs_si_1(num,"op1_",'green',a1));
		cols[num].appendChild(cs_si_2(num,'green',a2));
		cols[num].appendChild(cs_si_1(num,"op3_",'green',a3));
		cols[num].style.color='green';
		elt[num*6+4].data=" alors ";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cs_si_1(num,"op4_",'green',a4));
		cols[num].style.color='green';
		elt[num*6+5].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cs_si_1(num,"op5_",'green',a5));
	}
	if (selnum == "Si_"){
		obj.selectedIndex=6;
		cols[num].appendChild(cs_si_1(num,"op1_",'green'),a1);
		cols[num].appendChild(cs_si_2(num,'green',a2));
		cols[num].appendChild(cs_def(num,"op3_",a3,'green'));
		cols[num].style.color='green';
		elt[num*6+4].data=" alors ";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cs_si_1(num,"op4_",'green',a4));
		cols[num].style.color='green';
		elt[num*6+5].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cs_si_1(num,"op5_",'green',a5));
	}
	if (selnum == "Si__"){
		obj.selectedIndex=7;
		cols[num].appendChild(cs_si_1(num,"op1_",'green',a1));
		cols[num].appendChild(cs_si_2(num,'green'),a2);
		cols[num].appendChild(cs_def(num,"op3_",a3,'green'));
		cols[num].style.color='green';
		elt[num*6+4].data=" alors ";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cs_si_1(num,"op4_",'green',a4));
		cols[num].style.color='green';
		elt[num*6+5].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cs_def(num,"op5_",a5,'green'));
	}
	if (selnum == "Fonc"){
		obj.selectedIndex=4;
		cols[num].appendChild(cs_si_1(num,"op1_",'black',a1));
		cols[num].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cs_f_1(num,a2));
		cols[num].appendChild(cs_si_1(num,"op3_",'black',a3));
	}
	if (selnum == '}'){
		obj.selectedIndex=10;
		if (decale>11) decale-=12;
	}
	if (selnum == 'Fin') obj.selectedIndex=18;
	if (selnum == 'Prog_'){
		obj.selectedIndex=5;
		cols[num].appendChild(cs_si_1(num,"op1_",'black',a1));
		cols[num].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cs_si_1(num,"op2_",'black',a2));
		cols[num].appendChild(cs_opr_1(num,"op3_",a3));
		cols[num].appendChild(cs_def(num,"op4_",a4,'black'));
	}
	if (selnum == 'Boucle'){
		decale+=12;
		obj.selectedIndex=9;
		cols[num].appendChild(cs_si_1(num,"op1_",'red',a1));
		cols[num].style.color='red';
		elt[num*6+2].data=" variant de ";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cs_si_1(num,"op2_",'red',a2));
		cols[num].style.color='red';
		elt[num*6+3].data=" à ";
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(cs_si_1(num,"op3_",'red',a3));
		cols[num].style.color='red';
		elt[num*6+4].data='{';
		cols[num].appendChild(elt[num*6+4]);
	}
	if (selnum == 'Tant que'){
		decale+=12;
		obj.selectedIndex=11;
		cols[num].appendChild(cs_si_1(num,"op1_",'red',a1));
		cols[num].appendChild(cs_si_2(num,'red',a2));
		cols[num].appendChild(cs_si_1(num,"op3_",'red',a3));
		cols[num].style.color='red';
		elt[num*6+4].data='{';
		cols[num].appendChild(elt[num*6+4]);
	}
	if (selnum == 'Rect'){
		objselectedIndex=12;
		elt[num*6+1].data="Origine x";
		cols[num].appendChild(elt[num*6+1]);
		cols[num].appendChild(cs_si_1(num,"op1_",'darkviolet',a1));
		cols[num].style.color='darkviolet';
		elt[num*6+2].data="y";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cs_si_1(num,"op2_",'darkviolet',a2));
		cols[num].style.color='darkviolet';
		elt[num*6+3].data="largeur";
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(cs_si_1(num,"op3_",'darkviolet',a3));
		cols[num].style.color='darkviolet';
		elt[num*6+4].data="hauteur";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cs_si_1(num,"op4_",'darkviolet'),a4);
		cols[num].style.color='darkviolet';
		elt[num*6+5].data="en";
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cs_si_1(num,"op5_",'darkviolet',a5));
		cols[num].style.color='darkviolet';
	}
	if (selnum == 'Arc'){
		obj.selectedIndex=13;
		elt[num*6+1].data="reliant x1";
		cols[num].appendChild(elt[num*6+1]);
		cols[num].appendChild(cs_si_1(num,"op1_",'darkviolet',a1));
		cols[num].style.color='darkviolet';
		elt[num*6+2].data="y1";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cs_si_1(num,"op2_",'darkviolet',a2));
		elt[num*6+3].data="a x2";
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(cs_si_1(num,"op3_",'darkviolet',a3));
		elt[num*6+4].data="y2";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cs_si_1(num,"op4_",'darkviolet',a4));
		elt[num*6+5].data="d'angle";
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cs_si_1(num,"op5_",'darkviolet',a5));
	}
	if (selnum == 'Ligne'){
		obj.selectedIndex=14;
		elt[num*6+1].data="reliant x1";
		cols[num].appendChild(elt[num*6+1]);
		cols[num].appendChild(cs_si_1(num,"op1_",'darkviolet',a1));
		cols[num].style.color='darkviolet';
		elt[num*6+2].data="y1";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cs_si_1(num,"op2_",'darkviolet',a2));
		elt[num*6+3].data=" a x2";
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(cs_si_1(num,"op3_",'darkviolet',a3));
		elt[num*6+4].data="y2";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cs_si_1(num,"op4_",'darkviolet',a4));
		elt[num*6+5].data="en";
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cs_si_1(num,"op5_",'darkviolet',a5));
	}
	if (selnum == 'Transforme'){
		obj.selectedIndex=15;
		elt[num*6+1].data="de matrice [[";
		cols[num].appendChild(elt[num*6+1]);
		cols[num].appendChild(cs_si_1(num,"op1_",'darkviolet',a1));
		cols[num].style.color='darkviolet';
		elt[num*6+2].data=",";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cs_si_1(num,"op2_",'darkviolet',a2));
		elt[num*6+3].data="][";
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(cs_si_1(num,"op3_",'darkviolet',a3));
		elt[num*6+4].data=",";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cs_si_1(num,"op4_",'darkviolet',a4));
		elt[num*6+5].data="]] de facteur";
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cs_si_1(num,"op5_",'darkviolet',a5));
	}
	if (selnum == 'Quadratic'){
		obj.selectedIndex=16;
		elt[num*6+1].data="de centre (";
		cols[num].appendChild(elt[num*6+1]);
		cols[num].appendChild(cs_si_1(num,"op1_",'darkviolet',a1));
		cols[num].style.color='darkviolet';
		elt[num*6+2].data=",";
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cs_si_1(num,"op2_",'darkviolet',a2));
		elt[num*6+3].data=") de dim x=";
		cols[num].appendChild(elt[num*6+3]);
		cols[num].appendChild(cs_si_1(num,"op3_",'darkviolet',a3));
		elt[num*6+4].data=" y=";
		cols[num].appendChild(elt[num*6+4]);
		cols[num].appendChild(cs_si_1(num,"op4_",'darkviolet',a4));
		elt[num*6+5].data=" en ";
		cols[num].appendChild(elt[num*6+5]);
		cols[num].appendChild(cs_si_1(num,"op5_",'darkviolet',a5));
	}
	if (selnum == 'Echo'){
		obj.selectedIndex=19;
		cols[num].appendChild(cs_def2(num,"op1_",a1,'maroon'));
		cols[num].appendChild(cs_si_1(num,"op2_",'maroon',a2));
		declare_val[t_sql+j]=a1;
	}
	if (parseInt(selnum) == j){ // ligne d'affectation
		obj.selectedIndex=1;
		cols[num].appendChild(cs_si_1(num,"op1_",'black',a1));
		cols[num].style.color='black';
		elt[num*6+2].data=String.fromCharCode(0x2190);
		cols[num].appendChild(elt[num*6+2]);
		cols[num].appendChild(cs_si_1(num,"op2_",'black',a2));
		cols[num].appendChild(cs_opr_1(num,"op3_",a3));
		cols[num].appendChild(cs_si_1(num,"op4_",'black',a4));
		lig_type[j]="Prog";
	}
	cols[num].appendChild(tblInsere[num]);
	cols[num].appendChild(tblSupprime[num]);
	num++;
	prg_fin(num);
}

    function start() {
	var n;
	var i;
	if (sql_chp0[0] != undefined){
		n=sql_champ.length;
		for(i=0;i<n;i++){
			declare_nom[t_sql]=sql_champ[i];
			declare_val[t_sql++]='';
		}
		n=tbl_glob.length;
		for(i=0;i<n;i++){
			declare_nom[t_sql]=tbl_glob[i];
			declare_val[t_sql++]='';
		}
	}
	tablebody=document.getElementById("Prog");
	var intitules=new Array("Prog","","","","","");
	j=1; // indice ligne
        // creation des cellules
	lignes=new Array(); // tableau des lignes
	cols=new Array(); // tableau des colonnes;
	colsDecale=new Array(); // tableau des decalages des boucles
	elt=new Array(); // tableau des elements
	tblSupprime=new Array();
	tblInsere=new Array();
	lignes[0]=document.createElement("tr");
	cols[0]=document.createElement("td");
	for (i=0;i<6;i++){
		elt[i]=document.createTextNode(intitules[i]);
	}
	lignes[0].appendChild(cols[0]);
	var nbe=document.createElement("input");
	nbe.name="nbe";
	nbe.id="nbe";
	nbe.type="hidden";
	nbe.value="1";
	cols[0].appendChild(nbe);
	nbe=document.createTextNode("Prog");
	cols[0].appendChild(nbe);
        tablebody.appendChild(lignes[0]);
	prg_fin(1);
    }
