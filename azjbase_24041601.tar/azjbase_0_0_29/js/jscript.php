<?php
echo "<!DOCTYPE HTML>\n";
echo "<head>\n";
echo "<title>choix de script javascript</title>\n";
if (!isset($_POST['charger'])) $_POST['charger']='';
if (!isset($_POST['fichier'])) $_POST['fichier']='';
if (isset($_FILES['fichier'])) $nomFile=$_POST['fichier']=$_FILES['fichier']['name'];
else if (!isset($_POST['fichier'])) $_POST['fichier']=$nomFile='';
echo "<script type=\"text/javascript\">\n";
echo "function load(){\n";
echo 'envoyer("'.$nomFile.'");';
echo "}\n"; ?>

function getIFrameDocument(aID){
var docFen=window.opener.document;
return docFen.getElementById(aID).contentDocument;
}

function formate(motClef,phrase) {
getIFrameDocument('fenetre').execCommand(motClef,false, phrase+' ');
return;
}

function envoyer(nomFile)
{	
/* if (!nomFile){
	alert("Vous n'avez pas spécifié le nom du script!");
window.close();
}*/
if (!nomFile) return;
var phrase='<script type="text/javascript" SRC="../../script/'+nomFile+'">';
formate("inserthtml",phrase);
window.close();
}
</script>
</head>
<body onload="load();">
<H1>Ajout d'un script javascript</H1>
<form enctype="multipart/form-data" name="texte" id="texte" method="post">
<?php if (($_POST['charger']) && ($_FILES['fichier'])){
	$srcFile='../script/'.$_FILES['fichier']['name'];
	echo $srcFile.'<BR>';
	if (move_uploaded_file($_FILES['fichier']['tmp_name'],$srcFile)){
		echo "script chargé!";
	} else {
		echo "Erreur:chargement du script!";
	}
}?>
<TABLE>
<TR>
<TD>nom de l'image</TD>
<input type="hidden" NAME="MAX_FILE_SIZE" VALUE="300000">
<TD><input name="fichier" id="fichier" type="file" accept="application/javascript" size="96" value=""<?php $_POST['fichier']?>""></TD></TR>
</TABLE>
<BR>
&nbsp;&nbsp;<input type="submit" name="charger" id="charger" value="Choisir">
</form>
</body>
</html>
