	indicateurs=0; // shift-32; ctrl+32; alt-64
function _chg2(v){ // affiche le nouveau clavier
	var j=v+indicateurs;
	if (indicateurs != -32){
	document.getElementById("as02").firstChild.data=String.fromCharCode(j+0x5D);
	document.getElementById("asa1").firstChild.data=String.fromCharCode(j+0xE9);
	document.getElementById("asa2").firstChild.data=String.fromCharCode(j+0x22);
	document.getElementById("asa3").firstChild.data=String.fromCharCode(j+0x27);
	document.getElementById("asa4").firstChild.data=String.fromCharCode(j+0x28);
	document.getElementById("asa5").firstChild.data=String.fromCharCode(j+0x7C);
	document.getElementById("asa6").firstChild.data=String.fromCharCode(j+0xE8);
	document.getElementById("asa7").firstChild.data=String.fromCharCode(j+0x5F);
	document.getElementById("asa8").firstChild.data=String.fromCharCode(j+0xE7);
	document.getElementById("asa9").firstChild.data=String.fromCharCode(j+0xE0);
	document.getElementById("asapf").firstChild.data=String.fromCharCode(j+0x29);
	document.getElementById("asaeq").firstChild.data=String.fromCharCode(j+0x2B);
	document.getElementById("asvg").firstChild.data=String.fromCharCode(j+0x2C);
	document.getElementById("aspv").firstChild.data=String.fromCharCode(j+0x3B);
	document.getElementById("as2p").firstChild.data=String.fromCharCode(j+0x3A);
	document.getElementById("asexc").firstChild.data=String.fromCharCode(j+0x21);
	document.getElementById("aspr").firstChild.data=String.fromCharCode(j+0x25);
	document.getElementById("asmult").firstChild.data=String.fromCharCode(j+0x2A);
	document.getElementById("ascirc").firstChild.data=String.fromCharCode(j+0x5E);
	document.getElementById("asds").firstChild.data=String.fromCharCode(j+0x24);
	}
	document.getElementById("asa").firstChild.data=String.fromCharCode(j+0x61);
	document.getElementById("asb").firstChild.data=String.fromCharCode(j+0x62);
	document.getElementById("asc").firstChild.data=String.fromCharCode(j+0x63);
	document.getElementById("asd").firstChild.data=String.fromCharCode(j+0x64);
	document.getElementById("ase").firstChild.data=String.fromCharCode(j+0x65);
	document.getElementById("asf").firstChild.data=String.fromCharCode(j+0x66);
	document.getElementById("asg").firstChild.data=String.fromCharCode(j+0x67);
	document.getElementById("ash").firstChild.data=String.fromCharCode(j+0x68);
	document.getElementById("asi").firstChild.data=String.fromCharCode(j+0x69);
	document.getElementById("asj").firstChild.data=String.fromCharCode(j+0x6A);
	document.getElementById("ask").firstChild.data=String.fromCharCode(j+0x6B);
	document.getElementById("asl").firstChild.data=String.fromCharCode(j+0x6C);
	document.getElementById("asm").firstChild.data=String.fromCharCode(j+0x6D);
	document.getElementById("asn").firstChild.data=String.fromCharCode(j+0x6E);
	document.getElementById("aso").firstChild.data=String.fromCharCode(j+0x6F);
	document.getElementById("asp").firstChild.data=String.fromCharCode(j+0x70);
	document.getElementById("asq").firstChild.data=String.fromCharCode(j+0x71);
	document.getElementById("asr").firstChild.data=String.fromCharCode(j+0x72);
	document.getElementById("ass").firstChild.data=String.fromCharCode(j+0x73);
	document.getElementById("asu").firstChild.data=String.fromCharCode(j+0x74);
	document.getElementById("ast").firstChild.data=String.fromCharCode(j+0x75);
	document.getElementById("asv").firstChild.data=String.fromCharCode(j+0x76);
	document.getElementById("asw").firstChild.data=String.fromCharCode(j+0x77);
	document.getElementById("asx").firstChild.data=String.fromCharCode(j+0x78);
	document.getElementById("asy").firstChild.data=String.fromCharCode(j+0x79);
	document.getElementById("asz").firstChild.data=String.fromCharCode(j+0x7A);
	document.getElementById("ch0").firstChild.data=String.fromCharCode(j+0x30);
	document.getElementById("ch1").firstChild.data=String.fromCharCode(j+0x31);
	document.getElementById("ch2").firstChild.data=String.fromCharCode(j+0x32);
	document.getElementById("ch3").firstChild.data=String.fromCharCode(j+0x33);
	document.getElementById("ch4").firstChild.data=String.fromCharCode(j+0x34);
	document.getElementById("ch5").firstChild.data=String.fromCharCode(j+0x35);
	document.getElementById("ch6").firstChild.data=String.fromCharCode(j+0x36);
	document.getElementById("ch7").firstChild.data=String.fromCharCode(j+0x37);
	document.getElementById("ch8").firstChild.data=String.fromCharCode(j+0x38);
	document.getElementById("ch9").firstChild.data=String.fromCharCode(j+0x39);
	document.getElementById("chpl").firstChild.data=String.fromCharCode(j+0x2B);
	document.getElementById("chmult").firstChild.data=String.fromCharCode(j+0x2A)
	document.getElementById("chdiv").firstChild.data=String.fromCharCode(j+0x2F);
	document.getElementById("chmn").firstChild.data=String.fromCharCode(j+0x2D);
	if (indicateurs == -32){
	document.getElementById("as02").firstChild.data=String.fromCharCode(j+0x40);
	document.getElementById("asa1").firstChild.data=String.fromCharCode(j+0x46);
	document.getElementById("asa2").firstChild.data=String.fromCharCode(j+0x9E);
	document.getElementById("asa3").firstChild.data=String.fromCharCode(j+0x43);
	document.getElementById("asa4").firstChild.data=String.fromCharCode(j+0x44);
	document.getElementById("asa5").firstChild.data=String.fromCharCode(j+0x9B);
	document.getElementById("asa6").firstChild.data=String.fromCharCode(j+0x4F);
	document.getElementById("asa7").firstChild.data=String.fromCharCode(j+0x80);
	document.getElementById("asa8").firstChild.data=String.fromCharCode(j+0x7C);
	document.getElementById("asa9").firstChild.data=String.fromCharCode(j+0x9F);
	document.getElementById("asa0").firstChild.data=String.fromCharCode(j+0x60);
	document.getElementById("asapf").firstChild.data=String.fromCharCode(j+0x9D);
	document.getElementById("asaeq").firstChild.data=String.fromCharCode(j+0x80);
	document.getElementById("asvg").firstChild.data=String.fromCharCode(j+0x5F);
	document.getElementById("aspv").firstChild.data=String.fromCharCode(j+0x4E);
	document.getElementById("as2p").firstChild.data=String.fromCharCode(j+0x4F);
	document.getElementById("asexc").firstChild.data=String.fromCharCode(j+0xC7);
	document.getElementById("aspr").firstChild.data=String.fromCharCode(j+0x119);
	document.getElementById("asmult").firstChild.data=String.fromCharCode(j+0xCD);
	document.getElementById("ascirc").firstChild.data=String.fromCharCode(j+0xC8);
	document.getElementById("asds").firstChild.data=String.fromCharCode(j+0xD0);
	}
}
function _chg(e){
	// modifie alphabet
	var j=parseInt(this.value);
	_chg2(j);
	return true;
}
function _trad2(e){ // sur keyup pour aff clavier
	var car0=e['keyCode'];
	if (car0>47) return true;
	var i=0;
	var j=parseInt(document.getElementById("alpha").value);
	if (e['shiftKey'] == true) i=-32;
	if (e['altKey'] == true) i+=32;
	if (e['ctrlKey'] == true) i+=64;
	if (indicateurs != i){
		indicateurs=i;
		chg2(j);
	}
}

function _traduit(e){
	var i=0;
//	var j=parseInt(document.getElementById("alpha").value);
	if (e['shiftKey'] == true) i=-32;
	if (e['altKey'] == true) i+=32;
	if (e['ctrlKey'] == true) i+=64;
	if (indicateurs != i){
		indicateurs=i;
		chg2(j);
	}
	var car0;
	car0=e["keyCode"];
	parent.document.getElementById("aff1").value=car0;
	return;
	if (car0<47) return true;
	car0+=32;
	if ((car0 >= 128) && (car0 <= 137)) car0-=80; // clavier numerique
	if ((car0 >= 0x8A) && (car0 <= 0x8F)) car0-=0x60;
	if (car0 == 0x51) car0=0x26;
	if (car0 == 0x52) car0=0xE9;
	if (car0 == 0x53) car0=0x22;
	if (car0 == 0x54) car0=0x27;
	if (car0 == 0x55) car0=0x28;
	if (car0 == 0x56) car0=0x7C;
	if (car0 == 0x57) car0=0xE8;
	if (car0 == 0x58) car0=0x5F;
	if (car0 == 0x59) car0=0xE7;
	if (car0 == 0x50) car0=0xE0;
	if (car0 == 0xFB) car0=0x29;
	if (car0 == 0xDC) car0=0x2C;
	if (car0 == 0xDE) car0=0x3B;
	if (car0 == 0xDF) car0=0x3A;
	if (car0 == 0xFC) car0=0x3D;
	if (car0 == 0xFD) car0=0x5C;
	if (car0 == 0xFF) car0=0x21;
	if (car0 == 0x102) car0=0x3C;
	if (car0 == 0xFE) car0=0x5D;
	if (car0 == 0xE0) car0=0x25;
	if (e['shiftKey'] == true){
		car0-=32;
		if (car0 == 12) car0=0x3F;
		if (car0 == 0xC9) car0=0x7E;
		if (car0 == 0x1B) car0=0x2E;
		if (car0 == 0x1C) car0=0x3E;
		if (car0 == 0x1A) car0=0x2F;
		if (car0 == 0x1) car0=0xA7;
		if (car0 == 0x6) car0=0x60;
		if (car0 == 0x2) car0=0x23;
		if (car0 == 0x7) car0=0x7B;
		if (car0 == 0x8) car0=0x5E;
		if (car0 == 0xF) car0=0x5C;
		if (car0 == 0x5C) car0=0x24;
		if (car0 == 0xC8) car0=0x7F;
		if (car0 == 0xC7) car0=0x7D;
		if (car0 == 0x5) car0=0x40;
		if (car0 == 0x9) car0=0xB0;
		if (car0 == 0xB) car0=0xB1;
}
	var i=0;
	if (e['altKey'] == true) car0+=32;
	if (e['ctrlKey'] == true) car0-=64;
	if (car0 < 0) car0=0;
	if (car0 > 255) car0=255;
	var s=String.fromCharCode(j+car0);
	var t=this.value;
	i=this.selectionStart;
	if (this.textLength >= this.maxLength) return false;
	var t0=t.substring(0,i);
	var t1=t.substring(i+1);
	t=t0+s+t1;
	this.value=t;
	this.selectionEnd=this.selectionStart=i+1;
	return false;
}
