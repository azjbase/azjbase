<?php
echo phpinfo(INFO_ALL);
?>
