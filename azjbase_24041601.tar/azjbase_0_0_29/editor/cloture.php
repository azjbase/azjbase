<?php
function makeArbreBalises($txt){
$n=strlen($txt);
$niv=0;
$i=0;
$nBalises=0;
while($i<$n){
	while($txt[$i++]);
	if ($i<$n){
		$c=$txt[$i];
		$j=$i-1;
		while(($i<$n) && ($c != ' ') && ($c != '>')) $c=$txt[$i++];
		$tBalises[$nBalises]=substr($txt,$j,$i-$j);
	}
}
print_r($tbalises);
}

echo "<HEAD>\n";
echo "<TITLE>essai</TITLE>\n";
echo "</HEAD>\n";
echo "<BODY>\n";
echo "<FORM NAME=\"test\" METHOD=\"POST\" ACTION=\"cloture.php\">\n";
echo 'code html source <TEXTAREA NAME="source" COLS="64" ROWS="16">'.$_POST['source']."</TEXTAREA>\n";
echo '<INPUT TYPE="SUBMIT" NAME="lancer" VALUE="lancer">'."\n";
echo "</FORM>\n";
echo "</BODY>\n";
echo "</HTML>\n";
