function formate(motClef,phrase) {
	getIFrameDocument('fenetre').execCommand(motClef,false, phrase);
	document.getElementById('fenetre').contentWindow.focus();
  return;
}

function getIFrameDocument(aID){
  // if contentDocument exists, W3C compliant (Mozilla)
  if (document.getElementById(aID).contentDocument){
    return document.getElementById(aID).contentDocument;
  } else {
    // IE
    return document.frames[aID].document;
  }
}

function sauve(){
	alert(getIFrameDocument("fenetre").body.innerHTML);
}

function vide(){
	getIFrameDocument("fenetre").body.innerHTML='';
	document.getElementById('fenetre').contentWindow.focus();
}

function load2(a,b){
var obj=document.getElementById("fenetre").contentDocument;
obj.body.innerHTML=b.replace(/&#34;/g,'"',b);
obj.body.onkeyup=_trad2;
obj.body.onkeydown=_traduit;
//obj.body.onkeypress=_press;
obj.designMode="On";
}

function defTable(){
	var pan1=window.open("../../editor/tablev1.html","tablev1","menubar=no, status=no, scrollbars=no, menubar=no, location=no, dependent=yes, width=300, height=100");
	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};
}

function defForeColor(){
	var pan1=window.open("../../editor/forecolorv1.html","forecolorv1","menubar=no, status=no, scrollbars=no, menubar=no, location=no, dependent=yes, width=300, height=100");
	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};
}

function defBackColor(){
	var pan1=window.open("../../editor/backcolorv1.html","backcolorv1","menubar=no, status=no, scrollbars=no, menubar=no, location=no, dependent=yes, width=300, height=100");
	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};
}

function fermeture(a){
var val=document.getElementById("fenetre").contentDocument.body.innerHTML;
document.getElementById(a).value=val;
}

