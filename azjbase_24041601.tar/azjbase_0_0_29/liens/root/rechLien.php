<?php
echo "<!DOCTYPE HTML>\n";
// Modifie par Alexandre Zvenigorosky - 14-10-2009
// indice = premier champ, valeur affichée pour la saisie 2 ème champ
echo "<html>\n";
echo "<head>\n";
echo "<title>Lien vers autre fiche</title>\n";
echo "<script type=\"text/javascript\">\n";
/* $txt=file_get_contents("tables.js");
echo $txt."\n";*/
$txt=file_get_contents($_GET['fileFichesNom']);
echo $txt."\n";
echo "function getIFrameDocument(aID){\n";
echo "var docFen=window.opener.document;\n";
echo "return docFen.getElementById(aID).contentDocument;\n";
echo "}\n";

echo "function formate(motClef,phrase){\n";
echo "getIFrameDocument('fenetre').execCommand(motClef,false, phrase+' ');\n";
echo "return;\n";
echo "}\n";

echo "function envoyer()\n";
echo "{\n";
echo "var obj=document.getElementById('fiche');\n";
echo "var nobj=obj.selectedIndex;\n";
echo "phrase='<A style=\"color:#0000FE; \" onClick=\"chgtIndice('+obj.options[nobj].value+');\">'+obj.options[nobj].text+'</A>';\n";
echo "formate(\"inserthtml\",phrase);\n";
echo "window.close();\n";
echo "}\n";
echo "</script>\n";
echo "</head>\n";
echo "<body style=\"overflow: hidden; \">\n";
echo "<form name=\"champ\" id=\"champ\" method=\"post\">\n";
echo "<H2>Lien vers une autre fiche</H2>\n";
echo 'Choix d\'une fiche cible<SELECT NAME="fiche" ID="fiche" SIZE="1"></SELECT>'."\n";
echo '<script type="text/javascript">'."\n";
echo "obj=document.getElementById('fiche');\n";
echo "n=fichesIdx.length;\n";
echo "for(i=0;i<n;i++)\n";
echo "obj.options[obj.length]=new Option(fichesVal[i],fichesIdx[i],false,false);\n";
echo "</script>\n";
echo "<BR><BR>&nbsp;&nbsp;<input type=\"submit\" name=\"envVal\" id=\"envVal\" value=\"envoi\" onClick=\"envoyer();\">";
echo "</form>\n";
echo "</body>\n";
echo "</html>\n";
?>
