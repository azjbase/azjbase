function test23{
	alert("toto');
}
