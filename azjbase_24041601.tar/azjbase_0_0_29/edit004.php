<?php
function edite($nom,$valeur,$fileFichesNom){ ?>
<SCRIPT TYPE="text/javascript">
function defImg(){
	var pan1=window.open("../../editor/imgEdit.php","backcolorv1","menubar=no, status=no, location=no, dependent=yes, width=500, height=240 scrollbars=yes");
	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();}
}
function rechLien(){
	var pan1=window.open("rechLien.php?fileFichesNom=<?php echo $fileFichesNom ?>","backcolorv1","menubar=no, status=no, location=no, dependent=yes, width=500, height=240 scrollbars=yes");
	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();}
}
function editLien(){
	var pan1=window.open("../../editor/editLien.html","backcolorv1","menubar=no, status=no, location=no, dependent=yes, width=500, height=240 scrollbars=yes");
	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();}
}
function defAudio(){
	var pan1=window.open("../../js/Audio.php","backcolorv1","menubar=no, status=no, location=no, dependent=yes, width=500, height=240 scrollbars=yes");
	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();}
}
function defDiv(){
	var pan1=window.open("../../js/Div.html","backcolorv1","scrollbars=yes, dependent=yes, width=700");
	pan1.onunload=function(){document.getElementById('fenetre').contentWindow.focus();};
}
</SCRIPT>
<BR>
    <table border="2" bgcolor="grey">
      <tr>
        <td>
<img src="../../editor/h1.gif" width="24" height="16" align="middle" onClick="formate('formatblock','<h1>');">
<img src="../../editor/h2.gif" width="24" height="16" align="middle" onClick="formate('formatblock','<h2>');">
<img src="../../editor/h3.gif" width="24" height="16" align="middle" onClick="formate('formatblock','<h3>');">
<img src="../../editor/h4.gif" width="24" height="16" align="middle" onClick="formate('formatblock','<h4>');">
<img src="../../editor/h5.gif" width="24" height="16" align="middle" onClick="formate('formatblock','<h5>');">
<img src="../../editor/h6.gif" width="24" height="16" align="middle" onClick="formate('formatblock','<h6>');">
<img src="../../editor/pre.gif" width="24" height="16" align="middle" onClick="formate('formatblock','<pre>');">
<img src="../../editor/addresse.gif" width="24" height="16" align="middle" onClick="formate('formatblock','<address>');">
<img src="../../editor/p.gif" width="16" height="16" align="middle" onClick="formate('formatblock','<p>');">
<img src="../../editor/ecriture.gif" width="16" height="16" align="middle" onClick="defForeColor();">
<img src="../../editor/fond.gif" width="16" height="16" align="middle" onClick="defBackColor();">
<img src="../../editor/exposant.gif" width="16" height="16" align="middle" onClick="formate('superscript',null);">
<img src="../../editor/indice.gif" width="16" height="16" align="middle" onClick="formate('subscript',null);">
<img src="../../editor/souligne.gif" width="16" height="16" align="middle" onClick="formate('underline',null);">
<img src="../../editor/efface.gif" width="16" height="16" align="middle" onClick="formate('undo',null);">
<img src="../../editor/texte.gif" width="16" height="16" align="middle" onClick="formate('removeformat',null);">
<img src="../../editor/bold.gif" width="16" height="16" align="middle" onClick="formate('bold',null);">
<img src="../../editor/italic.gif" width="16" height="16" align="middle" onClick="formate('italic',null);">
<img src="../../editor/indente.gif" width="16" height="16" align="middle" onClick="formate('indent',null);">
<img src="../../editor/desindente.gif" width="16" height="16" align="middle" onClick="formate('outdent',null);">
<img src="../../editor/left.gif" width="16" height="16" align="middle" onClick="formate('justifyleft',null);">
<img src="../../editor/center.gif" width="16" height="16" align="middle" onClick="formate('justifycenter',null);">
<img src="../../editor/right.gif" width="16" height="16" align="middle" onClick="formate('justifyright',null);">
<img src="../../editor/justify.gif" width="16" height="16" align="middle" onClick="formate('justifyfull',null);">
<img src="../../editor/table.gif" width="16" height="16" align="middle" onClick="defTable();">
<img src="../../editor/sauve.gif" width="16" height="16" align="middle" onClick="sauve();">
<img src="../../editor/lst.gif" width="16" height="16" align="middle" onClick="formate('insertunorderedlist',null);">
<img src="../../editor/num.gif" width="16" height="16" align="middle" onClick="formate('insertorderedlist',null);">
<img src="../../editor/img.gif" width="16" height="16" align="middle" onClick="defImg();">
<img src="../../editor/Audio.png" width="16" height="16" align="middle" onClick="defAudio();">
<img src="../../editor/vide.gif" width="16" height="16" align="middle" onClick="vide();">
<img src="../../editor/editLien.png" width="16" height="16" align="middle" onClick="editLien();">
<img src="../../editor/rechLien.png" width="16" height="16" align="middle" onClick="rechLien();">
<img src="../../js/Div.gif" alt="div" width="16" height="16" align="middle" onClick="defDiv();">
<input type="text" disabled size=4 maxlentgh=5 name="affi1" id="aff1">
<?php require("../../js/pre2ext.php");?>
        </td>
      </tr>
    </table>
<?php $formulaire=str_replace('"','&#34;',$valeur);
$formulaire=str_replace('\\','\\\\',$formulaire);
$formulaire=str_replace("'","\\'",$formulaire);
$formulaire=str_replace("\r","",$formulaire);
$formulaire=str_replace("\n","",$formulaire);
echo '<input type="hidden" name="'.$nom.'" id="'.$nom.'" value="">'."\n";
echo "<iframe id=\"fenetre\" frameborder=\"1\" height=\"550 px\" width=\"90%\" onload=\"load2('".$nom."','".$formulaire."');\"></iframe>\n";
} ?>

