<?php
echo "<!DOCTYPE HTML>\n";
echo "<head>\n";
echo "<title>choix d'image</title>\n";
if (!isset($_POST['charger'])) $_POST['charger']='';
if (!isset($_POST['fichier'])) $_POST['fichier']='';
if (isset($_FILES['fichier'])) $nomFile=$_POST['fichier']=$_FILES['fichier']['name'];
else if (!isset($_POST['fichier'])) $_POST['fichier']='';
echo "<script type=\"text/javascript\">\n";
echo "function load(){\n";
if ($nomFile) echo "envoyer('".$nomFile."');\n";
echo "}\n";
echo "function getIFrameDocument(aID){\n";
echo "var docFen=window.opener.document;\n";
echo "return docFen.getElementById(aID).contentDocument;\n";
echo "}\n";

echo "function verifInt(val,valMin,valMax){\n";
// donne -1 si non valide
echo "var regle=/^[0-9]+$/;\n";
echo "if (!regle.test(val)){\n";
echo "alert(val+\" n'est pas un nombre valide!\");\n";
echo "return -1;\n";
echo "}\n";
echo "if ((val < valMin) || (val > valMax)){\n";
echo "alert(val+\" n'est pas compris entre \"+valMin+\" et \"+valMax+\" !\");\n";
echo "return -1;\n";
echo "}\n";
echo "return val;\n";
echo "}\n";

echo "function formate(motClef,phrase) {\n";
echo "getIFrameDocument('fenetre').execCommand(motClef,false, phrase);\n";
echo "return;\n";
echo "}\n";

echo "function envoyer(nomFile)\n";
echo "{\n";	
echo "if (!nomFile){\n";
echo "	alert(\"Vous n'avez pas spécifié le nom de la source!\");\n";
echo "window.close();\n";
echo "}\n";
echo "phrase=nomFile;\n";
echo "phrase+='<AUDIO controls ID=\"'+nomFile+'\" onMouseOver=\"playStopAudio(\''+nomFile+'\'); \"><SOURCE SRC=\"../../audio/'+nomFile+'\">';\n";
echo "phrase+='Votre navigateur ne supporte pas ce type de son!</AUDIO>';\n";
echo "alert(phrase);\n";
echo "formate(\"inserthtml\",phrase);\n";
echo "window.close();\n";
echo "}\n";
echo "</script>\n";
echo "</head>\n";
echo "<body onload=\"load();\">\n";
echo "<form enctype=\"multipart/form-data\" name=\"texte\" id=\"texte\" method=\"post\">\n";
if (($_POST['charger']) && ($_FILES['fichier'])){
	$srcFile='../audio/'.$_FILES['fichier']['name'];
	echo $srcFile.'<BR>';
	if (move_uploaded_file($_FILES['fichier']['tmp_name'],$srcFile)){
		echo "Image chargée!";
	} else {
		echo "Erreur:chargement de l'image!";
	}
}
echo "<TABLE>\n";
echo "<TR>\n";
echo "<TD>nom du son</TD>\n";
echo "<input type=\"hidden\" NAME=\"MAX_FILE_SIZE\" VALUE=\"100000000\">\n";
echo "<TD><input name=\"fichier\" id=\"fichier\" type=\"file\" accept=\"audio/*\" size=\"96\" value=\"".$_POST['fichier']."\"></TD></TR>\n";
echo "</TABLE>\n";
echo "<BR>\n";
echo "&nbsp;&nbsp;<input type=\"submit\" name=\"charger\" id=\"charger\" value=\"Choisir\">\n";
// echo "&nbsp;&nbsp;<input type=\"submit\" name=\"envVal\" id=\"envVal\" value=\"envoi\" onclick=\"envoyer();\">\n";
echo "</form>\n";
echo "</body>\n";
echo "</html>\n";
?>
