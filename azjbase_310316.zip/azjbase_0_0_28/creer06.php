<?php
function sqlp($txt){ // corrige ou supprime les caractères spéciaux \t \r \n \->\\ '->''
	$z=strlen($txt);
	$w='';
	for($x=0;$x<$z;$x++){
		$v0=$txt[$x];
		if (($v == "\n") || ($v == "\r") && ($v == "\t")) $v0='';
		if ($v == "'") $v0="\\\'";
		if ($v == "\\") $v0="\\\\";
		if ($v == '"') $v0='\"';
		$w.=$v0;
	}
	return $w;
}

function vnom($txt){ // verifie que le nom fourni suit a-z,A-Z,0-9,_
	$ok=0;
	$n=0;
	if ($txt <> '') $n=strlen($txt);
	if ($n < 1) return 1; // different des autres fonctions
	$a=$txt[0];
	if (($a >= 'A') && ($a <= 'Z')) $ok=1;
	if (($a >= 'a') && ($a <= 'z')) $ok=1;
	if ($a == '_') $ok1;
	$i=1;
	while(($ok) && ($i<$n)){
		$a=$txt[$i++];
		$ok=0;
		if (($a >= 'A') && ($a <= 'Z')) $ok=1;
		if (($a >= 'a') && ($a <= 'z')) $ok=1;
		if (($a >= '0') && ($a <= '9')) $ok=1;
		if ($a == '_') $ok=1;
	}
	return $ok;
}
$i=error_reporting(E_ERROR+E_WARNING+E_PARSE+E_CORE_ERROR+E_CORE_WARNING+E_COMPILE_ERROR+E_COMPILE_WARNING);
echo "<!DOCTYPE html>\n";
echo "<HTML>\n<HEAD>\n<TITLE>Creation table</TITLE>\n";
echo "</HEAD>\n";
echo "<BODY>\n";
echo "<H1>AZJ_BASE - Cr&eacute;ation de la structure</H1>";
echo '<FORM NAME="creer" ID="creer" METHOD="POST" ACTION="creer06.php">'."\n";
echo '<INPUT TYPE="HIDDEN" NAME="relancer" ID="relancer" VALUE="0">'."\n";
echo 'Serveur: <INPUT TYPE="TEXT" NAME="srv_1_serveur" SIZE="16" MAXLENGTH="16" VALUE="'.$_POST['srv_1_serveur'].'">';
echo ' Utilisateur: <INPUT TYPE="TEXT" NAME="srv_1_user" SIZE="32" MAXLENGTH="32" VALUE="'.$_POST['srv_1_user'].'">';
echo ' Mot de passe: <INPUT TYPE="PASSWORD" NAME="srv_1_mdp" SIZE="32" MAXLENGTH="32" VALUE="'.$_POST['srv_1_mdp'].'"><BR>';
echo ' Base de donn&eacute;es: <INPUT TYPE="TEXT" NAME="srv_1_base" SIZE="24" MAXLENGTH="24" VALUE="'.$_POST['srv_1_base'].'">';
if (!isset($_POST['srv_1_port'])) $_POST['srv_1_port']=3306;
echo ' Port: <INPUT TYPE="NUMBER" NAME="srv_1_port" SIZE="5" MAXLENGTH="5" VALUE="'.$_POST['srv_1_port'].'">'."\n";
$a=$_POST['srv_1_mdp'];
$ok=1;
if ((stripos($a,';')) || ($a[0] == ';')){
	echo "Le mot de passe ne peut comporter de ;!";
	$ok=false;
}
$a=$_POST['srv_1_base'];
if ((stripos($a,';')) || ($a[0] == ';')){
	echo "Le nom de la base ne peut comporter de ;!";
	$ok=false;
}
if (!$_POST['srv_1_user']) $ok=false; // pas d'utilisateur
if (!$a) $ok=false; // pas de nom de base
if (!vnom($a)){
	echo "Le nom de la base est incorrect!";
	$ok=false;
}
if (!$ok){
	echo '<INPUT TYPE="submit" VALUE="Se connecter" NAME="connecter">';
	echo "<br><A HREF=\"doc/help_creer1.html\">Fonctionnement</A>\n";
	echo "&nbsp;&nbsp;&nbsp;<A HREF=\"azjbase_0_0_28p.php\">AZJ Base</A>\n";
	exit;
}
echo "<br><A HREF=\"doc/help_creer1.html\">Fonctionnement</A>\n";
echo "&nbsp;&nbsp;&nbsp;<A HREF=\"azjbase_0_0_28p.php\">AZJ Base</A>\n";
$op_create=0;
$clause='';
$ok=(strlen($_POST['srv_1_serveur'])>2) && (strlen($_POST['srv_1_serveur'])>2);
if ($ok){
	// ouverture de la base
	$conn=null;
	$conn=new mysqli($_POST['srv_1_serveur'],$_POST['srv_1_user'],$_POST['srv_1_mdp'],$_POST['srv_1_base'],$_POST['srv_1_port']);
	if (!$conn){
		echo '<INPUT TYPE="submit" VALUE="Se connecter" NAME="connecter">';
		die("Echec de connexion a la base de donn&eacute;es<br>");
	}
	$ok3=1;
}
echo '&nbsp;&nbsp;<INPUT TYPE="SUBMIT" NAME="CrChamp" VALUE="Cr&eacute;er/Modifier Champ">&nbsp;&nbsp;'."\n";
echo '&nbsp;&nbsp;<INPUT TYPE="SUBMIT" NAME="SupChamp" VALUE="Supprimer Champ">&nbsp;&nbsp;'."\n";
echo '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<INPUT TYPE="SUBMIT" NAME="SupTable" VALUE="Supprimer Table">'."\n";
echo "<BR><HR>\n";
// liste des tables
$t_0['nom_table']=$_POST['nom_table'];
if (($_POST['CrChamp']) || ($_POST['SupTable'])){
	$t_1['aj_table']='';
}
	else $t_1['aj_table']=$_POST['aj_table'];
$t_0['aj_table']=$_POST['aj_table'];
$t_0['nom_champ']=$_POST['nom_champ'];
$t_0['aj_champ']=$t_1['aj_champ']=$_POST['aj_champ'];
$t_0['lga_champ']=$_POST['lga_champ'];
if ($ok3){
// si aj_table : table selectionnee
	if ($t_0['aj_table']) $t_0['nom_table']=$t_0['aj_table'];
	$result=$conn->query("SHOW TABLES");
	$ntbl=0; // nbe de tables
	while ($ligne=$result->fetch_row()){
		$ok=1;
		$nom_tbl[$ntbl++]=$ligne[0];
	}
}
// structure de la table courante
if (($ok3) && (isset($_POST['nom_table']))){
	$n=0; // nbe de champs
	$j=0; // indice dans le tableau des champs
	if ($t_0['nom_table']){
		$clause="DESCRIBE ".$t_0['nom_table'];
		$result=$conn->query($clause);
		while (($result) && ($ligne=$result->fetch_row())){
			$n++;
			for($i=0;$i<6;$i++) $tbl_c[$j++]=$ligne[$i];
		}
		$ok=($n);
	}
}
if ($ok3){
	echo "<BR><TABLE BORDER=\"0\"><TR><TD>\n";
	echo "Nouvelle Table <INPUT TYPE=\"TEXT\" NAME=\"aj_table\" VALUE=\"".$t_1['aj_table']."\" SIZE=\"16\" MAXLENGTH=\"16\">\n";
	echo "</TD><TD>";
	echo "Nouveau champ: <INPUT TYPE=\"TEXT\" NAME=\"aj_champ\" VALUE=\"".$t_1['aj_champ']."\" SIZE=\"16\" MAXLENGTH=\"16\"><BR><BR>\n";
	$t_0['type_champ']=$_POST['type_champ'];
	echo 'Type de champ:&nbsp;&nbsp;<SELECT NAME="type_champ" onchange="submit(); ">'."\n";
	if ($t_0['type_champ'] == '') echo "<OPTION SELECTED></OPTION>"; else echo "<OPTION></OPTION>";  // ne rien changer
	if ($t_0['type_champ'] == 'CHAR') echo "<OPTION SELECTED>CHAR</OPTION>"; else echo "<OPTION>CHAR</OPTION>";
	if ($t_0['type_champ'] == 'VARCHAR') echo "<OPTION SELECTED>VARCHAR</OPTION>"; else echo "<OPTION>VARCHAR</OPTION>";
	if ($t_0['type_champ'] == 'TEXT') echo "<OPTION SELECTED>TEXT</OPTION>"; else echo "<OPTION>TEXT</OPTION>";
	if ($t_0['type_champ'] == 'TINYINT') echo "<OPTION SELECTED>TINYINT</OPTION>"; else echo "<OPTION>TINYINT</OPTION>";
	if ($t_0['type_champ'] == 'SMALLINT') echo "<OPTION SELECTED>SMALLINT</OPTION>"; else echo "<OPTION>SMALLINT</OPTION>";
	if ($t_0['type_champ'] == 'INT') echo "<OPTION SELECTED>INT</OPTION>"; else echo "<OPTION>INT</OPTION>";
	if ($t_0['type_champ'] == 'BIGINT') echo "<OPTION SELECTED>BIGINT</OPTION>"; else echo "<OPTION>BIGINT</OPTION>";
	if ($t_0['type_champ'] == 'FLOAT') echo "<OPTION SELECTED>FLOAT</OPTION>"; else echo "<OPTION>FLOAT</OPTION>";
	if ($t_0['type_champ'] == 'DOUBLE') echo "<OPTION SELECTED>DOUBLE</OPTION>"; else echo "<OPTION>DOUBLE</OPTION>";
	if ($t_0['type_champ'] == 'DECIMAL') echo "<OPTION SELECTED>DECIMAL</OPTION>"; else echo "<OPTION>DECIMAL</OPTION>";
	if ($t_0['type_champ'] == 'DATE') echo "<OPTION SELECTED>DATE</OPTION>"; else echo "<OPTION>DATE</OPTION>";
	if ($t_0['type_champ'] == 'TIME') echo "<OPTION SELECTED>TIME</OPTION>"; else echo "<OPTION>TIME</OPTION>";
	if ($t_0['type_champ'] == 'INT AUTO_INCREMENT') echo "<OPTION SELECTED>INT AUTO_INCREMENT</OPTION>"; else echo "<OPTION>INT AUTO_INCREMENT</OPTION>";
	if ($t_0['type_champ'] == 'Foreign Key') echo "<OPTION SELECTED>Foreign Key</OPTION>"; else echo "<OPTION>Foreign Key</OPTION>";
	echo "</SELECT>&nbsp;&nbsp;\n";
	// longueur du champ
	$a=$t_0['type_champ'];
	if (($a == 'CHAR') || ($a == 'VARCHAR') || ($a == 'TEXT') || ($a == DECIMAL)){
		echo '<SELECT NAME="lga_champ" onchange="submit(); ">';
	}
	if (($a == 'CHAR') || ($a == 'VARCHAR') || ($a == DECIMAL)){
		if ($t_0['lga_champ'] == '1') echo "<OPTION SELECTED>1</OPTION>"; else echo "<OPTION>1</OPTION>";
		if ($t_0['lga_champ'] == '2') echo "<OPTION SELECTED>2</OPTION>"; else echo "<OPTION>2</OPTION>";
		if ($t_0['lga_champ'] == '3') echo "<OPTION SELECTED>3</OPTION>"; else echo "<OPTION>3</OPTION>";
		if ($t_0['lga_champ'] == '4') echo "<OPTION SELECTED>4</OPTION>"; else echo "<OPTION>4</OPTION>";
		if ($t_0['lga_champ'] == '5') echo "<OPTION SELECTED>5</OPTION>"; else echo "<OPTION>5</OPTION>";
		if ($t_0['lga_champ'] == '6') echo "<OPTION SELECTED>6</OPTION>"; else echo "<OPTION>6</OPTION>";
		if ($t_0['lga_champ'] == '7') echo "<OPTION SELECTED>7</OPTION>"; else echo "<OPTION>7</OPTION>";
		if ($t_0['lga_champ'] == '8') echo "<OPTION SELECTED>8</OPTION>"; else echo "<OPTION>8</OPTION>";
		if ($t_0['lga_champ'] == '9') echo "<OPTION SELECTED>9</OPTION>"; else echo "<OPTION>9</OPTION>";
		if ($t_0['lga_champ'] == '10') echo "<OPTION SELECTED>10</OPTION>"; else echo "<OPTION>10</OPTION>";
	}
	if (($a == 'CHAR') || ($a == 'VARCHAR')){
		if ($t_0['lga_champ'] == '11') echo "<OPTION SELECTED>11</OPTION>"; else echo "<OPTION>11</OPTION>";
		if ($t_0['lga_champ'] == '12') echo "<OPTION SELECTED>12</OPTION>"; else echo "<OPTION>12</OPTION>";
		if ($t_0['lga_champ'] == '13') echo "<OPTION SELECTED>13</OPTION>"; else echo "<OPTION>13</OPTION>";
		if ($t_0['lga_champ'] == '14') echo "<OPTION SELECTED>14</OPTION>"; else echo "<OPTION>14</OPTION>";
		if ($t_0['lga_champ'] == '15') echo "<OPTION SELECTED>15</OPTION>"; else echo "<OPTION>15</OPTION>";
		if ($t_0['lga_champ'] == '16') echo "<OPTION SELECTED>16</OPTION>"; else echo "<OPTION>16</OPTION>";
		if ($t_0['lga_champ'] == '24') echo "<OPTION SELECTED>24</OPTION>"; else echo "<OPTION>24</OPTION>";
		if ($t_0['lga_champ'] == '32') echo "<OPTION SELECTED>32</OPTION>"; else echo "<OPTION>32</OPTION>";
		if ($t_0['lga_champ'] == '48') echo "<OPTION SELECTED>48</OPTION>"; else echo "<OPTION>48</OPTION>";
		if ($t_0['lga_champ'] == '64') echo "<OPTION SELECTED>64</OPTION>"; else echo "<OPTION>64</OPTION>";
		if ($t_0['lga_champ'] == '96') echo "<OPTION SELECTED>96</OPTION>"; else echo "<OPTION>96</OPTION>";
		if ($t_0['lga_champ'] == '128') echo "<OPTION SELECTED>128</OPTION>"; else echo "<OPTION>128</OPTION>";
		if ($t_0['lga_champ'] == '192') echo "<OPTION SELECTED>192</OPTION>"; else echo "<OPTION>192</OPTION>";
		if ($t_0['lga_champ'] == '255') echo "<OPTION SELECTED>255</OPTION>"; else echo "<OPTION>255</OPTION>";
	}
	if ($a == 'VARCHAR'){
		if ($t_0['lga_champ'] == '256') echo "<OPTION SELECTED>256</OPTION>"; else echo "<OPTION>256</OPTION>";
		if ($t_0['lga_champ'] == '384') echo "<OPTION SELECTED>384</OPTION>"; else echo "<OPTION>384</OPTION>";
		if ($t_0['lga_champ'] == '512') echo "<OPTION SELECTED>512</OPTION>"; else echo "<OPTION>512</OPTION>";
		if ($t_0['lga_champ'] == '1024') echo "<OPTION SELECTED>1024</OPTION>"; else echo "<OPTION>1024</OPTION>";
		if ($t_0['lga_champ'] == '2048') echo "<OPTION SELECTED>2048</OPTION>"; else echo "<OPTION>2048</OPTION>";
		if ($t_0['lga_champ'] == '4096') echo "<OPTION SELECTED>4096</OPTION>"; else echo "<OPTION>4096</OPTION>";
		if ($t_0['lga_champ'] == '8192') echo "<OPTION SELECTED>8192</OPTION>"; else echo "<OPTION>8192</OPTION>";
		if ($t_0['lga_champ'] == '16384') echo "<OPTION SELECTED>16384</OPTION>"; else echo "<OPTION>16384</OPTION>";
		if ($t_0['lga_champ'] == '32768') echo "<OPTION SELECTED>32768</OPTION>"; else echo "<OPTION>32768</OPTION>";
		if ($t_0['lga_champ'] == '65200') echo "<OPTION SELECTED>65200</OPTION>"; else echo "<OPTION>65200</OPTION>";
	}
	if ($a == 'TEXT'){
		if ($t_0['lga_champ'] == '256') echo "<OPTION SELECTED>256</OPTION>"; else echo "<OPTION>256</OPTION>";
		if ($t_0['lga_champ'] == '512') echo "<OPTION SELECTED>512</OPTION>"; else echo "<OPTION>512</OPTION>";
		if ($t_0['lga_champ'] == '1024') echo "<OPTION SELECTED>1024</OPTION>"; else echo "<OPTION>1024</OPTION>";
		if ($t_0['lga_champ'] == '2048') echo "<OPTION SELECTED>2048</OPTION>"; else echo "<OPTION>2048</OPTION>";
		if ($t_0['lga_champ'] == '4096') echo "<OPTION SELECTED>4096</OPTION>"; else echo "<OPTION>4096</OPTION>";
		if ($t_0['lga_champ'] == '8192') echo "<OPTION SELECTED>8192</OPTION>"; else echo "<OPTION>8192</OPTION>";
		if ($t_0['lga_champ'] == '16384') echo "<OPTION SELECTED>16384</OPTION>"; else echo "<OPTION>16384</OPTION>";
		if ($t_0['lga_champ'] == '32768') echo "<OPTION SELECTED>32768</OPTION>"; else echo "<OPTION>32768</OPTION>";
	}
	if (($a == 'CHAR') || ($a == 'VARCHAR') || ($a == 'TEXT') || ($a == DECIMAL)) echo "</SELECT>&nbsp;&nbsp;\n";
	if ($a == 'DECIMAL'){
		$t_0['lgb_champ']=$_POST['lgb_champ'];
		echo '<SELECT NAME="lgb_champ" onchange="submit(); ">';
		if ($t_0['lgb_champ'] == '1') echo "<OPTION SELECTED>1</OPTION>"; else echo "<OPTION>1</OPTION>";
		if ($t_0['lgb_champ'] == '2') echo "<OPTION SELECTED>2</OPTION>"; else echo "<OPTION>2</OPTION>";
		if ($t_0['lgb_champ'] == '3') echo "<OPTION SELECTED>3</OPTION>"; else echo "<OPTION>3</OPTION>";
		if ($t_0['lgb_champ'] == '4') echo "<OPTION SELECTED>4</OPTION>"; else echo "<OPTION>4</OPTION>";
		if ($t_0['lgb_champ'] == '5') echo "<OPTION SELECTED>5</OPTION>"; else echo "<OPTION>5</OPTION>";
		if ($t_0['lgb_champ'] == '6') echo "<OPTION SELECTED>6</OPTION>"; else echo "<OPTION>6</OPTION>";
		if ($t_0['lgb_champ'] == '7') echo "<OPTION SELECTED>7</OPTION>"; else echo "<OPTION>7</OPTION>";
		if ($t_0['lgb_champ'] == '8') echo "<OPTION SELECTED>8</OPTION>"; else echo "<OPTION>8</OPTION>";
		if ($t_0['lgb_champ'] == '9') echo "<OPTION SELECTED>9</OPTION>"; else echo "<OPTION>9</OPTION>";
		if ($t_0['lgb_champ'] == '10') echo "<OPTION SELECTED>10</OPTION>"; else echo "<OPTION>10</OPTION>";
		echo "</SELECT>&nbsp;&nbsp;\n";
	}
	$foreignKeyName=array([]);
	$foreignKeyType=array([]);
	$foreignKeyMax=0;
	if ($a == 'Foreign Key'){
		$clause='SHOW TABLES';
		$resultFK=$conn->query($clause) or die("Erreur:recherche Foreign Table!".$clause);
		echo '<SELECT NAME="FKI" ID="FKI" onchange="submit(); ">'."\n";
		while($ligneFK=$resultFK->fetch_row()){
			$clause='describe '.$ligneFK[0];
			$resultFKT=$conn->query($clause) or die("Erreur:recherche index Foreign Key!".$clause);
			$ligneFKT=$resultFKT->fetch_row();
			$foreignKeyName[$foreignKeyMax]=$ligneFK[0].'('.$ligneFKT[0].')';
			$foreignKeyType[$foreignKeyMax]=$ligneFKT[1];
			echo '<OPTION ';
			if ($_POST['FKI'] == $foreignKeyMax) echo 'SELECTED ';
			echo 'VALUE="'.$foreignKeyMax.'">'.$foreignKeyName[$foreignKeyMax]."</OPTION>\n";
			$foreignKeyMax++;
		}
		echo "</SELECT>\n";
	}
	if ($t_0['aj_table']){
		echo " PRIMARY KEY ";
		$t_0['cont_champ']="PRIMARY KEY";
		echo '<INPUT TYPE="HIDDEN" NAME="cont_champ" VALUE="PRIMARY KEY">'."\n"; 
	} else {
		$t_0['cont_champ']=$_POST['cont_champ'];
		echo '<SELECT NAME="cont_champ" onchange=submit(); ">';
		if ($t_0['cont_champ'] == '') echo "<OPTION SELECTED></OPTION>"; else echo "<OPTION></OPTION>";
		if ($t_0['cont_champ'] == 'NOT NULL') echo "<OPTION SELECTED>NOT NULL</OPTION>"; else echo "<OPTION>NOT NULL</OPTION>";
		if ($t_0['cont_champ'] == 'UNIQUE') echo "<OPTION SELECTED>UNIQUE</OPTION>"; else echo "<OPTION>UNIQUE</OPTION>";
		echo "</SELECT>\n";
	}
	echo "</TD></TABLE><BR>";
} //($ok3)
else echo "</TR></TABLE>\n";
$ok2=((vnom($t_0['nom_table'])) && (vnom($t_0['nom_champ'])) && (vnom($t_0['aj_table'])) && (vnom($t_0['aj_champ'])));
if ($ok){
// si aj_table : table selectionnee
	if ($t_0['aj_nom']) $t_0['nom_table']=$t_0['aj_table'];
	$result=$conn->query("SHOW TABLES") or die("Erreur:Liste des tables!");
	$ntbl=0; // nbe de tables
	while ($nom_tbl[$ntbl++]=$result->fetch_row());
}
// if ($t_0['aj_table']) $t_0['nom_table']='';
// structure de la table courante
if ($ok){
	$n=0; // nbe de champs
	$j=0; // indice dans le tableau des champs
	if ($t_0['nom_table']){
		$clause="DESCRIBE ".sqlp($t_0['nom_table']);
		$result=$conn->query($clause);
		if ($result){
		while ($ligne=$result->fetch_row()){
			$n++;
			for($i=0;$i<6;$i++) $tbl_c[$j++]=$ligne[$i];
		}
		}
		$ok=($n);
	}
} // ok
$clause='';
$t_0['type_champ']=$_POST['type_champ'];
// longueur du champ
$a=$t_0['type_champ'];
if (($a == 'CHAR') || ($a == 'VARCHAR') || ($a == 'TEXT') || ($a == DECIMAL)){
	$t_0['lga_champ']=$_POST['lga_champ'];
}
if ($a == 'DECIMAL'){
	if ($_POST['lga_champ']>11) $t_0['lga_champ']='11';
	$t_0['lgb_champ']=$_POST['lgb_champ'];
}
if (($a == 'CHAR') && ($t_0['lga_champ'] > 255)) $t_0['lga_champ']='64';
if ($t_0['aj_table']){
$t_0['cont_champ']='';
} else {
	$t_0['cont_champ']=$_POST['cont_champ'];
}
if (($_POST['SupChamp']) && ($t_0['nom_table']) && ($t_0['nom_champ']) && ($tbl_c[0] != $t_0['nom_champ'])){ // primary key non effacable
	$clause="ALTER TABLE ".sqlp($t_0['nom_table'])." DROP ".sqlp($t_0['nom_champ']);
}
if (($_POST['SupTable']) && ($t_0['nom_table'])){
	$clause='DROP TABLE '.sqlp($t_0['nom_table']);
	$t_0['nom_table']='';
}
if ($_POST['CrChamp']){
// verification renseignements minimums de validite
if (($a == 'CHAR') || ($a == 'VARCHAR') || ($a == 'TEXT') || ($a == 'DECIMAL')){
	if ((is_numeric($t_0['lga_champ']) == 0) || ($t_0['lga_champ'] <= 0)) $t_0['aj_champ']=$t_0['nom_champ']='';
}
if ($a == 'DECIMAL'){
	if ((is_numeric($t_0['lgb_champ']) == 0) || ($t_0['lgb_champ'] <= 0)) $t_0['aj_champ']=$t_0['nom_champ']='';
}
if ($t_0['aj_table']){ // recherche d'existence dans la base
	for($i=0;$i<$ntbl;$i++){
		if ($t_0['aj_table'] == $nom_tbl[$i]) $t_0['aj_table']='';
	}
	$a=$t_0['type_champ'];
}
if ($t_0['aj_table']) $t_0['nom_table']=$t_0['aj_table'];

echo "<HR>";
$op_create=0;
if (($t_0['aj_table']) && ($t_0['aj_champ']) && ($t_0['type_champ'])){
	$op_create=1;
	$clause="CREATE TABLE ".$t_0['aj_table']." (".sqlp($t_0['aj_champ'])." ".sqlp($t_0['type_champ']);
	if (($a == 'CHAR') || ($a == 'VARCHAR') || ($a == 'TEXT')) $clause.=" (".sqlp($t_0['lga_champ']).")";
	if ($a == 'DECIMAL') $clause.=" (".sqlp($t_0['lga_champ']).",".sqlp($t_0['lgb_champ']).")";
	$clause.=" PRIMARY KEY) ENGINE = XtraDB";
}
// champ existe dans table ?
if (($t_0['aj_champ']) && (!$t_0['aj_table'])){
	for($i=0;$i<$n;$i++) if ($tbl_c[$i*6+$i0] == $t_0['aj_champ']) $t_0['aj_champ']='';
}
if (($ok3) && ($t_0['aj_champ']) && ($t_0['type_champ']) && ($t_0['nom_table']) && (!$t_0['aj_table'])){
	if (isset($_POST['FKI'])){
		$clause="ALTER TABLE ".sqlp($t_0['nom_table'])." ADD ".sqlp($t_0['aj_champ'])." ".sqlp($foreignKeyType[$_POST['FKI']])."  COMMENT '".sqlp($foreignKeyName[$_POST['FKI']])."'";
		$result=$conn->query($clause) or die("Erreur:1 CONSTRAINT!".$clause);
		echo $clause."<BR>\n";
		$clause="ALTER TABLE ".sqlp($t_0['nom_table'])." ADD CONSTRAINT ".sqlp($t_0['aj_champ'])."_c FOREIGN KEY(".sqlp($t_0['aj_champ']).") REFERENCES ".sqlp($foreignKeyName[$_POST['FKI']]);
	}
	else {
	$clause="ALTER TABLE ".sqlp($t_0['nom_table'])." ADD ".sqlp($t_0['aj_table'])." ".sqlp($t_0['aj_champ'])." ".sqlp($t_0['type_champ']);
	if (($a == 'CHAR') || ($a == 'VARCHAR') || ($a == 'TEXT')) $clause.=" (".sqlp($t_0['lga_champ']).")";
	if ($a == 'DECIMAL') $clause.=" (".sqlp($t_0['lga_champ']).",".sqlp($t_0['lgb_champ']).")";
	$clause.=" ".sqlp($t_0['cont_champ']);
} // isset($FKI)
}
if (($t_0['nom_table']) && ($t_0['nom_champ']) && ($t_0['type_champ'])){
	if (isset($_POST['FKI'])){
		$clause="ALTER TABLE ".sqlp($t_0['nom_table'])." MODIFY ".sqlp($t_0['nom_champ'])." ".sqlp($foreignKeyType[$_POST['FKI']])."  COMMENT '".sqlp($foreignKeyName[$_POST['FKI']])."'";
		$result=$conn->query($clause) or die("Erreur:1 CONSTRAINT!".$clause);
		echo $clause."<BR>\n";
		$clause="ALTER TABLE ".sqlp($t_0['nom_table'])." ADD CONSTRAINT ".sqlp($t_0['nom_champ'])."_c FOREIGN KEY(".sqlp($t_0['nom_champ']).") REFERENCES ".sqlp($foreignKeyName[$_POST['FKI']]);
	}
	else {
		$clause="ALTER TABLE ".$t_0['nom_table']." MODIFY ".sqlp($t_0['nom_champ'])." ".sqlp($t_0['type_champ']);
		if (($a == 'CHAR') || ($a == 'VARCHAR') || ($a == 'TEXT')){
			if ($t_0['lga_champ']) $clause.=" (".sqlp($t_0['lga_champ']).")";
			else $clause='';
		}
		if ($a == 'DECIMAL'){
			if ($t_0['lgb_champ']) $clause.=" (".sqlp($t_0['lga_champ']).",".sqlp($t_0['lgb_champ']).")";
			else $clause='';
		}
	}
	if ($clause) $t_0['nom_champ']='';
}
	if ($clause) $clause.=" ".sqlp($t_0['cont_champ']);
} // if CrChamp
if (($ok2) && ($clause)  && (!stripos($clause,';')) && (($t_0['type_champ'] != 'Foreign Key') || (isset($_POST['FKI'])))){
	echo $clause."<BR>\n";
	$result=$conn->query($clause);
	if (!$result){
		$op_create=0;
		echo "<BR>Erreur de l'op&eacute;ration:".$conn->error."<BR>";
	} else {
		if ($t_0['aj_table']) $t_0['nom_table']=$t_0['aj_table'];
		$t_0['aj_champ']='';
		$t_0['aj_table']='';
	}
}
if ($ok3){
// Affichage liste des tables :si aj_table : table selectionnee
	echo '<BR><TABLE BORDER="0"><TR><TD>'."\n";
	if ($t_0['aj_table']) $t_0['nom_table']=$t_0['aj_table'];
	$result=$conn->query("SHOW TABLES");
	$ntbl=0; // nbe de tables
	echo 'Tables: <SELECT NAME="nom_table" ID="nom_table" SIZE="5" onchange="submit(); ">'."\n";
	while ($ligne=$result->fetch_row()){
		$ok=1;
		if ($ligne[0] == $t_0['nom_table']) echo "<OPTION SELECTED>".$ligne[0]."</OPTION>";
		else echo "<OPTION>".$ligne[0]."</OPTION>\n";
		$nom_tbl[$ntbl++]=$ligne[0];
	}
	echo "</SELECT>\n";
	echo "</TD>\n";
}
// structure de la table courante
if (($ok3) && ($t_0['nom_table']) && (!$t_1['aj_table'])){
	echo "<TD>";
	$n=0; // nbe de champs
	$j=0; // indice dans le tableau des champs
	if ($t_0['nom_table']){
		echo "&nbsp;";
		$clause="DESCRIBE ".$t_0['nom_table'];
		$result=$conn->query($clause);
		echo 'Champs: <SELECT NAME="nom_champ" SIZE="5" onchange="submit(); ">';
		while (($result) && ($ligne=$result->fetch_row())){
			$n++;
			for($i=0;$i<6;$i++) $tbl_c[$j++]=$ligne[$i];
			if ($ligne[0] == $t_0['nom_champ']) echo "<OPTION SELECTED>".$ligne[0]."</OPTION>";
			else echo "<OPTION>".$ligne[0]."</OPTION>";
		}
		echo "</SELECT></TD></TR></TABLE>\n";
		$ok=($n);
	$clause="SHOW CREATE TABLE ".sqlp($t_0['nom_table']);
	$result=$conn->query($clause) or die("Erreur:recherche commentaires!".$clause);
	$ligne=$result->fetch_row();
	$j0=stripos($ligne[1],'(');
	if (!$j0) die("Erreur:table mal formée!".$ligne[1]);
	$j0++;
	$ligne[1]=substr($ligne[1],$j0);
	$j1=0;
	for($i=0;$i<$n;$i++){
		$j2=stripos($ligne[1],',',$j1);
		$txt=substr($ligne[1],$j1,$j2-$j1);
		$j3=stripos($txt,"COMMENT '");
		if ($j3) $tbl_c[$i*6+5]=substr($txt,$j3+9,-1);
		$j1=$j2+1;
	}
	} // ($t_0['nom_table'])
	// tableau des champs
	echo "<TABLE BORDER='1'>";
	echo "<TR><TD>Nom du Champ</TD><TD> Type </TD><TD> Null? </TD><TD> Index </TD><TD> Valeur Init </TD><TD> Détails </TD></TR>\n";
	for($i=0;$i<$n;$i++){
		echo "<TR>\n";
		for ($i0=0;$i0<6;$i0++) echo "<TD>".$tbl_c[$i*6+$i0]."</TD>";
		echo "</TR>\n";
	}
	echo "</TABLE>\n";

}
echo "</FORM>\n";
echo "</BODY></HTML>\n";
?>
