<?php
	function verifieHtml($txt){
	$php=preg_replace('/ +/',' ',$txt);
	$php=str_replace('< ','<',$php);
	$phr=explode('<',$php);
	$n=count($phr);
	if ($n==1) return $txt;
	$dicoDeb=array('!DOCTYPE','!--','A','ABBR','ACRONYM','ADDRESS','APPLET','AREA','B', //9
	'BASE','BASEFONT','BDO','BGSOUND','BIG','BLINK','BLOCKQUOTE','BODY','BR','BUTTON','CAPTION', //11
	'CENTER','CITE','CODE','DD','DEL','DFN','DIR','DIV','DL','DT', //10
	'EM','EMBED','FIELDSET','FONT','FORM','FRAME','FRAMESET','H1','H2','H3', //10
	'H4','H5','H6','HEAD','HR','HTML','I','IFRAME','IMG','INPUT', //10
	'INS','KBD','LAYER','LEGEND','LI','LINK','MAP','META','NEXTID','NOEMBED', //10
	'NOFRAMES','NOSCRIPT','OBJECT','OL','OPTION','P','PARAM','PRE','Q','S', //10
	'SAMP','SCRIPT','SELECT','SMALL','SPAN','STRIKE','STRONG','STYLE','SUB','SUP', //10
	'TABLE','TBODY','TD','TEXTAREA','TFOOT','TH','THEAD','TITLE','TR','TT', //10
	'U','UL','VAR','AUDIO','SOURCE'); //5
	$dicoFin=array('','/--','/A','/ABBR','/ACRONYM','/ADDRESS','/APPLET','','/B','','','/BDO','','/BIG','/BLINK','/BLOCKQUOTE','/BODY','','/BUTTON','/CAPTION','/CENTER','/CITE','/CODE','','/DEL','/DFN','/DIR','/DIV','/DL','','/EM','','/FIELDSET','/FONT','/FORM','','/FRAMESET','/H1','/H2','/H3','/H4','/H5','/H6','/HEAD','','/HTML','/I','/IFRAME','','','/INS','/KBD','/LAYER','/LEGEND','/LI','','/MAP','','','/NOEMBED','/NOFRAMES','/NOSCRIPT','/OBJECT','/OL','','/P','/PARAM','/PRE','/Q','/S','/SAMP','/SCRIPT','/SELECT','/SMALL','/SPAN','/STRIKE','/STRONG','/STYLE','/SUB','/SUP','/TABLE','','/TD','/TEXTAREA','/TFOOT','/TH','/THEAD','/TITLE','/TR','/TT','/U','/UL','/VAR','/AUDIO','');
	$dicoCmd=array(1,1,6,6,6,6,1,1,6,
	1,2,6,1,6,6,6,1,2,1,6,
	6,6,6,2,6,6,6,6,6,6,
	6,5,6,6,5,5,5,6,6,6,
	6,6,6,1,2,1,6,5,2,1,
	6,6,1,6,2,2,5,1,1,5,
	5,5,5,2,5,6,5,6,6,6,
	6,8,5,6,6,6,6,6,6,6,
	6,1,6,5,5,2,2,5,6,2,
	6,2,6,6,2,0); // 1 0 en plus
	for($i=0;$i<$n;$i++){
		$j=strpos($phr[$i],' ');
		if (!$j) $j=20;
		$j2=strpos($phr[$i],'>');
		if (($j2) && ($j2<$j)) $j=$j2;
		if ($j) $balise[$i]=strtoupper(substr($phr[$i],0,$j));
		else $balise[$i]=strtoupper($phr[$i]);
	}
	$rep=$phr[0];
	$m=count($dicoDeb);
	$i=1;
	$level=0; // niveau pile emboitement HTML
	$tblHtml[0]='';
	while($i<$n){
		$j=0;
		while(($j<$m) && ($balise[$i] != $dicoDeb[$j])) $j++;
		$j2=0;
		while(($j2<$m) && ($balise[$i] != $dicoFin[$j2])) $j2++;
		if (($j<$m) || ($j2<$m)){
			if ($dicoCmd[$j] == 8){
				$motif='/'.$balise[$i];
				while(($i<$n) && ($balise[$i] != $motif)) $i++;
			}
			if ($dicoCmd[$j] == 6) $tblHtml[$level++]=$balise[$i];
			if ($dicoCmd[$j] & 2) $rep.='<'.$phr[$i];
			if ($dicoCmd[$j2] == 6){
				$level--;
				if ($level<0) return ''; //die("Erreur:emboitement balises HTML");
				$motif='/'.$tblHtml[$level];
				while(($level >= 0) && ($motif != $balise[$i])){
					$rep.='<'.$motif.'>';
					$level--;
					if ($level >= 0) $motif='/'.$tblHtml[$level];
				}
				if ($level<0) return ''; //die("Erreur:2:emboitement balises HTML:".$motif.'#'.$balise[$i]);
				$rep.='<'.$phr[$i];
			}
/*			if (($dicoCmd[$j] == 6) || ($dicoCmd[$j2] == 6)){ // pour test
				echo $i.'-->';
				for($j1=0;$j1<$level;$j1++) echo ':'.$tblHtml[$j1];
				echo '<BR>';
			}*/
		}
		$i++;
	}
// decodage
	$level--;
	for($j1=$level;$j1>0;$j1--) $rep.='</'.$balise[$j1];
	return $rep;
}
?>
