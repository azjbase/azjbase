<?php
function sqlp($txt){ // corrige ou supprime les caracteres speciaux \t \r \n \->\\ '->''
	$z=strlen($txt);
	$w='';
	for($x=0;$x<$z;$x++){
		$v0=$txt[$x];
		if (($v == "\n") || ($v == "\r") && ($v == "\t")) $v0='';
		if ($v == "'") $v0="\\\'";
		if ($v == "\\") $v0="\\\\";
		if ($v == '"') $v0='\"';
		$w.=$v0;
	}
	return $w;
}

function vnom($txt){ // verifie que le nom fourni suit a-z,A-Z,0-9,_
	$ok=0;
	$n=0;
	if ($txt <> '') $n=strlen($txt);
	if ($n < 1) return 0;
	$a=$txt[0];
	if (($a >= 'A') && ($a <= 'Z')) $ok=1;
	if (($a >= 'a') && ($a <= 'z')) $ok=1;
	if ($a == '_') $ok1;
	$i=1;
	while(($ok) && ($i<$n)){
		$a=$txt[$i];
		$ok=0;
		if (($a >= 'A') && ($a <= 'Z')) $ok=1;
		if (($a >= 'a') && ($a <= 'z')) $ok=1;
		if (($a >= '0') && ($a <= '9')) $ok=1;
		if ($a == '_') $ok=1;
		$i++;
	}
	return $ok;
} 
$i=error_reporting(E_ERROR+E_WARNING+E_PARSE+E_CORE_ERROR+E_CORE_WARNING+E_COMPILE_ERROR+E_COMPILE_WARNING);
echo "<HTML>\n<HEAD><TITLE>modification de base</TITLE></HEAD>\n<BODY>\n";
echo '<H1>Cr&eacute;ation de bases et association d\'utilisateurs</H1>'."\n";
echo '<FORM NAME="cre_user" METHOD="POST" ACTION="base_user2.php">'."\n";
// recherche des changements de parametres
if (!isset($_POST['srv_1_serveur'])) $_POST['srv_1_serveur']='';
if (!isset($_POST['port'])) $_POST['port']=3306;
if (!isset($_POST['srv_1_user'])) $_POST['srv_1_user']='root';
if (!isset($_POST['srv_1_mdp'])) $_POST['srv_1_mdp']='';
if (!isset($_POST['srv_1_base'])) $_POST['srv_1_base']=NULL;
$t_0['srv_1_serveur']=sqlp($_POST['srv_1_serveur']);
$t_0['srv_1_user']=sqlp($_POST['srv_1_user']);
$t_0['srv_1_mdp']=sqlp($_POST['srv_1_mdp']);
$t_0['srv_1_base']=sqlp($_POST['srv_1_base']); ?>
<TABLE NOBORDER><TR>
<TD WIDTH=45%>Serveur: <INPUT TYPE=TEXT NAME="srv_1_serveur" SIZE="16" MAXLENGTH="16" VALUE="<?PHP echo $t_0['srv_1_serveur'] ?>"></TD>
<TD>Port: <INPUT TYPE="number" NAME="port" SIZE="5" MAXLENGTH="5" VALUE="<?php echo $_POST['port'] ?>"></TD></TR>
<TR><TD>Utilisateur: <INPUT TYPE=TEXT NAME="srv_1_user" SIZE="32" MAXLENGTH="32" VALUE="<?php echo $t_0['srv_1_user'] ?>"></TD>
<TD>Mot de passe: <INPUT TYPE=PASSWORD NAME='srv_1_mdp' SIZE='32' MAXLENGTH='32' VALUE="<?php echo $t_0['srv_1_mdp'] ?>" ></TD></TR>
<TR><TD>Base de donn&eacute;es: <INPUT TYPE=TEXT NAME="srv_1_base" SIZE="24" MAXLENGTH="24" VALUE="<?php echo $t_0['srv_1_base'] ?>" ></TD>
<TD>Jeux de caracteres: <SELECT NAME="JeuxCar" SIZE="1">
<OPTION SELECTED VALUE="latin1">cp1252</OPTION>
<OPTION VALUE="utf8">Unicode</OPTION>
<OPTION VALUE=\"cp850\">DOS</OPTION>
</SELECT> 
</TD></TR></TABLE>
<BR><BR><INPUT TYPE="submit" NAME="base" Value="Cr&eacute;er la base de donn&eacute;es">
&nbsp;&nbsp;&nbsp;<INPUT TYPE="submit" NAME="connecter" VALUE="se connecter">
<?php $a=$t_0['srv_1_mdp'];
if ((stripos($a,';')) || ($a[0] == ';')){
	echo "Le mot de passe ne peut comporter de ;!";
	exit;
}
$a=$t_0['srv_1_base'];
if ((stripos($a,';')) || ($a[0] == ';')){
	echo "Le nom de la base ne peut comporter de ;!";
	exit;
}
if (!$a) exit; // pas de nom de base
vnom($a) or die("Erreur: nom de base invalide!");
if (!$t_0['srv_1_user']) exit; // pas d'utilisateur
$ok=1;
if (!(strlen($_POST['srv_1_serveur'])>2)) die("Ereur:Le nom du serveur doit comporter plus de 2 caractères!");
$conn=null;
if (($_POST['base']) && ($t_0['srv_1_base'])){ // créer la base
	$conn=new mysqli(sqlp($t_0['srv_1_serveur']),sqlp($t_0['srv_1_user']),sqlp($t_0['srv_1_mdp']),'mysql',$_POST['port']);
	if (($_POST['base']) && ($t_0['srv_1_base'])){
		$clause='CREATE DATABASE '.sqlp($t_0['srv_1_base']).' CHARACTER SET=\''.$_POST['JeuxCar'].'\'';
		echo $clause.'<BR><BR>';
		$result=$conn->query($clause) or die("Erreur pendant la cr&eacute;ation de la base".$conn->mysqli_error.":".$clause);
		if ($conn) $conn->close;
	}
	echo "</FORM>\n</BODY>\n<HTML>\n";
	exit;
}
if (!($t_0['srv_1_base'])) die("Erreur:connection impossible, la base et le serveur ne sont pas spécifiés!");
$conn=new mysqli(sqlp($t_0['srv_1_serveur']),sqlp($t_0['srv_1_user']),sqlp($t_0['srv_1_mdp']),$t_0['srv_1_base'],$_POST['port']);
if (!$conn) die("Erreur: Ouverture du serveur Mysql en lecture!".mysql_error());
echo '&nbsp;&nbsp;&nbsp;<INPUT TYPE="submit" NAME="CUser" Value="Cr&eacute;er utilisateur">';
echo '&nbsp;&nbsp;&nbsp;<INPUT TYPE="submit" NAME="RUser" Value="Supprimer des droits &agrave; un utilisateur"><BR>';
echo '&nbsp;&nbsp;&nbsp;<A HREF="doc/help_base_user2.html">Fonctionnement</A>'."\n";
echo '&nbsp;&nbsp;&nbsp;<A HREF="creer06.php">Création de la structure</A>'."\n";
echo '&nbsp;&nbsp;&nbsp;<A HREF="azjbase_0_0_25p.php">Création des masques d\'affichage/de saisie</A><BR><BR>'."\n";
// accord de droits a un utilisateur ou revocation de droits
if (isset($_POST['droits'])) $t_droits=$_POST['droits']; else $t_droits=array([]);
$clause=''; // pour grant
echo "Droits <SELECT MULTIPLE NAME=\"droits[]\" SIZE=\"8\">";
if (in_array('ALL',$t_droits)) echo '<OPTION SELECTED>ALL</OPTION>'; else echo '<OPTION>ALL</OPTION>';
if (in_array('ALL',$t_droits)) $t_droits_deactive=' DISABLED ';
else {
$t_droits_deactivate='';
if (in_array('ALTER',$t_droits)) echo '<OPTION SELECTED'.$t_droits_deactive.'>ALTER</OPTION>'; else echo '<OPTION $t_droits_deactive>ALTER</OPTION>';
if (in_array('INSERT',$t_droits)) echo '<OPTION SELECTED'.$t_droits_deactive.'>INSERT</OPTION>'; else echo '<OPTION'.$t_droits_deactive.'>INSERT</OPTION>';
if (in_array('DROP',$t_droits)) echo '<OPTION SELECTED'.$t_droits_deactive.'>DROP</OPTION>'; else echo '<OPTION'.$t_droits_deactive.'>DROP</OPTION>';
if (in_array('DELETE',$t_droits)) echo '<OPTION SELECTED'.$t_droits_deactive.'>DELETE</OPTION>'; else echo '<OPTION'.$t_droits_deactive.'>DELETE</OPTION>';
if (in_array('GRANT OPTION',$t_droits)) echo '<OPTION SELECTED'.$t_droits_deactive.'>GRANT OPTION</OPTION>'; else echo '<OPTION'.$t_droits_deactive.'>GRANT OPTION</OPTION>';
if (in_array('UPDATE',$t_droits)) echo '<OPTION SELECTED'.$t_droits_deactive.'>UPDATE</OPTION>'; else echo '<OPTION'.$t_droits_deactive.'>UPDATE</OPTION>';
if (in_array('SELECT',$t_droits)) echo '<OPTION SELECTED'.$t_droits_deactive.'>SELECT</OPTION>'; else echo '<OPTION'.$t_droits_deactive.'>SELECT</OPTION>';
if (in_array('FILE',$t_droits)) echo '<OPTION SELECTED'.$t_droits_deactive.'>FILE</OPTION>'; else echo '<OPTION'.$t_droits_deactive.'>FILE</OPTION>';
if (in_array('CREATE ROUTINE',$t_droits)) echo '<OPTION SELECTED'.$t_droits_deactive.'>CREATE ROUTINE</OPTION>'; else echo '<OPTION'.$t_droits_deactive.'>CREATE ROUTINE</OPTION>';
if (in_array('INDEX',$t_droits)) echo '<OPTION SELECTED'.$t_droits_deactive.'>INDEX</OPTION>'; else echo '<OPTION'.$t_droits_deactive.'>INDEX</OPTION>';
if (in_array('SHOW VIEW',$t_droits)) echo '<OPTION SELECTED'.$t_droits_deactive.'>SHOW VIEW</OPTION>'; else echo '<OPTION'.$t_droits_deactive.'>SHOW VIEW</OPTION>';
if (in_array('TRIGGER',$t_droits)) echo '<OPTION SELECTED'.$t_droits_deactive.'>TRIGGER</OPTION>'; else echo '<OPTION'.$t_droits_deactive.'>TRIGGER</OPTION>';
}
echo "</SELECT>\n";
echo "Nouvel utilisateur <INPUT TYPE='TEXT' NAME='person' SIZE='32' MAXLENGTH='32'>\n";
echo "&nbsp;&nbsp;&nbsp;";
echo "de mot de passe <INPUT TYPE='TEXT' NAME='pass' SIZE='32' MAXLENGTH='32'><BR>\n";
if (isset($_POST['person'])) $t_pperson=$_POST['person']; else $t_pperson='';
if (isset($_POST['pass'])) $t_ppass=$_POST['pass']; else $t_ppass='';
$clause='';
foreach ($t_droits as $t_droits_val){
	if (!$clause) $clause=$t_droits_val; else $clause.=','.$t_droits_val;
}
echo $_POST['CUser'];
if ($_POST['CUser']){
	$clause='GRANT '.$clause;
	if (($t_pperson) && ($t_ppass)){
		if (!$clause) die("Erreur:Il faut au moins un droit!");
		$clause.=' ON '.sqlp($t_0['srv_1_base']).'.* TO \''.sqlp($t_pperson).'\'@\''.$t_0['srv_1_serveur'].'\' IDENTIFIED BY \''.sqlp($t_ppass).'\'';
		echo '<BR>'.$clause.'<BR>';
		$result=$conn->query($clause) or die("Erreur pendant la creation de l'utilisateur".$conn->mysqli_error);
	} else exit();
}
if ($_POST['RUser']){
	if ($t_pperson){
		$clause='REVOKE '.$clause;
		$clause.=' ON '.sqlp($t_0['srv_1_base']).'.* FROM \''.sqlp($t_pperson).'\'@\''.$t_0['srv_1_serveur'].'\'';
		echo '<BR>'.$clause.'<BR>';
		$result=$conn->query($clause,$instance) or die("Erreur pendant la r&eacute;vocation de droits de l'utilisateur".$conn->mysqli_error);
	}
}
echo "</FORM>\n";
echo "</BODY>\n";
echo "</HTML>\n";
?>
