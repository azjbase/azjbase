<?php
// Genere par azj_base 0.0.28p - (c) Alexandre Zvenigorosky - 22/03/2016
require('../../verifieHtml.php');
function sqlp($txt){ // corrige ou supprime les caracteres speciaux \t \r \n \->\ '->''
if (is_numeric($txt)) return $txt;
$z=strlen($txt);
$w='';
$x=0;
while($x<$z){
	$v=$txt[$x++];
	if (($v == "\\") || ($v=="\n") | ($v=="\t") | ($v == "\r")) $v="";
	if ($v == "'") $v="\\'";
	$w.=$v;
}
return $w;
}
echo '<!DOCTYPE HTML>'."\n";
echo '<HTML>'."\n";
echo '<HEAD>'."\n";
echo '<TITLE>saisie2</TITLE>'."\n";
echo '<SCRIPT TYPE="text/javascript" SRC="../../js/headAZJ.js"></SCRIPT>';
echo '</HEAD>'."\n";
echo '<BODY>'."\n";
$conn=new mysqli('127.0.0.1','root','&constellation','docAZJ',3306);
if (!$conn) die("Erreur: Ouverture du serveur Mysql en lecture!");
if (!isset($_POST['indicev'])) $ndeb=0; else $ndeb=$_POST['indicev'];
$l0=4;
$l=1;
$tbl_table[0]='HTML';
$ts[0]=0;
$tidx[0]='HTML_idx';
$tl_tbl[0]='HTML_idx';
$tl_tbl[1]='HTML_rubrique';
$tl_tbl[2]='HTML_texte';
$tl_tbl[3]='HTML_codes';
if (!isset($_POST['HTML_idx'])) $_POST['HTML_idx']='';
$ligne[0]=$_POST['HTML_idx'];
if (!isset($_POST['HTML_rubrique'])) $_POST['HTML_rubrique']='';
$ligne[1]=$_POST['HTML_rubrique'];
if (!isset($_POST['HTML_texte'])) $_POST['HTML_texte']='';
$ligne[2]=$_POST['HTML_texte'];
if (!isset($_POST['HTML_codes'])) $_POST['HTML_codes']='';
$ligne[3]=$_POST['HTML_codes'];
$ts[$l]=4;
$mod_sql=0;
if ($ligne[0] !== FALSE) $mod_sql=1;
$a8=0;
$req="INSERT INTO HTML (HTML_idx, HTML_rubrique, HTML_texte, HTML_codes) VALUES('".sqlp($ligne[0])."', '".sqlp($ligne[1])."', '".sqlp($ligne[2])."', '".sqlp($ligne[3])."') ON DUPLICATE KEY UPDATE HTML_idx='".sqlp($ligne[0])."', HTML_rubrique='".sqlp($ligne[1])."', HTML_texte='".sqlp($ligne[2])."', HTML_codes='".sqlp($ligne[3])."'";
if ($mod_sql){
if (!isset($_POST['indicev'])) $_POST['indicev']=0;
if (!isset($_POST['indices'])) $_POST['indices']=0;
if (!isset($_POST['indicep'])) $_POST['indicep']=0;
if (!isset($_POST['Effacer'])) $_POST['Effacer']=0;
if (!isset($_POST['_flags'])) $_POST['_flags']=0;
if ((isset($_GET['affiche'])) && ($_GET['affiche'])) $_POST['_flags']=1;if ((isset($_POST['saisie'])) && ($_POST['saisie']) && (!$_POST['_flags'])){
		$result=$conn->query($req);
		if ($result) $a8++;
		else {
			echo "Echec mise a jour de la table:".$conn->error;
			exit;
 }
 }
	if ($_POST['Effacer']){
		$req='DELETE FROM '.$tbl_table[0].' WHERE ';
		$req.=$tl_tbl[0].'=\''.$_POST[$tl_tbl[0]].'\'';
		echo $req.'<BR>';
		$result=$conn->query($req);
		if ($result) $a8++;
		else {
			echo "Echec de la suppression!".$conn->error;
			exit;
		}
	}
}
if ($mod_sql){
	$ndeb=$_POST['indicev'];
	$ndeb=0+$a8+$ndeb;
	if ($_POST['indicep']) $ndeb--;
	if ($_POST['indices']) $ndeb++;
	if ($ndeb<0) $ndeb=0;
}
$a7=' LIMIT '.$ndeb.',1';
$clause="SELECT HTML_idx, HTML_rubrique, HTML_texte, HTML_codes FROM HTML".sqlp($a7);
$result=$conn->query($clause);
if (!$mod_sql) erreur('Formulaire hors champ!');
$num_result=0;
$ligne=$result->fetch_row();
while($num_result < 1){
	$num_result++;
echo ' <form method="POST" name="saisie2" action=""><h1>Saisie documentation azjbase 0.0.28p</h1><p><input name="HTML_rubrique" size="64" maxlength="64" value="';
echo str_replace('"','&quot;',$ligne[1]);
echo '" required="" type="text"> index <input name="HTML_idx" size="" maxlength="" value="';
echo str_replace('"','&quot;',$ligne[0]);
echo '" required="" type="number"></p><p>';
$formulaire=str_replace("\\","",$ligne[2]);
echo "<script type=\"text/javascript\" src=\"../../editor/barreoutils3.js\"></script>\n";
require_once "/var/www/html/azjbase_0_0_28/edit004.php";
if (!$_POST['_flags']) edite('HTML_texte',verifieHtml($ligne['2']),'saisie2.fiches'); else echo "<DIV>".verifieHtml($ligne['2'])."</DIV>";
echo '</p><input name="saisie" value="saisie" type="submit" onclick="sauve2();"> ';
echo "\n<br><input type=\"submit\" name=\"indicep\" value=\"Pr&eacute;c&eacute;dent\">\n";
echo "&nbsp;&nbsp;&nbsp;<input type=\"text\" size=\"8\" maxlength=\"8\" name=\"indicev\" id=\"indicev\" value='".$ndeb."'>\n";
$txt='';if ($_POST['_flags']) $txt=' checked ';echo "&nbsp;&nbsp;&nbsp;<input type=\"checkbox\" name=\"_flags\" id=\"_flags\" ".$txt."onChange=\"submit(); \">\n";
echo "&nbsp;&nbsp;&nbsp;<input type=\"submit\" name=\"indices\" value=\"Suivant\">\n";
echo " _________________ <input type=\"submit\" name=\"Effacer\" value=\"Effacer\">\n";
echo '<input type="hidden" id="_son" name="_son" value=""></form>';
echo '<hr \>';
}
echo "<script type=\"text/javascript\">";
echo "function sauve2(){";
echo "fermeture('HTML_texte');";
echo "}";
echo '</script>';
echo "\n".'</BODY>'."\n";
echo '</HTML>'."\n";
?>
